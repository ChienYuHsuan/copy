import asv_pipeline.config as cfg

# from asv_pipeline.util import get_cluster_by_naming


class PoolName(object):

    def __init__(self, cpu=None, stepping=None, asignto=None, state=None, subclustername=None,
                 test_description=None, idsid=None):
        self.cpu = cpu
        self.stepping = stepping
        self.asignto = asignto
        self.state = state
        self.test_description = test_description
        self.subclustername = subclustername
        self.idsid = idsid
        self.pool = None
        self.headers = {
            "accept": "application/json, text/plain, */*",
            "authorization": "Basic {}".format(cfg.clusterscopes_base_auth),
            "Content-Type": "application/json;charset=UTF-8",
        }
        self.data = {"nodes": [], "data": {}, "pool": {}}

    def __str__(self):
        s = "%s_%s_%s_%s_%s_%s_%s" % (self.cpu, self.stepping, self.asignto, self.state,
                                      self.subclustername, self.test_description, self.idsid)
        # s += "\n"
        # s += f"CPU:{self.cpu} | STEPPING:{self.stepping} | Asignto:{self.asignto} | State:{self.state}"
        # s += f" | SubClusterName:{self.subclustername} | Test_Description:{self.test_description} | IDSID:{self.idsid}"
        return s

    def update_node(self, node, location):
        """
        Format of node name in ClusterScope is like: 'r013s002.fl30lne001:fl30lne001'
        For nodes migrated from OPUS to Flex, format will be like 'fl31ca105bs0709:fl30lne001'
        """
        '''
        cluster = get_cluster_by_naming(node)
        if cluster == 'zp31':
            self.data['nodes'] += [node + ':' + 'zp3110b']
        elif cluster == 'flex':
            self.data['nodes'] += [node + ':' + 'fl30lne001']
        elif cluster == 'bhs':
            self.data['nodes'] += [node + ':' + 'fl31ca1']
        else:
            self.data['nodes'] += ['.'.join(node.split('.')) + ':' + node.split('.')[-1]]
        '''
        self.data['nodes'] += [node + ':' + location]
        return self

    def update_cpu(self, cpu):
        self.cpu = cpu
        self.data['data']['CPU'] = cpu
        return self

    def update_stepping(self, stepping):
        self.stepping = stepping
        self.data['data']['Stepping'] = stepping
        return self

    def update_assignto(self, assignto):
        self.asignto = assignto
        self.data['data']['AssignTo'] = assignto
        return self

    def update_state(self, state):
        self.state = state
        self.data['data']['State'] = state
        return self

    def update_subclustername(self, subclustername):
        self.subclustername = subclustername
        self.data['data']['SubclusterName'] = subclustername
        return self

    def update_test_description(self, test_description):
        # def update_test_description(self, phase=''):
        # if phase:
        #     self.test_description = self.test_description + '-NOTREADY-' + phase
        # else:
        #     self.test_description += '-NOTREADY'
        self.test_description = test_description
        self.data['data']['TestDescription'] = self.test_description
        return self

    def update_idsid(self, idsid):
        self.idsid = idsid
        self.data['data']['IDSID'] = idsid
        return self

    def update_pool(self, pool):
        arr = pool.split('_')
        self.cpu, self.stepping, self.asignto, self.state, self.subclustername, self.test_description, self.idsid = arr[
            0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6]
        self.data['pool'] = pool
        return self


def parse(name):
    """Format the poolname to a structured variables

    Args:
        name (str): The name of node.
    Returns:
        PoolName (class): A structured variables
    """

    import re
    arr = re.split(r'_', name)
    if len(arr) <= 6:
        raise Exception(name)
    return PoolName(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], "".join(arr[6:]))


if __name__ == "__main__":
    s = "SPR_XCC-E2_PLN_EXC_PIV_BURNIN2-QS-WAVE2_VIMARTI"
    pn = parse(s)
    print(pn)
    pn.test_description += '-NOTREADY'
    print(pn)
