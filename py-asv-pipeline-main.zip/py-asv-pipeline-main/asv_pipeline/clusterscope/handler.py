"""
get pool and related poolname by the nodes
"""
# if sys.version_info.major == 3 and sys.version_info.minor < 9
from __future__ import annotations

import logging
import re
import sys

import tenacity

import asv_pipeline.config as cfg
from asv_pipeline.clusterscope import ClusterScope, ClusterScopeException
from asv_pipeline.clusterscope.poolname import parse
from asv_pipeline.util import are_both_empty_dicts, get_cluster_by_naming, return_last_value

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)


def get_metadata_by_nodes(nodes):
    rst, ret = [], {}
    """
    check whether we need to iterate all clusters or not
    """
    clusters = set()
    if nodes is not None:
        locations = get_location_by_nodes(nodes)

        for x in nodes:
            try:
                clusters.add(get_cluster_by_naming(x))
            except Exception as e:
                log.error(str(e))
                sys.exit(0)
        for node in nodes:
            location = locations.get(node, "")
            '''
            if get_cluster_by_naming(node) == 'flex' or get_cluster_by_naming(node) == 'bhs':
                location = 'fl30lne001'
            elif get_cluster_by_naming(node) == 'zp31':
                location = 'zp3110b'
            else:
                location = node.split(".")[1]
            '''
            for cluster, cs in cfg.clusterscopes.items():
                if clusters and cluster not in clusters:
                    continue
                try:
                    ret = ClusterScope(cs, timeout=360).instant_meta_data_by_name(
                        node.split(), location.split())
                except Exception as e:
                    log.error(str(e))
                if ret:
                    break
            if ret:
                rst.append(ret)

    return rst


@tenacity.retry(stop=tenacity.stop_after_attempt(3),
                wait=tenacity.wait_exponential(min=10, max=40, multiplier=10), reraise=True,
                retry_error_callback=return_last_value,
                retry=tenacity.retry_if_result(are_both_empty_dicts))
def get_pool_by_nodes(nodes, cluster=None):
    rst, noassigned, ret = {}, {}, {}
    # mp = {"fl30lcent1": set(), "ive-infra04": set()}  # cluster: nodes

    # =====================================
    # Get rid of this part.
    # Due to the issue of URL's length, we might not access the API successfully
    # =====================================
    #
    # for k, v in kv.items():
    #     if "flex"== k:
    #         mp["fl30lcent1"] = mp["fl30lcent1"].union(v)
    #     else:
    #         mp["ive-infra04"] = mp["ive-infra04"].union(v)

    # for cluster, cs in cfg.clusterscopes.items():
    #     if cluster == 'icx-1': continue
    #     nodes = []
    #     if cluster == 'flex':
    #         nodes = [n.name for n in mp["fl30lcent1"]]
    #     else:
    #         nodes = [n.name for n in mp["ive-infra04"]]
    """
    check whether we need to iterate all clusters or not
    """
    clusters = set()

    if cluster:
        clusters.add(cluster)
    else:
        if nodes is not None:
            for x in nodes:
                try:
                    clusters.add(get_cluster_by_naming(x))
                except Exception as e:
                    log.error(str(e))

    for cluster, cs in cfg.clusterscopes.items():
        if clusters and cluster not in clusters:
            continue
        try:
            # logging.critical(cluster)
            # logging.critical(cs)
            # TODO 2024.5.9 need to refactory this part
            ret = ClusterScope(cs, timeout=360).instant_query_by_name(nodes)
        except Exception as e:
            log.error(str(e))
        for _p in ret:
            name, pool = _p.get("name"), _p.get("pool")
            try:
                rst[name] = parse(pool)
            except Exception as e:
                log.debug(str(e))
                noassigned[name] = pool
                log.debug(f'{name} resides in {pool} pool')
                # print(name, "resides in %s pool" % pool)
                continue
            rst[name].pool = pool
        for k in rst:
            if k in noassigned:
                del noassigned[k]
    return rst, noassigned


"""
Update pool and related poolname by the nodes
"""


def update_pool_by_nodes(cs, pool):
    ret = {}
    try:
        ret = cs.instant_update_by_name(pool.headers, pool.data)
    except Exception as e:
        log.error(str(e))

    return ret


def update_pool_by_names(cs, pool):
    ret = {}
    try:
        ret = cs.instant_update_pool_by_name(pool.headers, pool.data)
    except Exception as e:
        log.error(str(e))
    return ret


def get_action_history_by_node(node, size, start, end, timeout=360):
    """Get node action histories.

    Args:
        node (str): The name of node.
        size (int): get result size of action histories
        start (str): the search start date, e.g. 2022-12-13
        end (str): the search end date, e.g. 2022-12-15

    Returns:
        List: the node's action hitories

    Raises:
        ClusterScopeException: when clusterscope cannot connect, will raise exception
    """
    clusters = set()
    location = ""
    if node is not None:
        clusters.add(get_cluster_by_naming(node))
        location = get_location_by_nodes(node.split())[node]

    variable = {"name": node, "count": size, "location": location, "from": start, "to": end}

    for cluster, cs in cfg.clusterscopes.items():
        if clusters and cluster not in clusters:
            continue
        try:
            ret = ClusterScope(cs, timeout=timeout).get_node_action_history(variable)
            return ret
        except (ClusterScopeException, Exception):
            raise ClusterScopeException('')


"""
Get CPU
"""


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def get_cpu(nodes: list[str], cache=None, cluster=None) -> dict[str, str]:
    if not cache:
        a, b = get_pool_by_nodes(nodes, cluster)
        cache = [a, b]
    else:
        logging.debug("get_cpu uses cache")
        logging.debug(cache)
        a, b = cache[0], cache[1]
    rst = {}
    for k, v in a.items():
        rst[k] = v.cpu

    for k, v in b.items():
        try:
            rst[k] = parse(v).cpu
        except Exception:
            try:
                rst[k] = v.split("_")[0]
            except Exception:
                rst[k] = "undetermined"
    return rst


"""
Get Stepping
"""


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def get_stepping(nodes: list[str], cache=None, cluster=None) -> dict[str, str]:
    if not cache:
        a, b = get_pool_by_nodes(nodes, cluster)
        cache = [a, b]
    else:
        logging.debug("get_stepping uses cache")
        logging.debug(cache)
        a, b = cache[0], cache[1]
    rst = {}
    for k, v in a.items():
        rst[k] = v.stepping

    for k, v in b.items():
        try:
            rst[k] = parse(v).stepping
        except Exception:
            try:
                A = v.split("_")
                if len(A) >= 2:
                    rst[k] = A[1]
            except Exception:
                rst[k] = "undetermined"
    return rst


"""
Get States
"""


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def get_state(nodes: list[str], cache=None, cluster=None) -> dict[str, str]:
    if not cache:
        a, b = get_pool_by_nodes(nodes, cluster)
        cache = [a, b]
    else:
        logging.debug("get_state uses cache")
        logging.debug(cache)
        a, b = cache[0], cache[1]
    for k, v in a.items():
        logging.info((k, str(v)))
    for k, v in b.items():
        logging.info((k, str(v)))
    rst = {}
    for k, v in a.items():
        rst[k] = v.state

    for k, v in b.items():
        try:
            rst[k] = parse(v).state
        except Exception:
            try:
                A = v.split("_")
                if len(A) >= 4:
                    rst[k] = A[3]
            except Exception:
                rst[k] = "undetermined"
    return rst


"""
Get asignto
"""


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def get_asignto(nodes: list[str], cache=None, cluster=None) -> dict[str, str]:
    if not cache:
        a, b = get_pool_by_nodes(nodes, cluster)
        cache = [a, b]
    else:
        logging.debug("get_asignto uses cache")
        logging.debug(cache)
        a, b = cache[0], cache[1]
    for k, v in a.items():
        logging.info((k, str(v)))
    for k, v in b.items():
        logging.info((k, str(v)))
    rst = {}
    for k, v in a.items():
        rst[k] = v.asignto

    for k, v in b.items():
        try:
            rst[k] = parse(v).asignto
        except Exception:
            try:
                A = v.split("_")
                if len(A) >= 4:
                    rst[k] = A[2]
            except Exception:
                rst[k] = "undetermined"
    return rst


"""
get nodes by poolname
"""


def get_nodes_by_poolname(partial_poolname: str, cs: str | None = None):
    rst = {}

    def _inner(_cs):
        param = None
        ret = {}
        if isinstance(partial_poolname, list):
            param = partial_poolname
        elif isinstance(partial_poolname, str):
            param = [partial_poolname]
        try:
            ret = ClusterScope(cfg.clusterscopes[cs], timeout=360).instant_query_by_pool(param)
        except Exception as e:
            log.error(str(e))
        for _p in ret:
            name, location = _p.get("name"), _p.get("pool")
            try:
                rst[name] = location
            except Exception:
                rst[name] = None
                log.warning(f'{name} resides in {location} location')
                # print(name, "resides in %s location" % location)
                continue

    try:
        if not cs:
            for _, cs in cfg.clusterscopes.items():
                _inner(cs)
        else:
            _inner(cs)
    except Exception as e:
        log.error(e)
    return rst


"""
Get node location
"""


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def get_location_by_nodes(nodes):
    rst, ret = {}, {}
    clusters = set()
    if nodes is not None:
        for x in nodes:
            try:
                clusters.add(get_cluster_by_naming(x))
            except Exception as e:
                log.error(str(e))

    for cluster, cs in cfg.clusterscopes.items():
        if clusters and cluster not in clusters:
            continue
        try:
            ret = ClusterScope(cs, timeout=360).instant_query_by_name(nodes)
        except Exception as e:
            log.error(str(e))
        for _p in ret:
            name, location = _p.get("name"), _p.get("location")
            try:
                rst[name] = location
            except Exception:
                rst[name] = None
                log.warning(f'{name} resides in {location} location')
                # print(name, "resides in %s location" % location)
                continue

    return rst


def get_pool_name(nodes: list[str]) -> dict[str, str]:
    rst, noassigned = get_pool_by_nodes(nodes)
    mp = rst
    for k, v in noassigned.items():
        mp[k] = parse(v)
    return mp


def update_pool_name(nodes: list[str], exptected_fields_values: dict[str, str] = None,
                     pool_name_cache: dict[str, str] = None):
    """
    exptected_fields_and_values
    fields: cpu, stepping, assignto, state, subclustername, test_description, idsid
    """
    mp = get_pool_name(nodes) if not pool_name_cache else pool_name_cache
    locations = get_location_by_nodes(nodes)
    # cs = ClusterScope(cfg.clusterscopes[get_cluster_by_naming()])
    cluster_mp = {}
    cs_mp = {}
    for n in mp:
        _cluster = get_cluster_by_naming(n)
        cluster_mp[n] = _cluster
        if _cluster not in cs_mp:
            cs_mp[_cluster] = ClusterScope(cfg.clusterscopes[_cluster], timeout=60)

    for n in mp:
        if n not in mp:
            continue

        cpu, stepping, state, subclustername, test_description, idsid \
            = mp[n].cpu, mp[n].stepping, mp[n].state, mp[n].subclustername, mp[n].test_description, mp[n].idsid
        if not exptected_fields_values:
            continue

        if exptected_fields_values.get('state', state) not in [
                'DBG', 'MIP', 'ERR', 'BRK', 'RDY', 'DEP', 'EXC', 'DEV', 'RER', 'NTR', 'COM', 'END',
                'PCE'
        ]:
            logging.error(state)
            raise Exception(
                "state is not one of 'DBG','MIP','ERR','BRK','RDY','DEP','EXC', 'DEV', 'RER', 'NTR', 'COM','END'"
            )

        if exptected_fields_values.get(
                'subclustername', subclustername) not in ['IVE', 'OSS', 'PIV', 'FREE', 'DEFAULT']:
            logging.error(state)
            raise Exception("state is not one of 'IVE','OSS','PIV','FREE','DEFAULT'")

        if exptected_fields_values.get('assignto', mp[n].asignto) not in [
                'IVE', 'PIV', 'BKC', 'RAS', 'INF', 'PLN', 'DEV', 'IPU'
        ]:
            logging.error(state)
            raise Exception("state is not one of 'IVE','PIV','BKC','RAS','INF','PLN','DEV', 'IPU'")

        mp[n].update_node(n, locations[n]).update_cpu(exptected_fields_values.get('cpu', cpu)) \
            .update_stepping(exptected_fields_values.get('stepping', stepping)) \
            .update_assignto(exptected_fields_values.get('assignto', mp[n].asignto)) \
            .update_state(exptected_fields_values.get('state', state)) \
            .update_subclustername(exptected_fields_values.get('subclustername', subclustername)) \
            .update_test_description(exptected_fields_values.get('test_description', test_description)) \
            .update_idsid(exptected_fields_values.get('idsid', idsid))
        _cluster = cluster_mp[n]
        print("==> ", mp[n].data)
        mp[n].update_pool(str(mp[n]))
        print(cs_mp[_cluster].server)
        try:
            # I don't see any useful for the first argument, nodes.
            update_pool_by_names(cs_mp[_cluster], mp[n])
            # cs_mp[_cluster].instant_update_by_name(mp[n].headers, mp[n].data)
        except Exception as e:
            logging.error("%s, %s" % (mp[n], str(e)))
            continue


def get_sku(node, cpu0, cpu1):
    defaultSKU = "unknown"
    try:
        if cpu0 and any(x in cpu0.get("qdf", "") for x in ("NA", "unknown", "N/A")):
            cpu0 = {}
        if cpu1 and any(x in cpu1.get("qdf", "") for x in ("NA", "unknown", "N/A")):
            cpu1 = {}

        if any(cpu0) and any(cpu1):
            defaultSKU = "2S"
        elif any(cpu0) and not any(cpu1):
            defaultSKU = "1S"
    except Exception as e:
        log.error("get SKU error, node = {} , ".format(node) + str(e))

    return defaultSKU


def estimate_tags_in_test_desc(desc: str, no_prefix=False):
    """
    Estimate tags in the test description.

    This function parses a given test description string to extract specific tags
    and their components. The description is expected to follow a specific format
    with tags separated by "--" and further divided by "-".

    Args:
        desc (str): The test description string to parse.
        no_prefix (bool, optional): If True, removes prefixes like "COM-" or "RER-"
            from the tags. Defaults to False.

    Returns:
        tuple: A tuple containing:
            - str or None: The first tag component (e.g., "BKC").
            - str or None: The second tag component (e.g., "M01").
            - str or None: The third tag component (e.g., "IO7").
            - str: The remaining part of the tags or the full tags string if the
              format is incorrect.

    Raises:
        None: Logs errors if the description format is incorrect.
    """
    try:
        # MAIN--BKC-M01-IO7-DEMO
        if "--" not in desc:
            log.error("Description format is incorrect")
            return None, None, None, desc
        # desc.split("--")[0] stands for task name
        tags = desc.split("--")[1]
        parts = tags.split("-")
        if len(parts) < 4:
            return None, None, None, re.sub(r'^(COM-|RER-)', '', tags) if no_prefix else tags
        return parts[0], parts[1], parts[2], "-".join(parts[3:])
    except IndexError:
        log.error("Description format is incorrect")
        return None, None, None, desc


# if __name__ == "__main__":
#    get_node_action_history("r002s014.zp31l10b01", 1, "2022-12-01", "2023-01-07")
#    for k, v in get_pool_by_nodes(["r002s014.zp31l10b01", "r008s011.zp31l10b01"])[0].items():
#        print(k, ":", v, "->", v.pool)
