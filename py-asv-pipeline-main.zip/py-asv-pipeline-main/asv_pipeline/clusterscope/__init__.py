import json
import logging
import os
import socket
from urllib.parse import urljoin

import requests
import requests.exceptions as req_exc
from urllib3.exceptions import InsecureRequestWarning

try:  # Python 2.7+
    from logging import NullHandler
except ImportError:

    class NullHandler(logging.Handler):

        def emit(self, record):
            pass


logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# REST Endpoints
""" for history/journal restapi, you have to add the parameter, count"""
GET_NODE_LAST_HISTORY = 'api/node/status/history'  # Not available, Get Last Status History By Node
GET_NODE_MEMORY_DETAIL = 'api/node_memory_info/%(location)s/%(node_name)s'  # Get Node Memory Details
GET_NODE_CRASHDUMP = 'api/node/with_error'  # Get Node with Error While Collecting Crashdump
GET_NODE_STATUS = 'api/node/status'  # Get Node Last Status
GET_NODE_METADATA = 'api/node/metadata?name=%(nodes)s&location=%(locations)s'
GET_NODE_ACTION_HISTORY = 'api/node/history/actions'  # Get Node Actions History
UPDATE_NODE_POOL_NAME = 'api/node/update/pool_by_fields'  # Update node pool name by fields
UPDATE_NODE_POOL_NAME_ALL = 'api/node/update/pool'  # Update node pool name with complete new pool name

QUERY_BY_NODE_NAMES = 'api/instant_query?key=name&value=%(nodes)s'
""" the particular key query is definitly not required !! using metadata to get what you need"""
# GET_NODE_SPECIFIC_KEY='api/node/status/specific_key' # Get Node Specific Key

QUERY_BY_POOL_NAMES = 'api/instant_query?key=pool&value=%(pool_names)s'
GET_NODE_INVENTORY = 'api/node/inventory'  # Get Node Inventory


class ClusterScopeException(Exception):
    '''General exception type for jenkins-API-related failures.'''
    pass


class NotFoundException(ClusterScopeException):
    '''A special exception to call out the case of receiving a 404.'''
    pass


class EmptyResponseException(ClusterScopeException):
    '''A special exception to call out the case receiving an empty response.'''
    pass


class BadHTTPException(ClusterScopeException):
    '''A special exception to call out the case of a broken HTTP response.'''
    pass


class TimeoutException(ClusterScopeException):
    '''A special exception to call out in the case of a socket timeout.'''


class WrappedSession(requests.Session):
    """A wrapper for requests.Session to override 'verify' property, 
       ignoring REQUESTS_CA_BUNDLE environment variable.

       workaround for https://github.com/kennethreitz/requests/issues/3829 
       (will be fixed in requests 3.0.0)
    """

    def merge_environment_settings(self, url, proxies, stream, verify, *args, **kwargs):
        if self.verify is False:
            verify = False

        return super(WrappedSession, self).merge_environment_settings(url, proxies, stream, verify,
                                                                      *args, **kwargs)


class ClusterScope(object):
    _timeout_warning_issued = False

    def __init__(self, url='http://ive-infra04.deacluster.intel.com:5000', username=None,
                 password=None, timeout=socket._GLOBAL_DEFAULT_TIMEOUT):
        '''Create handle to ClusterScope instance.

        All methods will raise :class:`ClusterScopeException` on failure.

        :param url: URL of ClusterScope server, ``str``
        :param timeout: Server connection timeout in secs (default: not set), ``int``
        '''
        if url[-1] == '/':
            self.server = url
        else:
            self.server = url + '/'

        self._auths = [('anonymous', None)]
        self._auth_resolved = False
        if username is not None and password is not None:
            self._auths[0] = ('basic',
                              requests.auth.HTTPBasicAuth(username.encode('utf-8'),
                                                          password.encode('utf-8')))

        self.auth = None
        self.timeout = timeout
        self._session = WrappedSession()

        extra_headers = os.environ.get("JENKINS_API_EXTRA_HEADERS", "")
        if extra_headers:
            logging.warning("JENKINS_API_EXTRA_HEADERS adds these HTTP headers: %s",
                            extra_headers.split("\n"))
        for token in extra_headers.split("\n"):
            if ":" in token:
                header, value = token.split(":", 1)
                self._session.headers[header] = value.strip()

        if os.getenv('PYTHONHTTPSVERIFY', '1') == '0':
            logging.debug('PYTHONHTTPSVERIFY=0 detected so we will '
                          'disable requests library SSL verification to keep '
                          'compatibility with older versions.')
            requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
            self._session.verify = False

    def _get_encoded_params(self, params):
        for k, v in params.items():
            if k in [
                    "name", "msg", "short_name", "from_short_name", "to_short_name", "folder_url",
                    "from_folder_url", "to_folder_url", "artifact"
            ]:
                # from six.moves.urllib.parse import quote
                # params[k] = quote(v.encode('utf8'))
                params[k] = v.encode('utf8')
        return params

    def _build_url(self, format_spec, variables=None):
        if variables:
            url_path = format_spec % self._get_encoded_params(variables)
        else:
            url_path = format_spec
        return str(urljoin(self.server, url_path))

    def _maybe_add_auth(self):
        if self._auth_resolved:
            return
        if len(self._auths) == 1:
            # If we only have one auth mechanism specified, just require it
            self._session.auth = self._auths[0][1]
        else:
            # Attempt the list of auth mechanisms and keep the first that works
            # otherwise default to the first one in the list (last popped).
            # This is a hack to allow the transparent use of kerberos to work
            # in future, we should require explicit request to use kerberos
            failures = []
            for name, auth in reversed(self._auths):
                try:
                    self._session.auth = auth
                    break
                except TimeoutException:
                    raise
                except Exception as exc:
                    # assume authentication failure
                    failures.append("auth(%s) %s" % (name, exc))
                    continue
            else:
                raise ClusterScopeException('Unable to authenticate with any scheme:\n%s' %
                                            '\n'.join(failures))
        self._auth_resolved = True
        self.auth = self._session.auth

    def _response_handler(self, response):
        '''Handle response objects'''
        # raise exceptions if occurred
        response.raise_for_status()
        # Response objects will automatically return unicode encoded
        # when accessing .text property
        return response

    def _request(self, req):
        r = self._session.prepare_request(req)
        # requests.Session.send() does not honor env settings by design
        # see https://github.com/requests/requests/issues/2807
        _settings = self._session.merge_environment_settings(r.url, {}, None, self._session.verify,
                                                             None)
        _settings['timeout'] = self.timeout
        return self._session.send(r, **_settings)

    def open(self, req, resolve_auth=False):
        '''Return the HTTP response body from a ``requests.Request``.
        :returns: ``str``
        '''
        return self.request(req, resolve_auth).text

    def request(self, req, resolve_auth=False):
        '''Utility routine for opening an HTTP request to a Jenkins server.
        :param req: A ``requests.Request`` to submit.
        :param add_crumb: If True, try to add a crumb header to this ``req``
                          before submitting. Defaults to ``True``.
        :param resolve_auth: If True, maybe add authentication. Defaults to
                             ``True``.
        :returns: A ``requests.Response`` object.
        '''
        try:
            if resolve_auth:
                self._maybe_add_auth()

            return self._response_handler(self._request(req))
        except req_exc.HTTPError as e:
            # Jenkins's funky authentication means its nigh impossible to
            # distinguish errors.
            if e.response.status_code in [401, 403, 500]:
                msg = 'Error in request. ' + \
                      'Possibly authentication failed [%s]: %s' % (
                          e.response.status_code, e.response.reason)
                if e.response.text:
                    msg += '\n' + e.response.text
                raise ClusterScopeException(msg)
            elif e.response.status_code == 404:
                raise NotFoundException('Requested item could not be found')
            else:
                raise
        except req_exc.Timeout as e:
            raise TimeoutException('Error in request: %s' % (e))
        except Exception as e:
            logging.debug('Error in request: %s' % str(e))
            # python 2.6 compatibility to ensure same exception raised
            # since URLError wraps a socket timeout on python 2.6.
            if str(e.reason) == "timed out":
                raise TimeoutException('Error in request: %s' % (e.reason))
            raise ClusterScopeException('Error in request: %s' % (e.reason))

    """
    ===========================================================================================
    Functions
    ===========================================================================================
    """
    """
    Get cluster scope metadata by node and location

    """

    def instant_meta_data_by_name(self, _nodes=[], _locations=[]):
        rst = []
        nodes = None
        if _nodes:
            nodes = ",".join(_nodes)
        else:
            nodes = ""
        if _locations:
            locations = ",".join(_locations)
        else:
            locations = ""

        try:
            resp = self.open(requests.Request('GET', self._build_url(GET_NODE_METADATA, locals())))
            return json.loads(resp)
        except NotFoundException:
            raise ClusterScopeException('')

    """
    Get Cluster Pools by search
    """

    def instant_query_by_name(self, _nodes=[]):
        rst = []
        nodes = None
        if _nodes:
            nodes = ",".join(_nodes)
        else:
            nodes = ""
        try:
            resp = self.open(requests.Request('GET', self._build_url(QUERY_BY_NODE_NAMES,
                                                                     locals())))
            return json.loads(resp)
        except NotFoundException:
            raise ClusterScopeException('')

    def instant_update_by_name(self, headers={}, data={}):
        # it is not necessary to have this argument nelson@10.2.2023
        # nodes = None
        # if _nodes:
        #     nodes = ",".join(_nodes)
        # else:
        #     nodes = ""
        try:
            resp = self.open(
                requests.Request('POST', self._build_url(UPDATE_NODE_POOL_NAME), headers=headers,
                                 json=data))
            return json.loads(resp)
        except NotFoundException:
            raise ClusterScopeException('')

    def instant_update_pool_by_name(self, headers={}, data={}):
        try:
            resp = self.open(
                requests.Request('POST', self._build_url(UPDATE_NODE_POOL_NAME_ALL),
                                 headers=headers, json=data))
            return json.loads(resp)
        except NotFoundException:
            raise ClusterScopeException('')

    def get_node_action_history(self, variables={}):
        try:
            resp = self.open(
                requests.Request(method='GET', url=self._build_url(GET_NODE_ACTION_HISTORY,
                                                                   locals()), params=variables))
            return json.loads(resp)
        except NotFoundException:
            raise ClusterScopeException('')

    def instant_query_by_pool(self, _poolnames=[]):
        rst = []
        nodes = None
        if _poolnames:
            pool_names = ",".join(_poolnames)
        else:
            pool_names = ""
        try:
            resp = self.open(requests.Request('GET', self._build_url(QUERY_BY_POOL_NAMES,
                                                                     locals())))
            return json.loads(resp)
        except NotFoundException:
            raise ClusterScopeException('')

    def get_memory_detail_by_nodename(self, _location="", _node=""):
        rst = []
        if _location:
            location = _location
        else:
            location = ""
        if _node:
            node_name = _node
        else:
            node_name = ""
        try:
            resp = self.open(
                requests.Request('GET', self._build_url(GET_NODE_MEMORY_DETAIL, locals())))
            return json.loads(resp)
        except NotFoundException:
            raise ClusterScopeException('')
