# Connectors - ClusterScope
The ClusterScope supports the metadata of SUTs, composed of poolname, cpu, stepping, desc, owner in idsid, locations.
