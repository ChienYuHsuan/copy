import logging
import os
import sys
import time
from datetime import datetime, timedelta

import fire
import pymsteams
from ratelimit import limits, sleep_and_retry

import asv_pipeline.clusterscope.handler as cshandler
import asv_pipeline.clusterscope.poolname as cspoolname
from asv_pipeline.clusterscope import ClusterScopeException

LINK = "https://intel.webhook.office.com/webhookb2/f9eecb46-3863-46e2-ad81-83e072088803@46c98d88-e344-4ed4-8496-4ed7712e255d/IncomingWebhook/bb8eb2fb21f34b95905cd84f23b59bc0/2c701de6-e35f-46dd-82fa-69aed1d40324"
PERIOD = 30
MAX_CALLS_PER_PERIOD = 60

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.DEBUG)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
sys.path.insert(0, ROOT)
"""
1. Create an initial timestamp when Jenkins job start
2. In while true loop (end when no SUT in monitor list)
   for every SUT in monitor list, get the last 1 action history 
   between the initial timestamp and now timestamp from ClusterScope
3. If has history, check the new poolname’s 
   assignto is not INF and state is RDY, add to ready list
4. Remove the RDY node from monitor list
5. For SUT in ready list, send message via Teams
6. When every suts are done, mail to trigger from Jenkins
"""


@sleep_and_retry
@limits(calls=MAX_CALLS_PER_PERIOD, period=PERIOD)
def send_teams_messages(suts):

    myTeamsMessage = pymsteams.connectorcard(LINK)
    myTeamsMessage.text("<pre>" + "<br>".join(suts) + "</pre>")

    try:
        if myTeamsMessage.send():
            logger.info("Send message to channel %s successfully" % (LINK))
    except Exception:
        logger.warning("Send Teams message failure.")


def monitor_poolname(*suts, pollsec=300, monitordays=14):
    if suts:
        start_date = (datetime.utcnow() - timedelta(1)).strftime('%Y-%m-%d')
        remainsec = 86400 * monitordays
        monitor_suts = list(suts)
        logger.info("Start monitor poolName of %s ", ' '.join(monitor_suts))

        while len(monitor_suts) != 0 and remainsec >= 0:
            ready_suts = []
            curr_date = (datetime.utcnow() + timedelta(1)).strftime('%Y-%m-%d')

            for sut in list(monitor_suts):
                try:
                    node_action_history = cshandler.get_action_history_by_node(
                        sut, 5, start_date, curr_date, 120)

                    if node_action_history:
                        newPoolName = cspoolname.parse(
                            node_action_history[0]["newPoolName"].strip())
                        logger.debug("sut = " + sut + ", newPoolName = " + str(newPoolName))

                        if newPoolName.asignto != "INF" and newPoolName.state == "RDY":
                            logger.info("READY, remove from monitor and notify by TEAMS, node=%s",
                                        sut)
                            ready_suts.append(sut)
                            monitor_suts.remove(sut)
                    else:
                        logger.debug("No action history between %s~%s, node=%s", start_date,
                                     curr_date, sut)
                except (ClusterScopeException, Exception):
                    logger.error("Can't get info from ClusterScope, node=%s", sut)

            if ready_suts:
                send_teams_messages(ready_suts)

            time.sleep(pollsec)
            remainsec -= pollsec

        if remainsec < 0:
            logger.info("Monitor TIMEOUT, remain %s not ready", monitor_suts)
            sys.exit(2)
        else:
            logger.info("All nodes READY!")
    else:
        logger.error("No SUTs to monitor")
        sys.exit(1)


if __name__ == '__main__':
    fire.Fire(monitor_poolname)
    # s = ["r04s15.op20lmain3", "r014s001.zp31l10b01"]
    # send_teams_messages(s)
