import logging
import re

logging = logging.getLogger(__name__)


def errordump(ctx):
    START = False
    rst = {}
    key, severity, signal, desc = None, None, None, None
    for line in ctx.split("\n"):
        if re.search(r'#* Dumping MC Banks Data: #*', line):
            START = True
            continue
        if re.search(r'NO MCA ERROR Found', line):
            return {}
        if re.search(r'MCA ERROR INFO:', line):
            break
        if START:
            match_key = re.match(r'.*Error Target\s?=\s?(.*)]', line)
            key = match_key.group(1) if match_key else key
            match_severity = re.match(r'.*Error_Severity\s*\=\s*(.*)]', line)
            severity = match_severity.group(1) if match_severity else severity
            match_signal = re.match(r'.*Interrupt_Signal\s*=\s*(.*)]', line)
            signal = match_signal.group(1) if match_signal else signal
            match_desc = re.match(r'.*Error_Description\s*=\s*(.*)]', line)
            desc = match_desc.group(1) if match_desc else desc
            if key and severity and signal and desc:
                rst[f'{key}_{signal}'] = {
                    "target": key,
                    "severity": severity,
                    'signal': signal,
                    'desc': desc
                }
                key, severity, signal, desc = None, None, None, None
    logging.info(rst)
    return rst
