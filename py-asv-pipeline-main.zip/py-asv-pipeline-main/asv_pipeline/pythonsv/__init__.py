"""
PythonSV module
It will connect to particular node using PythonSV in interactive mode
The message shows like the following. 

Info - Detected EBG B1 on JTAG chain 1 at position 0
PythonSv - INFO: Not running in Simics
Python 3.6.8 (default, Nov 16 2020, 16:55:22) 
[GCC 4.8.5 20150623 (Red Hat 4.8.5-44)] on linux
 PythonSv running in interactive mode
"""
# if sys.version_info.major == 3 and sys.version_info.minor < 9
from __future__ import annotations

import logging
import os
import re
import sys
import time
import warnings

import pexpect

from asv_pipeline.clusterscope import handler
from asv_pipeline.util import (expect_handler, fully_ansi_escape, get_cluster_by_naming,
                               rem_nonprintable_ctrl_chars)

# from typing import List, Tuple

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.DEBUG)
sys.path.insert(1, os.path.abspath('.'))
warnings.filterwarnings("ignore", category=DeprecationWarning)


class PythonSV(object):

    def __init__(self, cluster, idsid=None, cpu=None):
        self._cluster = cluster
        self.eb = expect_handler.sysman(cluster, idsid, cpu)
        self.rst = []

    def terminate(self):
        self.eb.sendcontrol('C')
        self.eb.expect([pexpect.EOF, pexpect.TIMEOUT], timeout=10)
        rst = ''
        try:
            rst = self.eb.before.decode()
        except Exception:
            rst = rem_nonprintable_ctrl_chars(self.eb.before)
        finally:
            try:
                rst = fully_ansi_escape(rst)
                logging.info("clean up ansi code")
            except Exception as e:
                logging.warning(e)
            logging.debug(rst)

        self.eb.sendcontrol('C')
        cnt = 300
        # we try 10 mins
        while self.eb.expect(['>>>', pexpect.TIMEOUT, '(srf_venv)', '/ASD_connections'],
                             timeout=2) and cnt:
            cnt -= 1
            self.eb.sendcontrol('C')
            time.sleep(0.5)
        if cnt == 0:
            raise Exception("Try to terminate the IPC but fail")
        logging.info("+" * 63)
        logging.info(rst)
        return rst

    def close(self):
        self.eb.sendline('exit()')
        self.eb.sendline('mission_complete()')
        self.eb.expect([
            '>>> exit', 'OpenIPC Conn Closed', '[C.Tools]: OpenIPC',
            "name 'mission_complete' is not defined", pexpect.EOF
        ])
        rst = ""
        if self.eb.before:
            try:
                rst = self.eb.before.decode()
            except Exception:
                rst = rem_nonprintable_ctrl_chars(self.eb.before)
            finally:
                try:
                    rst = fully_ansi_escape(rst)
                    logging.info("clean up ansi code")
                except Exception as e:
                    logging.error(e)
            logging.debug(rst)
        try:
            for i in range(5):
                self.eb.sendcontrol('D')
            self.eb.expect([pexpect.EOF, 'closed', 'logout', '.*\$'], timeout=600)  # noqa: W605
        except Exception as e:
            logging.error(e)
        final_rst = "\n".join(self.rst) + rst
        logging.debug("\n".join(self.rst))
        logging.debug(rst)
        return final_rst

    def series(self, act_exps: list[object], timeout=600) -> list[str]:
        """
        series. Giving a series actions in order with your expected response respectively
        :param List[list] act_exp, [act, [correct msg], [error msg]] execute the action and get the expected result
        :return List[str]
        """
        if not act_exps:
            return self
        self.eb.sendline("\r\n")
        for act_exp in act_exps:
            self.eb.sendline(act_exp[0])
            if len(act_exp) > 1:
                correct_msg, err_msg = [], []
                if isinstance(act_exp[1], list):
                    correct_msg += act_exp[1]
                elif isinstance(act_exp[1], str):
                    correct_msg += [act_exp[1]]
                if len(act_exp) == 3 and act_exp[2]:
                    if isinstance(act_exp[2], list):
                        err_msg += act_exp[2]
                    elif isinstance(act_exp[2], str):
                        err_msg += [act_exp[2]]
                ret = self.eb.expect(correct_msg + err_msg, timeout=timeout)
                if ret >= len(correct_msg):
                    tmp = correct_msg + err_msg
                    error = f'Error takes place on pattern:[{tmp[ret]}]'
                    raise Exception(error)
            self.rst += [rem_nonprintable_ctrl_chars(self.eb.before)]
        if self.rst:
            logging.debug(self.rst)
        return self

    # for sierraforest, it takes more than 300 seconds to bootup. Therefore, we change to 600
    def _target(self, node, timeout=600):
        self.eb.timeout = timeout
        self.eb.sendline('launch_remote_ipc ' + node)
        # self.eb.expect('PythonSv running in interactive mode')
        pattern = [
            'ASD failed to connect to',
            'OpenIPC Conn Closed',
            'OpenIPC failed to initialize',
            '>>>\s+'  # noqa: W605
        ]
        ret = self.eb.expect(pattern)
        logging.debug(self.eb.before)
        if ret == len(pattern) - 1:
            return self
        else:
            err = f'[{pattern[ret]}] error happens'
            raise Exception(err)

    def target(self, node, timeout=600, cpu=None):
        if not cpu:
            cpu = handler.get_cpu([node])[node]
        return self.target_test(node, timeout, cpu)

    def target_test(self, node, timeout=600, cpu=None):
        self.eb.timeout = timeout
        cluster = get_cluster_by_naming(node)
        if cpu and re.search(r'CWF', cpu.upper()):
            if cluster == 'bhs':
                self.eb.sendline(f'launch_remote_ipc_test -M {node}')
            else:
                self.eb.sendline(f'launch_remote_ipc -M {node}  -f cwf')
        elif cpu and re.search(r'ICX', cpu.upper()):
            self.eb.sendline(f'launch_remote_ipc {node}')
        else:
            self.eb.sendline('launch_remote_ipc_test -M ' + node)
        # self.eb.expect('PythonSv running in interactive mode')
        pattern = [
            'ASD failed to connect to',
            "python3: can't open file .* \[Errno 2] No such file or directory",  # noqa: W605
            'OpenIPC Conn Closed',
            'Someone is running Remote OpenIPC on this node',
            'OpenIPC failed to initialize',
            '>>>\s+'  # noqa: W605
        ]
        ret = self.eb.expect(pattern)
        logging.debug(self.eb.before)
        if ret == len(pattern) - 1:
            return self
        else:
            err = f'[{pattern[ret]}] error happens'
            raise Exception(err)

    def cscript(self, node, timeout=600):
        self.eb.timeout = timeout
        self.eb.sendline(f"launch_remote_ipc -M {node} --cscripts")
        pattern = [
            'ASD failed to connect to',
            'OpenIPC Conn Closed',
            'OpenIPC failed to initialize',
            # '[\r\n]+Cscripts version:',
            'Socket Read Wait Failure',
            'Entered project is not supported',
            "NameError: name 'error' is not defined",
            'command not found',
            'You may attempt to reinitialize CScripts',
            '>>>\s+'  # noqa: W605
        ]
        ret = self.eb.expect(pattern)
        logging.debug(self.eb.before)
        if ret == len(pattern) - 2:
            self.eb.sendline("init_cscripts()")
            _pattern = ['Socket Read Wait Failure.', 'OpenIPC failed to initialize',
                        '>>>\s+']  # noqa: W605
            _ret = self.eb.expect(pattern)
            if _ret == len(_pattern) - 1:
                return self
            else:
                err = f'[{_pattern[_ret]}] error happens'
                raise Exception(err)
        elif ret == len(pattern) - 1:
            return self
        else:
            err = f'[{pattern[ret]}] error happens'
            raise Exception(err)
