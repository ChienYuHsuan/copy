import logging
import os
import sys

import pexpect

from asv_pipeline.util import expect_handler

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.DEBUG)
sys.path.insert(1, os.path.abspath('.'))


class CSCript(object):

    def __init__(self, cluster, idsid=None, cpu=None):
        self._cluster = cluster
        self.eb = expect_handler.sysman(cluster, idsid, cpu)

    def close(self):
        self.eb.timeout = 30
        self.eb.sendline('exit()')
        self.eb.sendcontrol('D')
        self.eb.expect(['(cscripts_venv)', pexpect.EOF, r'closed'], timeout=30)
        logging.debug(self.eb.before)
        return self.eb.before

    def series(self, act_exps: list[list], timeout=600) -> list[str]:
        """
        series. Giving a series actions in order with your expected response respectively
        :param List[Tuple] act_exp, (act,exp) execute the action and get the expected result
        :return List[str]
        """
        rst = []
        if not act_exps:
            return self
        for act_exp in act_exps:
            self.eb.sendline(act_exp[0])

            if len(act_exp) > 1:
                correct_msg, err_msg = [], []
                if isinstance(act_exp[1], list):
                    correct_msg += act_exp[1]
                elif isinstance(act_exp[1], str):
                    correct_msg += [act_exp[1]]
                if len(act_exp) == 3 and act_exp[2]:
                    if isinstance(act_exp[2], list):
                        err_msg += act_exp[2]
                    elif isinstance(act_exp[2], str):
                        err_msg += [act_exp[2]]
                ret = self.eb.expect(correct_msg + err_msg, timeout=timeout)
                if ret >= len(correct_msg):
                    tmp = correct_msg + err_msg
                    error = f'Error takes place on pattern:[{tmp[ret]}]'
                    raise Exception(error)
            rst += [self.eb.before]
        logging.debug(rst)
        return self

    def target(self, node, timeout=300):
        self.eb.timeout = timeout
        self.eb.sendline("activate_cscripts")
        rst = self.eb.expect([r"\(.*\)\s+", r"command not found"])
        if rst == 1:
            logging.error("activate_cscripts: Command not found")
            raise Exception("Command not found")
        self.eb.sendline('launch_cscripts ' + node)
        rst = self.eb.expect([
            r"[\r\n]+Cscripts version:", r"You may attempt to reinitialize CScripts",
            r"Socket Read Wait Failure", r"Entered project is not supported", r'command not found'
        ])
        if rst == 1:
            self.eb.sendline("init_cscripts()")
            ret = self.eb.expect([
                r"[\r\n]+Cscripts version:", r" Socket Read Wait Failure.",
                r"OpenIPC failed to initialize"
            ])
            if ret == 1:
                logging.error("socket read wait failure")
                raise Exception("socket read wait failure")
            if ret == 2:
                raise Exception("fail to initialize")
        elif rst == 2:
            logging.error("socket read wait failure")
            raise Exception("socket read wait failure")
        elif rst == 3:
            logging.error("Entered project is not supported")
            raise Exception("Entered project is not supported")
        elif rst == 4:
            logging.error("launch_cscripts: Command not found")
            raise Exception("Command not found")
        return self
