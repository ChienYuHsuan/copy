import os
import pathlib
import sys

import pytest

os.chdir(pathlib.Path.cwd() / 'asv_pipeline/tests')
sys.path.insert(1, os.path.abspath('../..'))
print(sys.argv[1:])
pytest.main(sys.argv[1:])
