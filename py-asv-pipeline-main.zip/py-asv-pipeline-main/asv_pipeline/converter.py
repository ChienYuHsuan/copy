"""
the converter would help you to convert the input data into sut list in json|bash|python array format
the input data can be typed one by one, or directly provide any sequence concated by ","


usage:
example 1: giving 
r003s006.zp31l10b01,r008s019.zp31l10b01
r012s005.zp31l10b01
r012s016.zp31l10b01
r014s002.zp31l10b01
r004s020.zp31l10b01
r004s002.zp31l10b01

Result:
["r003s006.zp31l10b01", "r008s019.zp31l10b01", "r012s005.zp31l10b01", "r012s016.zp31l10b01", "r014s002.zp31l10b01", "r004s020.zp31l10b01", "r004s002.zp31l10b01"]

example 2: giving
r003s006.zp31l10b01
r008s019.zp31l10b01
r012s005.zp31l10b01
r012s016.zp31l10b01
r014s002.zp31l10b01
r004s020.zp31l10b01
r004s002.zp31l10b01

Result:
["r003s006.zp31l10b01", "r008s019.zp31l10b01", "r012s005.zp31l10b01", "r012s016.zp31l10b01", "r014s002.zp31l10b01", "r004s020.zp31l10b01", "r004s002.zp31l10b01"]
"""
import json
import re
import sys

pattern_quota = r'\'|\"'
pattern_split_comma = r','
pattern_split_semi = r';'
pattern_split_space = r'\s+'


def main():
    is_bash_format = False
    is_python_format = False
    is_airflow_format = False
    print(sys.argv)
    if len(sys.argv) > 1:
        print("=" * 63)
        if 'bash' == sys.argv[1]:
            is_bash_format = True
        elif 'python' == sys.argv[1]:
            is_python_format = True
        elif 'airflow' == sys.argv[1]:
            is_airflow_format = True
    print("please type the sut one by one or directly input the list")
    print("after finishing all data, pressing ctrl+D to get the result")
    lines = sys.stdin.readlines()
    data = []
    for line in lines:

        if re.search(pattern_quota, line):
            line = re.sub(pattern_quota, "", line)
        if re.search(pattern_split_comma, line):
            data += re.split(r',', line)
        elif re.search(pattern_split_semi, line):
            data += re.split(r';', line)
        elif re.search(pattern_split_space, line):
            data += re.split(r'\s+', line)
        else:
            data += [line]
    for i, x in enumerate(data):
        x = x.strip()
        if x:
            data[i] = x
    if is_bash_format:
        print('"%s"' % " ".join(data))
    elif is_python_format:
        print('%s' % ",".join(data))
    elif is_airflow_format:
        print('"%s"' % '","'.join(data))
    else:
        print(json.dumps(data))


if __name__ == "__main__":
    main()
