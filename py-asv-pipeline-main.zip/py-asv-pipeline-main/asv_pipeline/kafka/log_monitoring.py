import time

import asv_pipeline.config as cfg
from asv_pipeline.kafka import KafkaConsumer


def log_monitoring(cluster, groupid, auto_offset, topic, msg_process):
    consumer = KafkaConsumer(brokers=cfg.kafka_brokers[cluster], groupid=groupid,
                             auto_offset=auto_offset, topic=topic)
    consumer.consume_message(msg_process=msg_process)


def log_process(msg):
    host = ''

    if 'hostname' in msg['metadata']['cscope']:
        host = msg['metadata']['cscope']['hostname']
    elif 'name' in msg['metadata']['cscope']:
        host = msg['metadata']['cscope']['name']
    else:
        pass
    print(host, msg)


if __name__ == "__main__":
    # use new group id and set offset to latest to get latest message
    log_monitoring('icx-1', 'gid-%s' % (time.time()), 'latest', 'atscale', log_process)
