import json
import logging
import sys

from confluent_kafka import Consumer, KafkaError, KafkaException

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class KafkaConsumer(object):

    def __init__(self, brokers, groupid, auto_offset, topic):
        self.consumer = Consumer({
            'bootstrap.servers': brokers,
            'group.id': groupid,
            'auto.offset.reset': auto_offset
        })
        self.consumer.subscribe([topic])

    def consume_message(self, msg_process, timeout=1.0):
        running = True
        try:
            while running:
                msg = self.consumer.poll(timeout=timeout)
                if msg is None:
                    print("No message")
                    continue

                if msg.error():
                    if msg.error().code() == KafkaError._PARTITION_EOF:
                        # End of partition event
                        sys.stderr.write('%% %s [%d] reached end at offset %d\n' %
                                         (msg.topic(), msg.partition(), msg.offset()))
                        logger.error('%% %s [%d] reached end at offset %d\n' %
                                     (msg.topic(), msg.partition(), msg.offset()))
                    elif msg.error():
                        logger.error(msg.error())
                        raise KafkaException(msg.error())
                    running = False
                else:
                    try:
                        decoded_msg = msg.value().decode('utf-8')
                        data = json.loads(decoded_msg)
                        msg_process(data)
                    except Exception as e:
                        logger.error(str(e))
        finally:
            # Close down consumer to commit final offsets.
            self.consumer.close()
