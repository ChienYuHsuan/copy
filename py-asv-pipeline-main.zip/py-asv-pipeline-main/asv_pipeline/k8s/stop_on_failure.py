"""
Remove SUTs once there are critical error log recorded in ES
"""

import os
from datetime import datetime

import asv_pipeline.config as cfg
from asv_pipeline.es import ES
from asv_pipeline.k8s import Kubernetes

REMOVE_LABEL_FROM_NODE = "kubectl %(kubeconfig)s --insecure-skip-tls-verify label node/%(node)s %(label)s-"
GET_NODE_WITH_LABEL = "kubectl %(kubeconfig)s get node -l %(label)s -o=custom-columns=\"NAME:.metadata.name\" --no-headers"

system_under_test = []
keyoword_table = [
    'not ok', 'TSC warp', 'TSC unstable', 'downgraded', 'coredump', 'TSC found unstable',
    'REBOOT COUNT', 'REBOOT TYPE', 'Correctable errors'
]

if __name__ == "__main__":
    k8s = Kubernetes()
    out = k8s.cmd(GET_NODE_WITH_LABEL % {
        "kubeconfig": os.environ['KUBECONFIG'],
        "label": os.environ['JENKINS_NODE_LABEL']
    })
    for n in out:
        system_under_test.append(n)

    _cluster = os.environ['KUBECONFIG'].split(".")[-1]
    _begin = os.environ['START']
    _end = os.environ['END']
    begin = datetime.strptime(_begin, '%a %b %d %H:%M:%S %Z %Y')
    end = datetime.strptime(_end, '%a %b %d %H:%M:%S %Z %Y')
    es = ES(url=cfg.es_endpoints[_cluster], name=cfg.es_username[_cluster],
            password=cfg.es_password[_cluster]).index("qpool-*")
    body = es.oneOf('kubernetes.host', system_under_test) \
             .oneOf('log', keyoword_table) \
             .range(begin, end).build()
    rst = es.execute(timeout=600, payload=body)

    removed_host = []
    for doc in rst:
        if 'kubernetes' in doc['_source'].keys():
            removed_host.append(doc['_source']['kubernetes']['host'])
        else:
            removed_host.append(doc['_source']['hostname'])

    print("Total nodes:", len(set(removed_host)))
    print("Node list to be removed:", set(removed_host))

    for h in removed_host:
        k8s.cmd(
            REMOVE_LABEL_FROM_NODE % {
                "kubeconfig": os.environ['KUBECONFIG'],
                "node": h,
                "label": os.environ['JENKINS_NODE_LABEL']
            })
