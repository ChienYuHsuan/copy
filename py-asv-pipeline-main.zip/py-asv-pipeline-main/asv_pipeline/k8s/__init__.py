import re
import subprocess
from dataclasses import asdict, dataclass


class Kubernetes(object):

    def __init__(self):
        self.data = []

    def cmd(self, args):
        out = []
        try:
            args = filter(args)
            # process  = subprocess.Popen(args.split(), stdout=subprocess.PIPE)
            proc = subprocess.Popen(args, shell=True, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, universal_newlines=True)

            # out,err = proc.communicate()
            # print(out)
            while True:
                line = proc.stdout.readline()
                if not line:
                    break
                out += [line.rstrip()]
            # for entry in out:
            #     print(entry)
        except Exception:
            pass
        return out


@dataclass
class Pod(object):
    name: str
    ns: str
    life: str
    status: str
    ip: str
    node: str

    # def __init__(self, name=None, ns=None, life=None, status=None, ip=None, node=None):
    #     self.name = name
    #     self.ns = ns
    #     self.life = life
    #     self.status = status
    #     self.ip = ip
    #     self.node = node

    def __str__(self):
        return "%s|%s|%s|%s|%s" % (self.ns, self.node, self.name, self.status, self.life)

    def serialize(self):
        return asdict(self)

    @classmethod
    def deserialize(cls, data):
        return cls(**data)


class Node(object):

    def __init__(self, name=None, status=None, life=None, labels=None):
        self.name = name
        self.status = status
        self.life = life
        self.labels = labels

    def __str__(self):
        return "%s|%s|%s|%s" % (self.name, self.status, self.life, ",".join(self.labels))

    def has_label(self, key):
        for label in self.labels:
            if key.lower() in label.split("=")[0]:
                return True
        return False


def filter(args):
    """
    protect the input data, avoiding malicious data to attach the systems. 
    However, we couldn't cover it all at the moment.
    In the future, we can change the args as whitelist pattern.
    """
    if re.search(r'^kubectl\s+|^kc\s+|^k\s+', args):
        return args
    else:
        return ""
