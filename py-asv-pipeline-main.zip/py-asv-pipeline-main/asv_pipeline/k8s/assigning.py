import os
import sys

import asv_pipeline.config as cfg
from asv_pipeline.clusterscope import handler
from asv_pipeline.k8s import Kubernetes, Node
from asv_pipeline.util import str2labels

p = os.path.abspath('.')
sys.path.insert(1, p)

GET_NODES_WITH_NOREADY = "kubectl --kubeconfig=%s --insecure-skip-tls-verify get nodes --show-labels | grep NotReady"

if __name__ == "__main__":
    _kubeconfigs = list(cfg.kubeconfigs.values())
    _patterns = cfg.patterns

    assert len(_kubeconfigs) == len(_patterns)
    # if not _kubeconfig:
    #     raise Exception("Please add the kubeconfig")
    #     sys.exit(1)

    # if not _pattern:
    #     raise Exception("Please add pattern to filter out")
    #     sys.exit(1)
    # ===========================
    # CHANGE original logics into accept all kubes
    # ===========================
    k8s = Kubernetes()
    mp = {}
    for i in range(len(_kubeconfigs)):
        _kubeconfig, _pattern = _kubeconfigs[i].strip(), _patterns[i].strip()
        out = k8s.cmd(GET_NODES_WITH_NOREADY % (_kubeconfig))
        cluster = _kubeconfig.split(",")[-1]
        # get all nodes with NotReady

        for x in out:
            A = x.split()
            node = Node(A[0], A[1], A[3], str2labels(A[5]))
            mp[node.name] = node

    # we won't pass the nodes' name, because clusterscope query
    # api adopts GET, and length of URL has limitation depended
    # on the configuration from the client or server.
    # Therefore, we query nodes all, and filter out them later.
    #
    # Here, I don't adopt the func.
    # TODO : the main pipeline probably doesn't have idsid label,
    # so we need to take this situation into account.
    pools, noassgined = handler.get_pool_by_nodes()

    import csv

    data = []
    for k, v in mp.items():
        entry = {}
        entry['name'] = k
        entry['status'] = v.status
        entry['is_assigned_correctly'] = False
        entry['pool'] = "N/A"
        entry['idsid'] = "N/A"
        if k in pools:
            entry['pool'] = pools[k].pool
            entry['idsid'] = pools[k].idsid
            if v.has_label(pools[k].idsid):
                entry['is_assigned_correctly'] = True
        data += [entry]

    with open('notreadynode.csv', 'w', encoding='UTF8', newline='') as f:
        writer = csv.DictWriter(
            f, fieldnames=['name', 'status', 'pool', 'idsid', 'is_assigned_correctly'])
        writer.writeheader()
        writer.writerows(data)

    with open('unknow.csv', 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(
            f, fieldnames=['name', 'status', 'pool', 'idsid', 'is_assigned_correctly'])
        data = []
        for k, v in noassgined.items():
            entry = {}
            entry['name'] = k
            entry['status'] = "N/A"
            entry['is_assigned_correctly'] = False
            entry['idsid'] = "N/A"
            entry['pool'] = noassgined[k]
            data += [entry]
        writer.writeheader()
        writer.writerows(data)
