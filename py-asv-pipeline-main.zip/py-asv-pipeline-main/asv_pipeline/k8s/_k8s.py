from kubernetes import client, config

config.load_kube_config(config_file='~/workspace/kubeconfig/config.icx-1')

v1 = client.CoreV1Api()

thread = v1.list_node(async_req=True)

rst = thread.get()
# for x in rst:
#     print("%s\t%s" %
#         x.metadata.name)
#     print(x.metadata.labels)
print(rst.items[0])
