"""
Helper functions in K8s
"""
# if sys.version_info.major == 3 and sys.version_info.minor < 9
from __future__ import annotations

import logging

from asv_pipeline.k8s import Kubernetes

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

REMOVE_LABEL_FROM_NODE = "kubectl {kube} --insecure-skip-tls-verify label node/{node} {label}-"
DELETE_NS = "kubectl {kube} --insecure-skip-tls-verify delete ns/{ns}"
GET_POD_IN_NS = "kubectl {kube} --insecure-skip-tls-verify get po -n {ns}"


def unlabel(nodes, kubeconfig, label):
    """
    Removes a specified label from multiple Kubernetes nodes using the provided kubeconfig.

    Parameters:
    nodes (list of str): A list of node names from which the label will be removed.
    kubeconfig (str): The path to the kubeconfig file.
    label (str): The label to be removed from the nodes.

    Returns:
    None
    """
    if not all([kubeconfig, label]):
        log.warning(f"Invalid Kubeconfig or label: ({kubeconfig}, {label})")
        return

    k8s = Kubernetes()
    for node in nodes:
        cmd = REMOVE_LABEL_FROM_NODE.format(kube=kubeconfig, node=node, label=label)
        log.info(f"Remove label {label} from node {node}")
        try:
            k8s.cmd(cmd)
        except Exception as e:
            log.error(f"Failed to remove label {label} from node {node}: {e}")


def del_ns(kubeconfig, ns):
    """
    Deletes a specified Kubernetes namespace using the provided kubeconfig.

    Parameters:
    kubeconfig (str): The path to the kubeconfig file.
    ns (str): The name of the namespace to be deleted.

    Returns:
    None
    """
    if not all([kubeconfig, ns]):
        log.warning(f"Invalid Kubeconfig or namespace: ({kubeconfig}, {ns})")
        return

    k8s = Kubernetes()
    cmd = GET_POD_IN_NS.format(kube=kubeconfig, ns=ns)
    try:
        res = k8s.cmd(cmd)
    except Exception as e:
        log.error(f"Failed to get pod in namespace {ns}: {e}")

    # Only delete NS if there is no pod running on it
    if 'No resources found' in res:
        cmd = DELETE_NS.format(kube=kubeconfig, ns=ns)
        log.info(f"Delete namespace {ns}")
        try:
            k8s.cmd(cmd)
        except Exception as e:
            log.error(f"Failed to delete namespace {ns}: {e}")
    else:
        log.info(f"There are pods runing in {ns}. Skip deleting it.")
