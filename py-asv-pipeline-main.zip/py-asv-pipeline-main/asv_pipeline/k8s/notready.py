import logging
import os
import sys
import time
from datetime import datetime

import asv_pipeline.clusterscope.handler as handler
import asv_pipeline.config as cfg
from asv_pipeline.auto_messages import send_teams_message_thu_workflow, send_teams_messages
from asv_pipeline.clusterscope import ClusterScope
from asv_pipeline.es import es_handler
from asv_pipeline.k8s import Kubernetes, Node, Pod
from asv_pipeline.sharepoint.check_dpmo import (get_dpmo_list, push_dpmo_to_es,
                                                send_dpmo_results_to_teams,
                                                send_teams_messages_dpmo)
from asv_pipeline.sharepoint.update_notready import clean_nrn_report, update_notready_sheet
from asv_pipeline.tasks.elasticsearch.es_not_ready_reporting import (change_pythonsv_readiness,
                                                                     prepare_data_for_dpmo,
                                                                     prepare_data_for_nrn,
                                                                     push_notready_nodes_into_index,
                                                                     push_nrn_into_index)
from asv_pipeline.util import (display_not_ready_by_cluster, display_not_ready_by_ns, is_older,
                               str2labels, trigger_dag)

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logging.getLogger('elasticsearch').setLevel(logging.WARNING)
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

p = os.path.abspath('.')
sys.path.insert(1, p)

GET_NOTREADY_NODES_WITH_LABEL = "kubectl --kubeconfig=%(kube)s --insecure-skip-tls-verify get nodes -l=%(label)s=true | grep NotReady"
GET_ALL_LAVID_NS = "kubectl --kubeconfig=%s --insecure-skip-tls-verify get ns -o=custom-columns=NAME:.metadata.name --no-headers | grep -v -E 'dev|dbg|misc'"
GET_ALL_PODS_IN_NAMESPACES_BY_NODE = "kubectl --kubeconfig=%(kube)s --insecure-skip-tls-verify get pod -n %(ns)s -owide | grep %(node)s"
REMOVE_LABEL_FROM_NODE = "kubectl --kubeconfig=%(kube)s --insecure-skip-tls-verify label node/%(node)s %(label)s-"
DELETE_NS = "kubectl --kubeconfig=%(kube)s --insecure-skip-tls-verify delete ns/%(ns)s"


def filter_nodes(rst, nodes_to_skip):
    log.debug("Nodes %s need to be skipped" % nodes_to_skip)
    filtered_rst = {}
    for ns, pods in rst.items():
        log.debug("pods %s" % pods)
        # Filter out pods where the node is in nodes_to_skip
        filtered_pods = [pod for pod in pods if pod.node not in nodes_to_skip]
        filtered_rst[ns] = filtered_pods

    log.debug("filtered_rst %s" % filtered_rst)
    return filtered_rst


if __name__ == "__main__":
    import getopt
    import sys

    # handle the args & options
    opts, args = getopt.getopt(sys.argv[1:], "p:k:c:h:m:", "dry-run")

    _kubeconfigs = list(cfg.kubeconfigs.values())
    _patterns = cfg.patterns
    _is_dry_run = False
    _cpu = 'spr'
    _hour, _min = 0, 0
    if opts:
        for o, a in opts:
            if o in ["-p", "--prefix"]:
                _patterns = [a]
            if o in ["-k", "--kubeconfig"]:
                _kubeconfigs = [a]
            if o in ["--dry-run"]:
                _is_dry_run = True
            if o in ["-c"]:
                _cpu = a
            if o in ["-h"]:
                _hour = a
            if o in ["-m"]:
                _min = a

    # ===========================
    # CHANGE original logics into accept all kubes
    # ===========================
    k8s = Kubernetes()
    rst, mp, nodes = {}, {}, {}
    rm_label_cmds, del_ns_cmds = set(), set()
    for i in range(len(_kubeconfigs)):
        _kubeconfig = _kubeconfigs[i].strip()

        _cluster = _kubeconfig.split(".")[-1]
        """
        for x in out:
            A = x.split()
            node = Node(A[0], A[1], A[3], str2labels(A[5]))
            mp[node.name] = node
        """

        # get all ns
        out = k8s.cmd(GET_ALL_LAVID_NS % (_kubeconfig))

        for ns in out:
            if not ns.startswith(_cpu) or (_cpu == 'srf' and ns.startswith('srf-ap')):
                continue

            nodes_notready = k8s.cmd(GET_NOTREADY_NODES_WITH_LABEL % {
                "kube": _kubeconfig,
                "label": ns
            })
            if 'No resources found' in nodes_notready:
                continue

            for node in nodes_notready:
                A = node.split()
                n = Node(A[0], A[1], A[3], str2labels(ns))
                x = k8s.cmd(GET_ALL_PODS_IN_NAMESPACES_BY_NODE % {
                    "kube": _kubeconfig,
                    "ns": ns,
                    "node": n.name
                })
                if not x or "No resources found" in x[0] or "Unable to connect to the server" in x[
                        0]:
                    log.info("[DEBUG]: No resources found in %s" % n.name)
                    if ns not in rst:
                        rst[ns] = []
                    rst[ns] += [Pod(name='NA', ns=ns, life='NA', status='NA', ip='NA', node=n.name)]

                    if _cluster not in nodes:
                        nodes[_cluster] = set()
                    nodes[_cluster].add(n.name)
                    rm_label_cmds.add(REMOVE_LABEL_FROM_NODE % {
                        "kube": _kubeconfig,
                        "node": n.name,
                        "label": ns
                    })
                    continue

                A = x[0].split()
                if '(' in A[4]:
                    pod = Pod(A[0], ns, A[6], A[2], A[7], A[8])
                else:
                    pod = Pod(A[0], ns, A[4], A[2], A[5], A[6])
                if pod.ns in ["monitoring", "mgmt"]:
                    continue
                if any(x in pod.ns for x in ['dev', 'dbg', 'misc']):
                    continue
                """
                check if pod.name contains killer_pod, we need to consider the life span.
                otherwise, we take the node into account immediately.
                """
                if _cpu in pod.ns and ((is_older(pod.life, "6h") and "killer-pod" in pod.name) or
                                       "killer-pod" not in pod.name):
                    if pod.ns not in rst:
                        rst[pod.ns] = []
                    rst[pod.ns] += [pod]

                    if _cluster not in nodes:
                        nodes[_cluster] = set()
                    nodes[_cluster].add(pod.node)
                    rm_label_cmds.add(REMOVE_LABEL_FROM_NODE % {
                        "kube": _kubeconfig,
                        "node": pod.node,
                        "label": pod.ns
                    })
                    del_ns_cmds.add(DELETE_NS % {"kube": _kubeconfig, "ns": pod.ns})

    # Update the pool name from ClusterScope
    log.info("[DEBUG] Results of NRN: %s" % rst)
    log.info("[DEBUG] Start updating pool name: %s" % nodes)
    nodes_to_skip = []
    for _cluster, _nodes in nodes.items():
        res, noassigned = handler.get_pool_by_nodes(_nodes)
        locations = handler.get_location_by_nodes(_nodes)
        states = handler.get_state(_nodes)
        asignto = handler.get_asignto(_nodes)
        cs = ClusterScope(cfg.clusterscopes[_cluster])
        for n in _nodes:
            if n not in res:
                log.debug("Node %s is not in pool %s" % (n, res))
                if (n in states and n in asignto) and (states[n] != 'EXC' or asignto[n] == 'INF' or
                                                       asignto[n] == 'IVE'):
                    log.debug("Node %s is skipped (State: %s, Asign To: %s)" %
                              (n, states[n], asignto[n]))
                    nodes_to_skip.append(n)
                continue
            if res[n].asignto == 'INF' or res[n].asignto == 'IVE' or 'MAINT' in res[
                    n].test_description or res[n].state != 'EXC':
                log.debug("Node %s is skipped due to criteria #1 (%s)" % (n, res[n]))
                nodes_to_skip.append(n)
                continue
            if any(x in res[n].test_description for x in ['NOTREADY', 'HSD']):
                log.debug("Node %s is skipped due to criteria #2 (%s)" % (n, res[n]))
                continue
            workload, phase, pipeline = es_handler.get_burnin_phase(_cluster, n)

            if phase:
                expected_desc = f"{res[n].test_description}-NOTREADY-{phase}"
            else:
                expected_desc = f"{res[n].test_description}-NOTREADY"

            target = "%s_%s_%s_%s_%s_%s_%s" % (res[n].cpu, res[n].stepping, 'PIV', 'NTR',
                                               res[n].subclustername, expected_desc,
                                               cfg.triage_owner[_cpu]['idsid'])
            log.debug("Target pool name for node %s: %s" % (n, target))
            try:
                res[n].update_node(n, locations[n]).update_pool(target)
                handler.update_pool_by_names(cs, res[n])
            except Exception as e:
                log.error("%s, %s" % (n, str(e)))
                continue
    rst = filter_nodes(rst, nodes_to_skip)

    # Get DPMO results
    res_dpmo = get_dpmo_list(_cpu, _hour, _min)
    log.info("res_dpmo %s" % res_dpmo)

    creation_time = datetime.utcnow()

    # Prepare data for NRN and DPMO
    data_nrn = prepare_data_for_nrn(rst, creation_time)
    data_dpmo = prepare_data_for_dpmo(res_dpmo, creation_time)
    logging.info("data_nrn %s" % data_nrn)
    logging.info("data_dpmo %s" % data_dpmo)
    body = data_nrn + data_dpmo

    # Push NRN results to ES
    push_nrn_into_index(_cpu, body)

    # Push status into ES index
    pods = []
    for v in rst.values():
        pods += v
    push_notready_nodes_into_index(pods)
    push_dpmo_to_es(res_dpmo, creation_time)

    # Get node list
    node_list = [pod.node for pods in rst.values() for pod in pods]
    node_list += list(res_dpmo.keys())

    # Trigger DAG event_pythonsv_handler in Airflow to collect PythonSV logs
    try:
        if _cpu == 'srf' or _cpu == 'gnr' or _cpu == 'srf-ap':
            logging.info("Node list for capturing PythonSV logs: %s" % node_list)
            data = {
                'conf': {
                    'idsid': 'sys_asvauto',
                    'suts': node_list,
                    'time_period': '%sh%sm' % (_hour, _min)
                },
            }
            trigger_dag('event_pythonsv_handler', data)
            '''
            In Airflow, DAG event_pythonsv_handler set timeout to complete PythonSV collection.
            Here we wait for timeout to make sure all tasks are done.
            '''
            total_sleep_time = cfg.pythonsv_timeout[_cpu]
            log.info("Wait for DAG compeltion. Timeout %d" % total_sleep_time)
            time.sleep(total_sleep_time)
            log.info("Finish waiting for DAG compeltion.")
    except Exception as e:
        log.error(str(e))

    # Change PythonSV Readiness to Completed
    change_pythonsv_readiness(_cpu, node_list)

    # Update Excel sheet in SharePoint
    try:
        update_notready_sheet(body, _cpu)
    except Exception as e:
        log.error(str(e))

    # Print info as daily reporting in Teams channel
    try:
        if _cpu == "cwf-ap":
            send_teams_message_thu_workflow(rst, _cpu)
        else:
            send_teams_messages(rst, _cpu)
    except Exception as e:
        log.error(str(e))
    try:
        if _cpu == "cwf-ap":
            send_dpmo_results_to_teams(res_dpmo, _cpu)
        else:
            send_teams_messages_dpmo(res_dpmo, _cpu)
    except Exception as e:
        log.error(str(e))

    # Remove out label
    for cmd in rm_label_cmds:
        # really go k8s to do this cmd
        print(cmd)
        k8s.cmd(cmd)

    clean_nrn_report(_cpu)

    # display
    if _is_dry_run:
        display_not_ready_by_ns(rst)
        display_not_ready_by_cluster(nodes)
        print("\n\n\n\n")
        print("removing label", "=" * 36)
        for cmd in rm_label_cmds:
            print(cmd)
        for cmd in del_ns_cmds:
            print(cmd)
        print("\n")
