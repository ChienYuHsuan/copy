# Connectors - Kubernetes (Local)
The Kubernetes