# Connectors - Redfish API
The Redfish