import logging

import redfish

import asv_pipeline.config as cfg
from asv_pipeline.util import s2b

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)

redfish_logger = logging.getLogger('redfish')
redfish_logger.setLevel(logging.INFO)


class RFFactory:

    def __init__(self, node, timeout=30, max_retry=1):
        self.rf_client = redfish.redfish_client(
            base_url="https://{}.deacluster.intel.com".format(s2b(node)), username=cfg.bmc_username,
            password=cfg.bmc_password, timeout=timeout, max_retry=max_retry)
        try:
            self.rf_client.login(username=cfg.bmc_username, password=cfg.bmc_password)
        except Exception as e:
            logging.error(f"Failed to log in: {e}")

    def get_request(self, endpoint, headers=None, timeout=30, max_retry=1):
        try:
            response = self.rf_client.get(endpoint, headers=headers, timeout=timeout,
                                          max_retry=max_retry)
            if response.status == 200:
                return response.dict
        except Exception as e:
            logging.error(f"Failed to retrieve system details: {e}")
        return None

    def post_request(self, endpoint, headers=None, body=None, timeout=60, max_retry=1):
        try:
            response = self.rf_client.post(endpoint, headers=headers, body=body, timeout=timeout,
                                           max_retry=max_retry)
            return response
        except Exception as e:
            logging.error(f"Failed to perform action on the system: {e}")
            return None

    def logout(self):
        try:
            self.rf_client.logout()
        except Exception as e:
            logging.error(f"Failed to logout: {e}")
