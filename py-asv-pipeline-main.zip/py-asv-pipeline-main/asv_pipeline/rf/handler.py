import logging

from asv_pipeline.rf import RFFactory

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)


def get_debug_cpld(node, rf_client=None, islogout=True):
    if not rf_client:
        rf_client = RFFactory(node)
    rst = rf_client.get_request("/redfish/v1/UpdateService/FirmwareInventory/DEBUG_cpld")

    if islogout:
        rf_client.logout()
    return "" if rst is None else rst.get("Version")


def get_cpu_cpld(node, rf_client=None, islogout=True):
    if not rf_client:
        rf_client = RFFactory(node)
    rst = rf_client.get_request("/redfish/v1/UpdateService/FirmwareInventory/CPU_cpld")
    if islogout:
        rf_client.logout()
    return "" if rst is None else rst.get("Version")


def get_scm_cpld(node, rf_client=None, islogout=True):
    if not rf_client:
        rf_client = RFFactory(node)
    rst = rf_client.get_request("/redfish/v1/UpdateService/FirmwareInventory/SCM_cpld")

    if islogout:
        rf_client.logout()
    return "" if rst is None else rst.get("Version")


def get_pfr_cpld(node, rf_client=None, islogout=True):
    if not rf_client:
        rf_client = RFFactory(node)
    rst = rf_client.get_request("/redfish/v1/UpdateService/FirmwareInventory/cpld_active")

    if rst is None:
        rst = rf_client.get_request("/redfish/v1/UpdateService/FirmwareInventory/rot_fw_active")

    if islogout:
        rf_client.logout()

    return "" if rst is None else rst.get("Version")


def get_dimm0_dimm1(node, rf_client=None, islogout=True):
    if not rf_client:
        rf_client = RFFactory(node)
    dimm0 = rf_client.get_request("/redfish/v1/Systems/system/Memory/dimm0")
    dimm1 = rf_client.get_request("/redfish/v1/Systems/system/Memory/dimm1")

    if islogout:
        rf_client.logout()

    logging.debug(dimm0)
    logging.debug(dimm1)

    return dimm0, dimm1


def cold_reset(node, rf_client=None, islogout=True):
    if not rf_client:
        rf_client = RFFactory(node)
    data = {"ResetType": "PowerCycle"}
    rst = rf_client.post_request("/redfish/v1/Systems/system/Actions/ComputerSystem.Reset",
                                 body=data)
    if islogout:
        rf_client.logout()

    if rst.status == 200:
        return True
    return False


def warm_reset(node, rf_client=None, islogout=True):
    if not rf_client:
        rf_client = RFFactory(node)
    data = {"ResetType": "ForceRestart"}
    rst = rf_client.post_request("/redfish/v1/Systems/system/Actions/ComputerSystem.Reset",
                                 body=data)
    if islogout:
        rf_client.logout()

    if rst.status == 200:
        return True
    return False


def bmc_reset(node, rf_client=None):
    if not rf_client:
        rf_client = RFFactory(node)
    data = {"ResetType": "GracefulRestart"}
    rst = rf_client.post_request("/redfish/v1/Managers/bmc/Actions/Manager.Reset", body=data)
    if rst.status == 200:
        return True
    return False


def get_bmc(node, rf_client=None, islogout=True):
    if not rf_client:
        rf_client = RFFactory(node)
    rst = rf_client.get_request("/redfish/v1/UpdateService/FirmwareInventory/bmc_active")

    if islogout:
        rf_client.logout()

    return "" if rst is None else rst.get("Version")


def get_bios(node, rf_client=None, islogout=True):
    if not rf_client:
        rf_client = RFFactory(node)
    rst = rf_client.get_request("/redfish/v1/UpdateService/FirmwareInventory/bios_active")

    if islogout:
        rf_client.logout()

    return "" if rst is None else rst.get("Version")


def is_power_state(node, rf_client=None, islogout=True):
    if not rf_client:
        try:
            rf_client = RFFactory(node)
        except Exception:
            raise Exception("Fail to access BMC endpoint")
    rst_sys = rf_client.get_request("/redfish/v1/Systems/system")
    rst_chasis = rf_client.get_request("/redfish/v1/Chassis/BNC_Baseboard")
    if not rst_chasis and not rst_sys:
        raise Exception("Fail to access Redfish system and chassis endpoints")
    if rst_sys and rst_chasis and rst_sys.get("PowerState") != rst_chasis.get("PowerState"):
        logging.warning("system and chassis get different result of PowerState")
    if islogout:
        rf_client.logout()
    rst = True if (rst_sys and rst_sys.get("PowerState").lower() == "on") or (
        rst_chasis and rst_chasis.get("PowerState").lower() == "on") else False
    ctx = f'the node {node} power_state is {rst}'
    logging.info(ctx)
    if not rst:
        logging.info(rst_sys)
        logging.info(rst_chasis)
    return rst


def is_bmc_reachable(node, rf_client=None, islogout=True):
    if not rf_client:
        try:
            rf_client = RFFactory(node)
        except Exception:
            return False
    try:
        rst = rf_client.get_request("/redfish/v1/Systems/system")
        return rst is not None
    except Exception:
        return False
    finally:
        if islogout:
            rf_client.logout()
