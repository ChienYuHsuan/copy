from unittest.mock import MagicMock, Mock, patch

import pytest

from asv_pipeline.tasks.bmc import get_cpu_cpld


@pytest.fixture
def mock_expect_handler_bastion():
    with patch('asv_pipeline.util.expect_handler.bastion') as mock_bastion:
        mock_eb = MagicMock()
        mock_bastion.return_value = mock_eb
        yield mock_eb


@pytest.fixture
def mock_s2b():
    with patch('asv_pipeline.tasks.bmc.s2b', return_value=Mock()) as mock_s2b:
        yield mock_s2b


@pytest.fixture
def mock_ansi_escape():
    with patch('asv_pipeline.tasks.bmc.ansi_escape',
               return_value="fake version") as mock_ansi_escape:
        yield mock_ansi_escape


def test_get_cpu_cpld(mock_expect_handler_bastion, mock_s2b, mock_ansi_escape):
    # def mock_s2b(node):
    #     pass  # Implement the behavior of the mock s2b function
    # monkeypatch.setattr("asv_pipeline.tasks.bmc.s2b", mock_s2b)
    # Set the expected responses from the mock
    # mock_expect_handler_bastion.before = 'Mocked response'

    # Call the function with test inputs
    result = get_cpu_cpld('test_cluster', 'test_node', 'test_idsid')

    # Assertions

    assert result == 'fake version'


def test_get_pfr_cpld(mock_expect_handler_bastion, mock_s2b, mock_ansi_escape):
    # def mock_s2b(node):
    #     pass  # Implement the behavior of the mock s2b function
    # monkeypatch.setattr("asv_pipeline.tasks.bmc.s2b", mock_s2b)
    # Set the expected responses from the mock
    # mock_expect_handler_bastion.before = 'Mocked response'

    # Call the function with test inputs
    result = get_cpu_cpld('test_cluster', 'test_node', 'test_idsid')

    # Assertions

    assert result == 'fake version'
