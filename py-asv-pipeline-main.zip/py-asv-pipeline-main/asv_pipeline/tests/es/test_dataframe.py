import logging
from datetime import datetime, timedelta, timezone

import pytz

import asv_pipeline.config as cfg
from asv_pipeline.es import ES


def test_get_nrn_dataframe():
    end = datetime(2024, 5, 21, 2, 1, 21).astimezone(pytz.UTC)
    start = end - timedelta(hours=2)
    logging.info("from:%s, to:%s", start, end)
    cluster = "flex"
    es = ES(url=cfg.es_endpoints[cluster], name=cfg.es_username[cluster],
            password=cfg.es_password[cluster]).index("nrn_reporting")
    body = es.range(start, end, timestamp="Creation Time").build()
    df = ES.to_df(es.execute(timeout=600, payload=body))
    logging.debug(df.to_string())
    logging.info(len(df))
    return df, es


def test_get_dataframe():
    end = datetime.now(timezone.utc)
    start = end - timedelta(hours=12)
    cluster = "flex"
    es = ES(url=cfg.es_endpoints[cluster], name=cfg.es_username[cluster],
            password=cfg.es_password[cluster]).index("nrn_reporting")
    body = es.range(start, end, timestamp="NRN timestamp").build()
    df = ES.to_df(es.execute(timeout=600, payload=body))
    logging.info(len(df.index))
    logging.info(df['Node'].isin(['fl31ca102gs0809', 'fl41ca201fs1103']).any())
    logging.info(df[df['Node'].isin(['fl31ca102gs0809', 'fl41ca201fs1103'])].to_string())
    logging.info(df.loc[df['Node'] == 'fl41ca202es0110', ["Initial Pool"]])
    logging.info(df.loc[df['Node'] == 'fl31ca102gs0809', ["Initial Pool"]])
    # in-place update
    df.loc[df['Node'] == 'fl41ca202es0110', [
        "PythonSV Result"
    ]] = "https://intel.sharepoint.com/:t:/s/ScaleInternalCluster/EeyhFMEQSP1Mg6aVDNaRd5UB2obwPSaKu9ZqjCsMAmhgfg"
    df.loc[df['Node'] == 'fl41ca202gs0302', [
        "PythonSV Result"
    ]] = "https://intel.sharepoint.com/:t:/s/ScaleInternalCluster/EQTIF2BZAbxKoGUeYbIesdEBZDA-RQXqdKEMUqJAjY85IA"
    df.loc[df['Node'] == 'fl41ca201hs0209', [
        "PythonSV Result"
    ]] = "[timeout]https://intel.sharepoint.com/:t:/s/ScaleInternalCluster/ETGG3k_GetdBsGNRohz74uIBd8g9vJFO_XegQmorBtwxAg"
    logging.info(df['Node'].values)
    filtered = df[df['Node'].isin(["fl41ca202es0110", "fl41ca202gs0302", "fl41ca201hs0209"])]
    filtered2 = filtered[["Initial Pool", "Node", "QDF", "PythonSV Result"]]
    # print(filtered.to_dict(orient='records'))
    print(filtered2)
    es.update(filtered)
    # filtered = df.loc[df['Node']=='fl41ca202gs0302', ["Initial Pool","Node","QDF","PythonSV Result"]]
    # filtered2 = df.loc[df['Node']=='fl41ca202gs0302']
    # print(filtered.to_string())
    # print(filtered2.to_dict())
    # es.update_df(filtered)
    # print(df.to_string())
