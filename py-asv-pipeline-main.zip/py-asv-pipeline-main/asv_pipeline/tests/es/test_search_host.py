'''
Suppose we get begin/end time as Linux time format: 'Fri Feb 25 16:07:17 UTC 2022'
Sample of converting Linux time format to Python datetime format:
>>> date = "Fri Feb 25 16:07:17 UTC 2022"
>>> new_date = datetime.datetime.strptime(date, '%a %b %d %H:%M:%S %Z %Y')
>>> print(new_date)
2022-02-25 16:07:17
'''
from es import ES

import asv_pipeline.config as cfg


def test_search_host():
    # _begin = datetime(2023, 6, 1, 1, 39, 30, 149)
    # _end = datetime(202, 6, 1, 9, 39, 30, 149)
    es = ES(url=cfg.es_endpoints['flex'], name=cfg.es_username['flex'],
            password=cfg.es_password['flex']).index("qpool-*")
    body = es.oneOf('log', [
        'not ok', 'TSC warp', 'TSC unstable', 'downgraded', 'coredump', 'TSC found unstable',
        'REBOOT COUNT', 'REBOOT TYPE'
    ]).build()
    rst = es.execute(timeout=600, payload=body)

    removed_host = []
    doc_count = 0
    for doc in rst:
        doc_count += 1
        if 'kubernetes' in doc['_source'].keys():
            removed_host.append(doc['_source']['kubernetes']['host'])
        else:
            removed_host.append(doc['_source']['hostname'])

    print("Total nodes:", len(set(removed_host)))
    print("Node list to be removed:", set(removed_host))

    assert len(set(removed_host)) == 70
