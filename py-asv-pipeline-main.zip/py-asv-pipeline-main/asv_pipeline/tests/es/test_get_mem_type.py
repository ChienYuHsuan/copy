from es.es_handler import get_mem_type


def test_get_mem_type():
    # a, b = get_mem_type('bhs', 'fl41ca201es0902')
    a, b = get_mem_type('zp31', 'zp3110b001s0907')
    print("################\n", a, b)

    assert False
