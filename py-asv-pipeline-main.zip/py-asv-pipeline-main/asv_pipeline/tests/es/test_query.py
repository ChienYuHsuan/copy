import json
from datetime import datetime, timedelta

import es.eventrouter as er
from es import ES


def test_es_builder():
    es = ES()
    _now = datetime(2022, 6, 8, 0, 0, 0)
    _begin = _now - timedelta(days=1)
    js = es.IS('log', '"reason":"Started"').IS('kubernetes.pod_name', 'eventrouter').notOneof(
        'log',
        ['"namespace":"monitoring"', '"namespace":"mgmt"', '"verb":"UPDATED"']).range(_begin,
                                                                                      _now).build()
    target = '''
    {"sort": [{"@timestamp": {"order": "desc", "unmapped_type": "boolean"}}], "query": {"bool": {"filter": [{"match_phrase": {"log": {"query": "\\"reason\\":\\"Started\\""}}}, {"match_phrase": {"kubernetes.pod_name": {"query": "eventrouter"}}}, {"range": {"@timestamp": {"format": "strict_date_optional_time", "gte": "2022-06-07T00:00:00", "lte": "2022-06-08T00:00:00"}}}], "must_not": [{"bool": {"should": [{"match_phrase": {"log": "\\"namespace\\":\\"monitoring\\""}}, {"match_phrase": {"log": "\\"namespace\\":\\"mgmt\\""}}, {"match_phrase": {"log": "\\"verb\\":\\"UPDATED\\""}}], "minimum_should_match": 1}}]}}}'''.strip(
    )

    assert json.dumps(js).strip() == target


def test_query_extraction_from_eventrouter():
    es = ES()
    _now = datetime(2022, 6, 8, 0, 0, 0)
    _begin = _now - timedelta(hours=1)
    js = es.index('qpool').IS(
        'log', '"reason":"Started"').IS('kubernetes.pod_name', 'eventrouter').notOneof(
            'log', ['"namespace":"monitoring"', '"namespace":"mgmt"', '"verb":"UPDATED"']).range(
                _begin, _now).build()
    rst = es.execute(timeout=300, payload=js)

    is_action_added_existed = False

    logs = er.extract_events(rst)
    for log in logs:
        if log.get('verb') == "ADDED":
            is_action_added_existed = True
            break

    assert is_action_added_existed
