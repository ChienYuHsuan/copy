import logging

from asv_pipeline.jk import JenkinsFactory

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def test_output():
    # assert JenkinsFactory().get_console_output("Tests/cycle-in-reboot", 33069) == 33069
    logger.info(JenkinsFactory().get_console_output(
        "Sapphire/Main pipelines/Burn-in-Custom-Pipeline-SPR-OPUS"))
    assert False
