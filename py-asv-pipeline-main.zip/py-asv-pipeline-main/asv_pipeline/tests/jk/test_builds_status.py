import logging

from asv_pipeline.jk import JenkinsFactory

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def test_builds_status():
    # Sample result of get_builds_status is:
    # {25: 'WIP', 23: 'WIP', 22: 'WIP', 21: 'SUCCESS', 20: 'SUCCESS', 19: 'FAILURE', 18: 'SUCCESS'}
    status = JenkinsFactory().get_builds_status("Granite/Main pipelines/GNR-Burn-in-BKC-Pipeline")
    logger.info(status)

    # Max # of builds to keep for this pipeline is 10
    assert len(status) <= 10


def test_build_result_by_buildid():
    logger.info(JenkinsFactory().get_build_result_by_buildid(
        "Granite/Main pipelines/GNR-Burn-in-BKC-Pipeline", 7))
    assert False


def test_build_result_by_buildid_dummy():
    rst = JenkinsFactory().get_build_result_by_buildid(
        "SierraForest/Main Pipelines/SRF-BKC-Acceptance-Burnin-Pipeline-Stage1", 6)
    assert rst == "SUCCESS"


def test_build_url_by_buildid():
    rst = JenkinsFactory().get_build_url_by_buildid(
        "SierraForest/Main Pipelines/SRF-BKC-Acceptance-Burnin-Pipeline-Stage1", 6)
    assert rst == "SUCCESS"
