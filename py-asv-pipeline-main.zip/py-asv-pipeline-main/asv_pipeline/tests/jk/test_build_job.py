import logging
import time

from asv_pipeline.jk import JenkinsFactory

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def test_build_dummy():
    for _ in range(10):
        JenkinsFactory().build_job(
            "Tests/Development/pre-check-dummy", {
                'ns': 'srf-ap-pe-demo-io1-at-ww08-2-3',
                'kubeconfig': 'srf',
                'RECIPIENT': 'nelson.lin@intel.com,caty.lee@intel.com,eric.lei@intel.com',
                'cluster': 'srf'
            })


def test_builds_status():
    queue_id = JenkinsFactory().build_job(
        "Tests/testing-af-cycle-in-reboot", {
            "CLEAN": "TRUE",
            "CYCLES": "100",
            "KKONG": False,
            "NS": "automation",
            "REBOOT_TYPE": "rf_cold",
            "SS": "TRUE",
            "TIMEOUT": "600",
            "UPI_CHECK": "FALSE"
        })
    logger.info(queue_id)

    for _ in range(10):
        rst = JenkinsFactory().get_queue_item(queue_id)
        if "executable" in rst:
            logger.info(rst)
            logger.info(rst.get('executable').get('number'))
            logger.info(JenkinsFactory().get_builds_status("Tests/testing-af-cycle-in-reboot",
                                                           rst.get('executable').get('number')))
            logger.info(JenkinsFactory().get_build_info("Tests/testing-af-cycle-in-reboot",
                                                        rst.get('executable').get('number')))
            break
        else:
            time.sleep(2)

    # Max # of builds to keep for this pipeline is 10
    assert False
    # assert len(status) <= 10


def test_build_result():
    job = "Tests/testing-af-cycle-in-reboot"
    rst = JenkinsFactory().get_build_result_by_queueid(
        job,
        JenkinsFactory().build_job(
            job, {
                "CLEAN": "TRUE",
                "CYCLES": "100",
                "KKONG": False,
                "NS": "automation",
                "REBOOT_TYPE": "rf_cold",
                "SS": "TRUE",
                "TIMEOUT": "600",
                "UPI_CHECK": "FALSE"
            }))
    logger.info(rst)

    assert False


def test_buildid_url():
    job = 'Tests/cycle-in-reboot-srf'
    build_id = '62'
    print(JenkinsFactory.get_buildid_url(job, build_id))
