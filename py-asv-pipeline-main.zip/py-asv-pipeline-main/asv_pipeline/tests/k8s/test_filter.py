import logging

from asv_pipeline.k8s import filter

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Only valid command starting with 'kubectl' or 'kc' or 'k' is accepted
cmd = "bad command"


def test_filter():
    args = filter(cmd)
    logger.info("Command after filter: %s" % args)

    assert args == ""
