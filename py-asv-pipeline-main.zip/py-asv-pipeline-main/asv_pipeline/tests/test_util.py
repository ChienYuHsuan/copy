from util import get_cluster_by_naming, get_ww, is_older, s2b


def test_is_order():
    assert is_older("131m", "5h") == False
    assert is_older("5h10m", "5h") == True
    assert is_older("1d5h", "5h") == True
    assert is_older("1y1d", "5h") == True
    assert is_older("5h", "5h") == False
    assert is_older("3d3h", "5h") == True
    assert is_older("4h59m", "5h") == False
    assert is_older("4h", "5h") == False


def test_get_cluster_by_naming():
    suts = ["fl31ca105as0702", "fl31ca105as0503"]
    for x in suts:
        print(get_cluster_by_naming(x))


def test_get_ww():
    assert get_ww().startswith('WW')


def test_s2b():
    sut = 'fl31ca102es0305'
    assert s2b(sut) == 'fl31ca102eb0305'
