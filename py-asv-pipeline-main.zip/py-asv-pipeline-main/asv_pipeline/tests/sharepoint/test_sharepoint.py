import datetime
import logging
import os
from unittest.mock import MagicMock, patch

from asv_pipeline.sharepoint import SharePoint, SharePointFactory
from asv_pipeline.sharepoint.update_notready import update_notready_sheet
from asv_pipeline.util import get_ww_tpe
from fixtures.k8s import k8s_pods_fixture  # noqa: F401


def test_download_upload():
    FOLDER = "Shared Documents/NotReady Nodes Reporting - "
    FILE = "NOTREADY_NODE_%(cpu)s_%(ww)s.xlsx"
    ww = get_ww_tpe()
    site = "https://intel.sharepoint.com/sites/ScaleInternalCluster"
    sp = SharePoint(site)

    _folder = 'SPR'

    # Need a relative path for the first parameter
    url = '/' + '/'.join(site.split('/')[-2:]) + '/' + FOLDER + _folder
    filename = FILE % {"cpu": 'SPR', "ww": ww}
    path = sp.download(url + "/" + filename, os.getcwd())
    print(path)

    if not path:
        print("File doesn't exist in SharePoint. Go create a file")
        assert False

    sp.upload(path, "Shared Documents/FTx ASV/test")
    assert True


def test_share_object():
    import asv_pipeline.config as cfg
    filename = f"/{'/'.join(cfg.sp_site.split('/')[-2:])}/Shared Documents/PythonSV/WW49/fl41ca202es0408_2023_12_08_10_42_14.txt"
    rst = SharePointFactory.build().get_shared_link(filename)
    logging.info(rst)
    assert "https://intel.sharepoint.com/:t:/s/asv-auto/" in rst


@patch(
    "asv_pipeline.sharepoint.update_notready.launch_pythonsv",
    return_value=  # noqa: E251
    "https://intel.sharepoint.com/:t:/s/asv-auto/EbwPZ2NTfDpJmx4044EGvxsBrNGjJ-qHYiHnDbIXPqr67g")
@patch("asv_pipeline.sharepoint.update_notready.SharePoint", return_value=MagicMock())
def test_update_notready_sheet(mocked_SharePoint, mocked_launch_pythonsv,
                               k8s_pods_fixture):  # noqa: F811
    logging.info(k8s_pods_fixture)
    logging.info(mocked_SharePoint.return_value)
    logging.info(mocked_launch_pythonsv.return_value)

    mocked_sharepoint_instance = mocked_SharePoint.return_value
    mocked_sharepoint_instance.download.return_value = None
    mocked_sharepoint_instance.upload.return_value = None

    update_notready_sheet(k8s_pods_fixture, "srf", datetime.datetime.now().isoformat())

    mocked_launch_pythonsv.assert_called()
    mocked_sharepoint_instance.download.assert_called_once()
    mocked_sharepoint_instance.upload.assert_called_once()


def test_download_from_shared_link():
    shared_link = "https://intel.sharepoint.com/:t:/s/ScaleInternalCluster/EYoCxB-xx2dGm5bR64JyuLQB_qb6XFKe2H7rfP4JfwZ8QQ"
    with SharePointFactory.build(sp_site='https://intel.sharepoint.com/sites/ScaleInternalCluster'
                                 ).download_from_shared_link(shared_link) as f:
        logging.info(f"File is located at : {f}")


def test_download_task_definition():
    from asv_pipeline.sharepoint import at

    logging.info(at.load_tasks())
