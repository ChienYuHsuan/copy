import logging

import pytest

import asv_pipeline.rf.handler as hd

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


@pytest.fixture
def node():
    sut = "fl41ca202gs1107"
    yield sut


def test_get_debug_cpld(node):
    rst = hd.get_debug_cpld(node)
    logging.info(rst)
    assert rst == "0.26"
    # assert False


def test_get_cpu_cpld(node):
    rst = hd.get_cpu_cpld(node)
    logging.info(rst)
    assert rst == "0.26"
    # assert False


def test_get_scm_cpld(node):
    rst = hd.get_scm_cpld(node)
    logging.info(rst)
    assert rst == "4.16"
    # assert False


def test_get_pfr_cpld(node):
    rst = hd.get_pfr_cpld(node)
    logging.info(rst)
    assert rst == "3.0-75e05637da884d9cf6a2b2af4789649d290579de88315f675760839a2dd71a98"
    # assert False


def test_get_dimm0_dimm1(node):
    dimm0, dimm1 = hd.get_dimm0_dimm1(node)
    logging.info(hd.get_dimm0_dimm1(node))
    assert dimm0.get("Id") == "dimm0" and dimm1.get("Id") == "dimm1"


def test_get_bmc(node):
    rst = hd.get_bmc(node)
    logging.info(rst)
    assert rst == "bhs-23.47-13-g3e6c03-6fddef2"
    # assert False


def test_get_bios(node):
    rst = hd.get_bios(node)
    logging.info(rst)
    assert rst == "BHSDCRB1.IPC.0028.D33.2311290008"
    # assert False


def test_is_power_state(node):
    logging.info(node)
    node = "fl41ca202gs0405"
    rst = hd.is_power_state(node)
    logging.info(rst)
