import asv_pipeline.config as cfg
from asv_pipeline.kafka import KafkaConsumer


def test_list_topic():
    consumer = KafkaConsumer(brokers=cfg.kafka_brokers['icx-1'], groupid='test-1',
                             auto_offset='latest', topic='atscale')
    """
    Expected topics within 'icx-1' Kafka brokers:
    {
     'atscale-other': TopicMetadata(atscale-other, 9 partitions), 
     'cluster-pnp': TopicMetadata(cluster-pnp, 9 partitions), 
     '__consumer_offsets': TopicMetadata(__consumer_offsets, 50 partitions), 
     '_confluent-metrics': TopicMetadata(_confluent-metrics, 12 partitions), 
     'atscale': TopicMetadata(atscale, 9 partitions)
    }
    """
    assert len(consumer.consumer.list_topics().topics) == 5
