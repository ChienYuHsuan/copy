import re

from asv_pipeline.auto_messages import (CHANNEL, create_table_row, create_text_block,
                                        notify_via_teams, notify_via_teams_using_workflow)
from asv_pipeline.jk import JenkinsFactory


def test_notify_via_team_with_ctx():
    output = {"MAIN": "jenkins:id1", "WARM": "jenkins:id:2"}
    # line = "```"
    line = ""
    for k, v in output.items():
        line += f'|**{k}**|{v}||<br>'
    # line += "```"
    line += """
<table bordercolor='black' border= '2'>
    <thead>
        <tr style = 'background-color : #33475b; color: White'>
            <th>Task</th>
            <th>Status</th>
            <th>Start Time</th>
            <th>End Time</th>
        </tr>
    </thead>
    <tbody>
        <tr><td>xxx</td><td>yyy</td><td>14:25</td></tr>
        <tr><td>xxx</td><td><a href="https://www.microsoft.com">buildid</a></td><td>15:25</td><td>16:25</td></tr>
    </tbody>
</table>
"""
    notify_via_teams(line, CHANNEL.AUTOTRIGGER)


def test_notify_via_team_using_workflow_with_ctx():

    kv = {
        "fl31ca303as0306": [
            '141', 'srf-ap-burnin-at-ww42-3', 'SierraForest-AP/Main pipelines/SRF-Burn-in-Pipeline',
            "SRF-AP", "BURNIN", "SierraForest-AP/Main pipelines/SRF-Burn-in-Pipeline"
        ],
        "fl31ca303bs0208": [
            '141', 'srf-ap-burnin-at-ww42-3', 'SierraForest-AP/Main pipelines/SRF-Burn-in-Pipeline',
            "SRF-AP", "BURNIN", "SierraForest-AP/Main pipelines/SRF-Burn-in-Pipeline"
        ],
        "fl31ca303as0405": [
            '141', 'srf-ap-burnin-at-ww42-3', 'SierraForest-AP/Main pipelines/SRF-Burn-in-Pipeline',
            "SRF-AP", "BURNIN", "SierraForest-AP/Main pipelines/SRF-Burn-in-Pipeline"
        ],
    }
    table_tpl = {
        "type": "Table",
        "columns": [{
            "width": 2
        }, {
            "width": 1
        }, {
            "width": 2
        }, {
            "width": 1
        }, {
            "width": 1
        }, {
            "width": 5
        }],
        "rows": []
    }

    body = [create_text_block("autotrigger result")]

    # we can use markdown format to send the message via Team
    heads = ["Node", "Build ID", "Namespace|BKC", "Task", "CPU", "JOB"]
    # strength
    for i in range(len(heads)):
        heads[i] = f"**{heads[i]}**"

    table_tpl['rows'] += [create_table_row(*heads)]
    for node, pair in kv.items():
        anchor = f'[{pair[0]}]({JenkinsFactory().get_build_url_by_buildid(pair[2], pair[0])})' if pair[
            0] and re.search(r'\d+', str(pair[0])) else pair[0]
        data = [
            f'{node}', f'{anchor}', f'{pair[1]}', f'{pair[4]}', f'{pair[3]}',
            f'{pair[2]}({pair[5]})'
        ]

        row = create_table_row(*data)
        table_tpl['rows'] += [row]
    body.append(table_tpl)

    notify_via_teams_using_workflow(body, CHANNEL.AUTOTRIGGER)
