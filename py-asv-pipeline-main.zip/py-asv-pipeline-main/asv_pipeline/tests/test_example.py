"""Unit tests for example."""

from asv_pipeline.example import Example


class TestExample:

    def test_msg(self):
        example = Example('foo')
        assert example.msg == 'foo'
