import logging

from util import get_cluster_by_naming
from util.expect_handler import bastion, k8s, sut, sysman

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
idsid = 'catylee'
logger.setLevel(logging.DEBUG)


def test_sysman_icx():
    try:
        eb = sysman("icx-1", idsid)
        logger.info(eb.before)
    except Exception:
        assert False


def test_bastion_icx():
    try:
        eb = bastion("icx-1", idsid)
        logger.info(eb.before)
    except Exception:
        assert False


def test_k8s_icx():
    try:
        eb = k8s("icx-1", idsid)
        logger.info(eb.before)
    except Exception:
        assert False


def test_sysman_flex():
    try:
        eb = sysman("flex", idsid)
        logger.info(eb.before)
    except Exception:
        assert False


def test_sysman_flex_4_gnr():
    try:
        eb = sysman("flex", idsid, 'GNR')
        logger.info(eb.before)
    except Exception:
        assert False


def test_bastion_flex():
    try:
        eb = bastion("flex", idsid)
        logger.info(eb.before)
    except Exception:
        assert False


def test_k8s_flex():
    try:
        eb = k8s("flex", idsid)
        logger.info(eb.before)
    except Exception:
        assert False


"""
start with Feb, 2023, Opus is decommissioned
"""
# def test_sysman_opus():
#     try:
#         eb = sysman("opus-spr", idsid)
#         logger.info(eb.before)
#     except Exception:
#         assert False

# def test_bastion_opus():
#     try:
#         eb = bastion("opus-spr", idsid)
#         logger.info(eb.before)
#     except Exception:
#         assert False

# def test_k8s_opus():
#     try:
#         eb = k8s("opus-spr", idsid)
#         logger.info(eb.before)
#     except Exception:
#         assert False


def test_k8s_zp31():
    try:
        eb = k8s("zp31", idsid)
        logging.info(eb.before)
    except Exception:
        assert False


def test_bastion_zp31():
    try:
        eb = bastion("zp31", idsid)
        logging.info(eb.before)
    except Exception:
        assert False


def test_sysman_zp31():
    try:
        eb = sysman("zp31", idsid)
        logging.info(eb.before)
    except Exception:
        assert False


def test_k8s_bhs():
    try:
        eb = k8s("bhs", idsid)
        logging.info(eb.before)
    except Exception:
        assert False


def test_bastion_bhs():
    try:
        eb = bastion("bhs", idsid)
        logging.info(eb.before)
    except Exception:
        assert False


def test_sysman_bhs():
    try:
        eb = sysman("bhs", idsid)
        logging.info(eb.before)
    except Exception:
        assert False


def test_bastion_for_sut():
    node = "fl31ca102fs0201"

    eb = sut(get_cluster_by_naming(node), node)
    logging.info(eb.before)
