# Tests
all commands are executed in the py-asv-pipeline
## comprehensive tests
- For CI/CD pipeline, we could directly use `make test` for comprehensive tests.
- For regression testing, it would be good to execute `make test` as well
- To observer more details, `python asv_pipeline/tests -vvv -s`

## a designate test
`python asv_pipeline/tests <group>/<a particular file> -vvv -s`
## a group of tests
`python asv_pipeline/tests <group>/ -vvv -s`
## print out logging info.
adjust the log-level and try to let the testing fail, for example,
```python
assert False
```
~~~bash
$ python asv_pipeline/tests.py tasks/test_xmlcli.py -s -vvvvv --log-level=debug
~~~