import logging

from clusterscope.poolname import parse

import asv_pipeline.config as cfg
from asv_pipeline.clusterscope import ClusterScope, handler
from asv_pipeline.util import get_cluster_by_naming


def test_parse():

    data = "SPR_XCC-E2_PLN_EXC_PIV_BURNIN2-QS-WAVE2_VIMARTI"
    pn = parse(data)
    pn.update_test_description(pn.test_description + "-NOTREADY").update_cpu('ICX').update_stepping(
        'HBM-A0').update_assignto('BKC').update_state('RDY').update_subclustername(
            'OSS').update_idsid('LEIERIC')
    assert str(pn) == "ICX_HBM-A0_BKC_RDY_OSS_BURNIN2-QS-WAVE2-NOTREADY_LEIERIC"


def test_update_poolname():
    n = "fl41ca201fs0603"
    test = 'srf-tsl-sq6j5'
    current_phase = ''
    _nodes = {n}
    res, noassigned = handler.get_pool_by_nodes(_nodes)
    locations = handler.get_location_by_nodes(_nodes)

    cs = ClusterScope("http://api.clusterscope.fl31c2ingress.deacluster.intel.com")

    for p in cfg.burnin_phases:
        if test in cfg.burnin_phases[p]:
            current_phase = p
            break
    else:
        print("No match phase for %s" % test)

    if current_phase:
        expected_desc = f"{res[n].test_description}-NOTREADY-{current_phase}"
    else:
        expected_desc = f"{res[n].test_description}-NOTREADY"

    print(res[n])
    res[n].update_node(n, locations[n]).update_cpu('SRF-SP')\
        .update_stepping('B0').update_assignto('PLN')\
        .update_state('EXC').update_subclustername('PIV')\
        .update_test_description(expected_desc).update_idsid('CTN')
    print(res[n])

    handler.update_pool_by_nodes(cs, res[n])
    assert True


def test_update_poolname_2():
    n = "fl31ca102fs0204"
    _nodes = {n}
    res = handler.get_pool_name(_nodes)
    locations = handler.get_location_by_nodes(_nodes)

    cs = ClusterScope(cfg.clusterscopes[get_cluster_by_naming(n)], timeout=60)
    logging.info(locations)
    logging.info(res[n])

    expected_test_description = f"test-{res[n].test_description}"
    expected_idsid = f"{res[n].idsid}"

    import re
    expected_test_description = re.sub(r'-test-', "", expected_test_description)

    res[n].update_node(n, locations[n]).update_cpu(res[n].cpu)\
        .update_stepping(res[n].stepping).update_assignto(res[n].asignto)\
        .update_state(res[n].state).update_subclustername(res[n].subclustername)\
        .update_test_description(expected_test_description).update_idsid(expected_idsid)
    logging.info(res[n])
    logging.info(res[n].data)
    logging.info(res[n].headers)
    logging.info(cs.server)
    # ret = cs.instant_update_by_name( headers = res[n].headers, data= res[n].data)
    handler.update_pool_by_nodes(cs, res[n])
    res = handler.get_pool_name(_nodes)
    logging.info(res[n])
    assert res[n].test_description == expected_test_description
    assert res[n].idsid == expected_idsid
    assert False


def test_update_poolname_3():
    n = "fl31ca102fs0206"
    _nodes = {n}
    res_1 = handler.get_pool_name(_nodes)
    locations = handler.get_location_by_nodes(_nodes)

    cs = ClusterScope(cfg.clusterscopes[get_cluster_by_naming(n)], timeout=60)
    logging.info(locations)
    logging.info(res_1[n])

    res_1[n].update_node(n, locations[n]).update_pool('SRF-SP_A0_PIV_RDY_PIV_DPMO-BKC56_CATYLEE')
    logging.info(res_1[n])
    logging.info(res_1[n].data)
    logging.info(res_1[n].headers)
    logging.info(cs.server)
    handler.update_pool_by_names(cs, res_1[n])

    res_2 = handler.get_pool_name(_nodes)
    logging.info(res_2[n])

    assert res_1[n].data['pool'] == res_2[n].data['pool']


def test_get_cpu_enhance():
    _in = [
        'fl41ca202fs0806', 'fl31ca102es0508', 'fl31ca102es0709', 'fl31ca102gs0405',
        'fl31ca102gs0408', 'fl41ca202hs0101', 'fl41ca202hs0102', 'fl31ca102ds0405',
        'fl41ca201hs0101', 'fl31ca102es0309', 'fl31ca102gs0503', 'fl31ca103es0303',
        'fl31ca401cs0505', 'fl41ca202gs0502', 'fl41ca202hs0507', 'fl41ca202hs0408',
        'fl31ca102hs0304', 'fl31ca103es0201'
    ]
    node_cpu_mp = handler.get_cpu(_in)
    logging.info("result: \n")
    logging.info(node_cpu_mp)

    _in = [
        "fl31ca303bs0407", "fl31ca303bs0204", "fl31ca303bs0205", "fl31ca303bs0405",
        "fl31ca303bs0406", "fl31ca303bs0604", "fl31ca303bs0606", "fl31ca303bs0608",
        "fl31ca303bs0609", "fl31ca303bs0607", "fl31ca303bs0602", "fl31ca303bs0601",
        "fl31ca303bs0603", "fl31ca303bs0605", "fl31ca303bs0306", "fl31ca303bs0304",
        "fl31ca303bs0305", "fl31ca303bs0302", "fl31ca303bs0303", "fl31ca303as0106",
        "fl31ca303as0101", "fl31ca303as0102", "fl31ca303as0103", "fl31ca303as0107",
        "fl31ca303bs0401", "fl31ca303bs0308"
    ]
    node_cpu_mp = handler.get_cpu(_in)
    logging.info("result: \n")
    logging.info(node_cpu_mp)
