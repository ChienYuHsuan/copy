import logging

from asv_pipeline.clusterscope import handler
from asv_pipeline.clusterscope.poolname import parse

log = logging.getLogger(__name__)


def test_instant_query_by_name():
    suts = ["r008s002.zp31l10b01", "fl31ca105bs0117", "fl31ca105bs0201", "fl31ca105bs0210"]
    rst = {}
    a, b = handler.get_pool_by_nodes(suts)
    print(a, b)
    for k, v in a.items():
        rst[k] = str(v)

    for k, v in b.items():
        rst[k] = v
    print(rst)


def test_metadata_by_node():
    suts = ["fl31ca102gs0204"]
    meta = handler.get_metadata_by_nodes(suts)

    assert meta[0]["name"] == suts[0]

    locations = handler.get_location_by_nodes(suts)
    assert locations[meta[0]["name"]] == meta[0]["location"]

    pools, _ = handler.get_pool_by_nodes(suts)
    assert str(pools[meta[0]["name"]]) == meta[0]["pool"]
    print(meta)


def test_get_location_by_node():
    suts = ["fl31ca102gs0204"]
    rst = handler.get_location_by_nodes(suts)
    print(rst)


def test_get_nodes_by_poolname():
    query_pool_names = ["SRF"]
    ret = handler.get_nodes_by_poolname(query_pool_names, 'bhs')
    log.info(ret)


def test_get_cpu_by_nodes():
    logging.info(handler.get_cpu(["fl41ca201ds0607"]))


def test_poolname_desc():
    out = parse("SRF-AP_C0-ES2_PLN_EXC_PIV_DPMO-AC--BKC20-IO1_CATYLEE")
    logging.info(out)
    logging.info(out.test_description)
