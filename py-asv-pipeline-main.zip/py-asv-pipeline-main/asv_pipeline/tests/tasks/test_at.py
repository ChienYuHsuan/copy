import logging
import re
from datetime import datetime
from unittest.mock import MagicMock, patch

import pytz

from asv_pipeline.clusterscope.handler import estimate_tags_in_test_desc, get_pool_name
from asv_pipeline.sharepoint.at import (compare_desc_with_pattern, load_pipelines,
                                        load_raw_pipelines, load_task_definition, load_tasks,
                                        load_testname_in_pipelines, match_desc_with_pattern,
                                        meet_test_criteria)
from asv_pipeline.tasks.at import (determine_rerun_tasks, find_next_task, get_at_next_step,
                                   get_current_task_iteration, load_and_prepare_data)
from asv_pipeline.tasks.clusterscope import get_cpu
from asv_pipeline.tasks.elasticsearch.es_burning_tracker import check_burnin_tracker
from asv_pipeline.tasks.elasticsearch.es_tests import get_test_summary
from asv_pipeline.tasks.kubernetes import get_derivatives_by_namespace
from asv_pipeline.util import get_cluster_by_naming, get_ww
from fixtures.context import sharepoint_pipeline_fixture, sharepoint_task_fixture  # noqa: F401


@patch("asv_pipeline.sharepoint.at._crawl_task_from_sharepoint", return_value=MagicMock())
def test_rerun_tasks(
        mock_crawler,
        sharepoint_pipeline_fixture,  # noqa: F811
        sharepoint_task_fixture):  # noqa: F811
    mock_crawler.return_value = sharepoint_pipeline_fixture
    cache, pl_jobs, ordered_lists, step_taskname, taskname_step, tasks = load_and_prepare_data()

    cur_mission = "BURNIN"
    tag = "DEMO"
    task_mp = {
        'fl31ca302as1009': {
            'srf-ap-burnin-demo-demo-at-ww03-4': {
                'sandstone-rf-warm': ['ABORTED', 0.17406194444444445],
                'killer-pod': ['UNKNOWN', 0.07140194444444445],
                'RMT': 'Fail',
                'AMT': 'Fail',
                'OMT': 'Fail'
            },
            'srf-ap-burnin-rer-1-demo-at-ww03-3': {
                'killer-pod': ['UNKNOWN', 6.35614],
                'sandstone-rf-cold': ['ABORTED', 0.1740488888888889],
                'ive-povray-rf-cold': ['PASSED', 1.0082216666666666]
            },
            'srf-ap-burnin-demo-at-ww03-3-2': {
                'sandstone-rf-warm': ['ABORTED', 0.17413833333333334],
                'killer-pod': ['UNKNOWN', 0.058437777777777776],
                'RMT': 'Fail',
                'AMT': 'Fail',
                'OMT': 'Fail'
            },
            'nan': {
                'Warm_Reset_OS': ['PASSED', 0.07805555555555556]
            }
        }
    }
    out = determine_rerun_tasks(task_mp, "fl31ca302as1009", taskname_step, "SRF-AP", cur_mission,
                                tag, cache)
    logging.info(out)


@patch("asv_pipeline.sharepoint.at._crawl_task_from_sharepoint", return_value=MagicMock())
def test_at_next_step_from_dpmo(
        mock_crawler,
        sharepoint_pipeline_fixture,  # noqa: F811
        sharepoint_task_fixture):  # noqa: F811

    mock_crawler.return_value = sharepoint_pipeline_fixture
    cache = load_raw_pipelines()
    P, ordered_lists = load_pipelines(cache)

    mock_crawler.return_value = sharepoint_task_fixture
    tasks = load_tasks()
    desc = "DPMO-WARM--DEMO"
    cur_mission = match_desc_with_pattern(desc, tasks)
    logging.info(cur_mission)
    _, _, _, tag = estimate_tags_in_test_desc(desc)

    logging.info(tag)
    out = find_next_task(ordered_lists, "SRF-AP", cur_mission, tag)
    logging.info(out)

    desc = "DPMO-WARM-1000--DEMO"
    cur_mission = match_desc_with_pattern(desc, tasks)
    logging.info(cur_mission)
    _, _, _, tag = estimate_tags_in_test_desc(desc)

    logging.info(tag)
    out = find_next_task(ordered_lists, "SRF-AP", cur_mission, tag)
    logging.info(out)

    out = get_current_task_iteration(P, "SRF-AP", cur_mission, tag)
    logging.info(out)

    desc = "BURNIN-DEMO--DEMO"
    cur_mission = match_desc_with_pattern(desc, tasks)
    logging.info(cur_mission)
    out = find_next_task(ordered_lists, "SRF-AP", cur_mission, tag)
    logging.info(out)

    cur_mission = compare_desc_with_pattern("SRF-AP", desc, tasks)
    logging.info(cur_mission)

    desc = "DPMO-WARM-1000--DEMO"
    cur_mission = compare_desc_with_pattern("SRF-AP", desc, tasks)
    logging.info(cur_mission)

    desc = "DPMO-WARM-1000--BKC27-M27-IO13-DEMO"
    bkc, mem, io, tag = estimate_tags_in_test_desc(desc)
    logging.info(f"{bkc} | {mem} | {io} | {tag}")


def test_at_next_step():
    # suts = ["fl31ca302as1009", "fl31ca302bs0807", "fl31ca302as1007", "fl31ca303as0604"]
    suts = ["fl31ca303bs0104"]
    logging.info(get_at_next_step(suts))


@patch("asv_pipeline.sharepoint.at._crawl_task_from_sharepoint", return_value=MagicMock())
def test_at_pipeline(
        mock_crawler,
        sharepoint_pipeline_fixture,  # noqa: F811
        sharepoint_task_fixture):  # noqa: F811
    logging.info(mock_crawler)

    mock_crawler.return_value = sharepoint_pipeline_fixture
    cache = load_raw_pipelines()
    rst, ordered_lists = load_pipelines(cache)
    # logging.info(mock_crawler.return_value)
    logging.info(rst)
    logging.info(ordered_lists)
    # mock_crawler.return_value = sharepoint_pipeline_fixture
    step_taskname, taskname_step = load_testname_in_pipelines(cache)

    mock_crawler.return_value = sharepoint_task_fixture
    tasks = load_tasks()

    for cpu, ctx in rst.items():
        logging.info(f"CPU {cpu}")

        for k, _ in ctx.items():
            if not compare_desc_with_pattern(cpu, f"{k}--", tasks):
                logging.error(f"{cpu}'s pipeline owns undefined task {k}--")

    sut = "fl31ca303bs0104"
    logging.info(step_taskname)
    logging.info(taskname_step)
    logging.info("=" * 39)
    logging.info(tasks)
    logging.info("=" * 39)

    mock_crawler.assert_called()

    from datetime import datetime, timedelta

    import pandas as pd
    import pytz

    timezone = pytz.utc
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(days=14)).astimezone(timezone)

    oneof = [("kubernetes.host", [sut])]
    rst = get_test_summary(cluster="bhs", is_fields=None, oneof_fields=oneof, day=0, start=_begin,
                           end=_now)
    logging.info(len(rst))
    if rst:
        result = [el['_source'] for el in rst]
        df = pd.json_normalize(result)

        burnin_result = check_burnin_tracker([sut], days=14, begin=_begin)
        logging.info(len(burnin_result))
        logging.info(burnin_result[0])

        # logging.info(df[(df["kubernetes.host"] == "fl31ca303as0409") & (df["metadata.test.name"].isin(["ive-povray-rf-cold","sandstone-rf-cold",
        #                                                                                                       "sandstone-rf-warm","vss-unified","shc","srf-tsl","sandstone-release",

        task_mp = {}
        for el in df[df["kubernetes.host"] == sut].to_dict(orient='records'):
            # try:
            #     if isinstance(el["metadata.test.pipeline"], float) or not re.search(
            #             r'Burn', el["metadata.test.pipeline"], re.IGNORECASE):
            #         continue
            # except Exception:
            #     logging.error(el["metadata.test.pipeline"])
            #     logging.error(type(el["metadata.test.pipeline"]))
            #     raise
            task_mp.setdefault(el["kubernetes.host"], {}).setdefault(
                el["kubernetes.namespace_name"],
                {})[el["metadata.test.name"]] = [el["result"], el["duration"]]

        for n in task_mp:
            for el in burnin_result:
                # el['namespace'] = "srf-ap-burnin-at-ww46-3"
                if el['host'] != n or 'Namespace' not in el:
                    continue
                for ns in task_mp[n]:
                    if ns == el['Namespace']:
                        task_mp[n][ns]["RMT"] = "Pass" if re.search(r'Pass',
                                                                    el['RMT result']) else "Fail"
                        task_mp[n][ns]["AMT"] = "Pass" if re.search(
                            r'Pass', el["AdvMemTest result"]) else "Fail"
                        task_mp[n][ns]["OMT"] = "Pass" if re.search(
                            r'Pass',
                            el["OS margin result"][0] if el["OS margin result"] else "") else "Fail"
        logging.info(task_mp)

        poolname = get_pool_name([sut])[sut]

        logging.info(poolname.test_description)
        logging.info(poolname.cpu)
        logging.info(poolname.stepping)
        cur_mission = match_desc_with_pattern(poolname.test_description, tasks)
        cpu = poolname.cpu
        logging.info(cur_mission)

        rerun = set()

        # In general, we should only get one namespace within 2 weeks, because burnin takes almost 10-14 days
        logging.info(task_mp[sut])
        ns = list(task_mp[sut].keys())[0]
        for testname, steps in taskname_step[cpu]['default']['BURNIN'].items():
            logging.info(testname)
            if not meet_test_criteria(cpu=cpu, pipeline="BURNIN", testname=testname,
                                      datasource=task_mp[sut][ns], doc=cache):
                rerun.update(steps)

        if not rerun:
            if match_desc_with_pattern(poolname.test_description, tasks):
                logging.info("go next cycle")

        nxt = 0
        has_nxt = False
        while nxt < len(ordered_lists[cpu]['default']):
            if cpu in ordered_lists and ordered_lists[cpu]['default'][nxt] == cur_mission:
                nxt += 1
                has_nxt = True
                break
            nxt += 1
        if has_nxt:
            logging.info(f"nxt task {ordered_lists[cpu]['default'][nxt]}")
            logging.info(rerun)

        # meta = get_metadata_by_nodes([sut])
        # logging.info(meta)
        # logging.info(status(get_cluster_by_naming(sut), sut))

        # logging.info([meta[0].get('qdf', 'NA')])
        # logging.info(check_stepping_qdf(get_cluster_by_naming(sut), sut))


@patch("asv_pipeline.sharepoint.at._crawl_task_from_sharepoint", return_value=MagicMock())
def test_rdy_transition(
        mock_crawler,
        sharepoint_pipeline_fixture,  # noqa: F811
        sharepoint_task_fixture):  # noqa: F811

    mock_crawler.return_value = sharepoint_pipeline_fixture
    cache = load_raw_pipelines()
    pipelines, _ = load_pipelines(cache)

    logging.info(pipelines)

    mock_tasks = {"fl31ca302as1009": "SierraForest-AP/Main pipelines/SRF-Burn-in-Pipeline"}
    mock_nodes = ["fl31ca302as1009"]

    mock_crawler.return_value = sharepoint_task_fixture
    jobs = load_tasks()

    cpu_to_job = {}
    for job, _tasks in jobs.items():
        for cpu, task in _tasks.items():
            cpu_to_job.setdefault(cpu, {})[task] = job
    # logging.info(cpu_to_job)

    cpus = get_cpu([x for x in mock_tasks])
    ww = get_ww()

    ns_clusters = {}
    cluster_pairs = {}
    rst = {}

    poolnames = get_pool_name(mock_nodes)

    for node, task in mock_tasks.items():
        if node not in mock_nodes:
            continue
        cpu = cpus[node]
        tags = estimate_tags_in_test_desc(poolnames[node].test_description)
        base_ns = f"{cpu}-{cpu_to_job[cpu][task]}-{tags[-1]}-at-{ww}-{datetime.now().astimezone(pytz.UTC).strftime('%w')}".lower(
        )

        cluster = get_cluster_by_naming(node)
        logging.info(cluster)
        derivatives = set(get_derivatives_by_namespace(cluster, base_ns))

        ns = next((f'{base_ns}-{i}' for i in range(2, 1000) if f'{base_ns}-{i}' not in derivatives),
                  base_ns)

        ns_clusters.setdefault(ns, set()).add(cluster)
        cluster_pairs.setdefault(cluster, set()).add((cpu.upper(), task, ns, tags[-1]))
        rst[node] = ns

    logging.info(ns_clusters)
    logging.info(cluster_pairs)
    logging.info(rst)

    for c, values in cluster_pairs.items():
        for cpu, task, ns, tag in values:
            logging.info(f"Cluster: {c} CPU: {cpu} Task: {task} Namespace: {ns} Tag: {tag}")
            payload = {'ns': ns, 'kubeconfig': c}

            payload["cluster"] = ('emr' if re.search(r'EMR', cpu) else 'gnr' if re.search(
                r'GNR', cpu) else 'srf' if re.search(r'SRF', cpu) else 'spr')
            logging.info(f"Payload: {payload}")
            jk_params = load_task_definition(task, payload) or payload
            _task = task.split('@')[0] if '@' in task else task
            logging.info(f"Jenkins Params: {jk_params}, Task: {_task}")

            test_contents = pipelines.get(cpu, {}).get(tag,
                                                       pipelines.get(cpu, {}).get('default', {}))
            logging.info(test_contents)

            demand_contents = test_contents.get(cpu_to_job[cpu][task], {}).get('tasks', [])
            logging.info(demand_contents)
            if not demand_contents:
                jk_params.update({"RUN_ALL": True})
            else:
                jk_params.update({"RUN_ALL": False})
                jk_params.update({x: True for x in demand_contents})

            logging.info(f"Jenkins Params: {jk_params}, Task: {_task}")
