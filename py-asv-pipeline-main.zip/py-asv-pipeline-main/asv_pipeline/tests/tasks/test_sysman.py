from tasks.sysman import ac_cycle, status

from asv_pipeline.util import get_cluster_by_naming


def test_status():
    """
    the test takes almost the boundry of the execution timeout (300)
    =============================================== slowest 5 durations ===============================================
    289.59s call     asv_pipeline/tests/tasks/test_sysman.py::test_status
    0.00s setup    asv_pipeline/tests/tasks/test_sysman.py::test_status
    0.00s teardown asv_pipeline/tests/tasks/test_sysman.py::test_status
    ========================================== 1 passed in 289.62s (0:04:49) ==========================================
    """
    print(status("flex", "fl41ca202gs1104"))


def test_ac_cycle():
    sut = "fl41ca202gs1104"
    ac_cycle(get_cluster_by_naming(sut), sut)
