import logging

from tasks.dpmo import (check_knob_bifurcation, check_knob_dimm_samsung5600,
                        create_dpmo_jira_description, create_dpmo_jira_summary, cycle_launcher,
                        update_knob_bifurcation, update_knob_dimm_samsung5600)
from util import get_cluster_by_naming

sut = "fl31ca302bs0701"
idsid = "catylee"
cpu = "SRF-AP"
cycle_type = 'Cold_Reset_Redfish'
iterations = 5
bkc_name = 'SRF-AP_DPMO_BKCR19'


def test_cycle_launcher():
    logging.info(cycle_launcher(get_cluster_by_naming(sut), sut, idsid))
    assert False


def test_check_bifurcation():
    logging.info(check_knob_bifurcation(get_cluster_by_naming(sut), sut, idsid))
    assert False


def test_check_dimm_samsung5600():
    logging.info(check_knob_dimm_samsung5600(get_cluster_by_naming(sut), sut, idsid))
    assert False


def test_update_knob_bifurcation():
    logging.info(update_knob_bifurcation(get_cluster_by_naming(sut), sut, idsid))
    assert False


def test_update_knob_samsung5600():
    logging.info(update_knob_dimm_samsung5600(get_cluster_by_naming(sut), sut, idsid))
    assert False


def test_create_dpmo_jira_summary():
    result = "SRF-AP - DPMO Cold resets [SRF-AP_DPMO_BKCR19] WW25.2 - 1 node"
    test_result = create_dpmo_jira_summary(cpu, cycle_type, [sut], bkc_name)
    logging.info(test_result)
    assert test_result == result


def test_create_dpmo_jira_description():
    """
        *EXECUTION_TYPE
        cycle_test
        *CYCLE_TYPE
        Cold_Reset_Redfish
        *VALIDATION_TYPE
        OS_validation
        *ITERATIONS
        5
        *HOSTNAMES
        fl31ca302bs0701
        fl31ca302bs0707
        *BKC_NAME
        SRF-AP_DPMO_BKCR19
        *IGNORE_DEVICES
        1
    """
    logging.info(
        create_dpmo_jira_description(cycle_type, iterations, [sut], bkc_name, ignore_devices=True))
    assert False
