import logging

from asv_pipeline.tasks.elasticsearch import es_tests

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def test_get_test_summary():
    sut = "fl31ca102gs0807"
    testname = "paiv-pnp-srf-main-mlc-bandwidth"
    query_rst = es_tests.get_test_summary(cluster="zp31", sut=sut, testname=testname)
    possible_result = ["PASSED", "UNKNOWN", "FAILED", "ABORTED"]
    if len(query_rst) > 0:
        for x in query_rst:
            meta_test_name = x['_source']["kubernetes.labels.name"]
            if testname == meta_test_name:
                test_result = x['_source']["result"]
                logging.debug(test_result)
                if test_result in possible_result:
                    return True
    assert False


def test_get_validation_test_result():
    from asv_pipeline.sharepoint import get_test_report

    # suts = ['fl31ca303bs0509', 'fl31ca303bs0403', 'fl31ca303bs0307', 'fl31ca303as0101']
    rst = get_test_report.get_data(day=1, start=None, end=None, ns=None)

    # rst = get_test_report.get_result(df=rst, type='latest', suts=suts, ns= None, start = None, end = None, testname=None, day=20)
    print(rst.head(2).to_dict())
