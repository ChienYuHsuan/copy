import logging
import re
from unittest.mock import MagicMock, patch

import pytest
from tasks.os import (bootorder, ethtool, get_cvl_cards, hook_processor, is_reachable, is_sgx,
                      is_tdx, isDIMMSamsung5600, pingable, sys_check, verify_sys_check_result)
from util import get_cluster_by_naming

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
# def test_os():
#     out = sys_check("icx-1","r003s006.zp31l10b01")
#     logging.info(out[:512])
#     assert True


def test_ethtool():
    # out, mp = ethtool("icx-1","r012s016.zp31l10b01")
    # logging.info(out)
    # logging.info(mp)

    node = 'zp3110b001s0310'
    out, mp = ethtool(get_cluster_by_naming(node), node)
    logging.info(out)
    logging.info(mp)
    assert False


def test_bootorder():
    sut = "r012s005.zp31l10b01"
    order, mp = bootorder(get_cluster_by_naming(sut), sut)
    logger.info(order)
    logger.info(mp)

    _, kv = ethtool(get_cluster_by_naming(sut), sut)
    logger.info(kv)
    mac = None
    for k, v in kv.items():
        if v['ipaddr']:
            mac = v['mac']
            break
    MAC = "".join(mac.split(":")).upper()
    logger.info(MAC)

    for k, v in mp.items():
        if MAC in v and re.search(r'PXEv4', v):
            logger.info("=" * 63)
            logger.info("%s [%s] needs to be the first" % (k, v))
            logger.info("=" * 63)
    assert False


def test_sys_check():

    sut = 'zp3110b001s0310'
    logger.info(verify_sys_check_result(sys_check(get_cluster_by_naming(sut), sut)))
    assert False


def test_is_reachable():
    sut = "r02s14.op20lmain3"
    logger.info("start to chekc %s" % sut)
    logger.info(is_reachable(get_cluster_by_naming(sut), sut, timeout=(10, 3)))
    logger.info("=" * 63)

    sut = "r002s011.fl30lne001"
    logger.info("start to chekc %s" % sut)
    logger.info(is_reachable(get_cluster_by_naming(sut), sut, timeout=(10, 3)))
    logger.info("=" * 63)

    sut = "zp3110b001s0310"
    logger.info("start to chekc %s" % sut)
    logger.info(is_reachable(get_cluster_by_naming(sut), sut, timeout=(10, 3)))
    logger.info("=" * 63)

    assert False


def test_get_cvl_cards_bhs():
    sut = "fl31ca102fs0201"
    logging.info(get_cvl_cards(get_cluster_by_naming(sut), sut))
    assert False


def test_isDIMMSamsung5600_bhs():
    sut = "fl31ca102fs0201"
    logging.info(isDIMMSamsung5600(get_cluster_by_naming(sut), sut))
    assert False


def test_get_cvl_cards_zp31():
    sut = "zp3110b001s1412"
    logging.info(get_cvl_cards(get_cluster_by_naming(sut), sut))
    assert False


def test_isDIMMSamsung5600_zp31():
    sut = "zp3110b001s1412"
    logging.info(isDIMMSamsung5600(get_cluster_by_naming(sut), sut))
    assert False


@pytest.fixture
def mock_bastion():
    with patch('asv_pipeline.tasks.os.expect_handler.bastion') as mock_bastion:
        mock_eb = MagicMock()
        mock_bastion.return_value = mock_eb
        mock_eb.sendline.return_value = None
        mock_eb.expect.return_value = None
        mock_eb.before = '''
PING test.evfinfra.intel.com (10.75.52.79) 56(84) bytes of data.

--- test.evfinfra.intel.com ping statistics ---
5 packets transmitted, 5 received, 0% packet loss, time 4001ms

'''
        yield mock_bastion


def test_sut_pingable_success(mock_bastion):
    sut = 'fl31ca102fs0201'
    mock_eb = mock_bastion.return_value
    mock_eb.before = '''
PING test.evfinfra.intel.com (10.75.52.79) 56(84) bytes of data.

--- test.evfinfra.intel.com ping statistics ---
5 packets transmitted, 5 received, 0% packet loss, time 4001ms

'''
    assert pingable(get_cluster_by_naming(sut), sut) == True
    mock_bastion.assert_called_once()


def test_sut_pingable_failure(mock_bastion):
    sut = 'fl31ca102fs0201'
    mock_eb = mock_bastion.return_value
    mock_eb.before = '''
PING test.evfinfra.intel.com (10.75.52.79) 56(84) bytes of data.

--- test.evfinfra.intel.com ping statistics ---
5 packets transmitted, 0 received, 100% packet loss, time 4421ms

'''
    assert pingable(get_cluster_by_naming(sut), sut) == False
    mock_bastion.assert_called_once()


def test_is_tdx():
    sut = 'fl41ca202hs0303'
    logging.info(is_tdx(get_cluster_by_naming(sut), sut))


def test_is_sgx():
    sut = 'fl41ca202hs0303'
    logging.info(is_sgx(get_cluster_by_naming(sut), sut))


def test_hook_processor():
    sut = 'fl31ca303bs0104'
    logging.info(hook_processor(get_cluster_by_naming(sut), sut, idsid="sys_asvauto", cpu="SRF-AP"))
    logging.info(
        hook_processor(get_cluster_by_naming(sut), sut, idsid="sys_asvauto", cpu="SRF-AP",
                       is_preprocess=False, need_git_pull=False))
