import logging
import re
from datetime import datetime

import numpy
import pytz
from clusterscope.poolname import parse as cs_poolname_parser
from util import change_time_format

import asv_pipeline.config as cfg
from asv_pipeline.es import ES

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class ESFactory:
    _instances = {}

    def __call__(cls, *args, **kwargs):
        """
        Possible changes to the value of the `__init__` argument do not affect
        the returned instance.
        """
        if cls not in cls._instances:
            instance = super().__call__(*args, **kwargs)
            cls._instances[cls] = instance
        return cls._instances[cls]

    def __init__(self):
        cluster = 'zp31'
        self.es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
                     password=cfg.es_password.get(cluster))

        timezone = pytz.utc
        _end = datetime.strptime(change_time_format('2024-09-24 00:00:00 UTC'),
                                 '%a %d %b %Y %I:%M:%S %p %Z')
        _begin = datetime.strptime(change_time_format('2024-07-01 00:00:00 UTC'),
                                   '%a %d %b %Y %I:%M:%S %p %Z')
        self.es.index('dev-phoenix_pool_states-').range(_begin, _end, timezone.zone)

        self.duration_key = "duration_sec"
        self.unit = 'sec'

        # self.es.index('phoenix_pool_states-').range(_begin, _end, timezone.zone)

        # self.duration_key = "duration"
        # self.unit = 'hrs'


def test_try_query():
    qry = ESFactory().es.build()
    rst = ESFactory().es.execute(timeout=1200, payload=qry)
    logging.info(rst)
    logging.info(len(rst))


def test_max_min():
    logger.warning("== test_max_min ===")
    qry = ESFactory().es.IS("phoenix_pool_state", "RDY").IS("next_state"
                                                            "EXC").build()
    #  .IS("phoenix_pool_cpu","SRF-AP") \

    rst = ESFactory().es.execute(timeout=1200, payload=qry)
    data = {}
    for e in rst:
        src = e['_source']
        if re.search(r'--', src['phoenix_pool']) and not re.search(r'PCE', src['phoenix_pool']):
            key = f"{src['phoenix_pool']}_{src.get('host', src.get('phoenix_host', ''))}_{src['@timestamp']}"
            count = 1
            while key in data:
                key += f"_{count}"
                count += 1
            data[key] = src[ESFactory().duration_key]

    rst = {key: value for key, value in sorted(data.items(), key=lambda x: x[1], reverse=True)}
    keys = list(rst.keys())
    logger.warning(f"max duration : {keys[0]} : {rst[keys[0]]}")
    logger.warning(f"min duration : {keys[-1]} : {rst[keys[-1]]}")


def test_percentage_autotrigger():

    logger.warning("== PERCENTAGE using autotrigger===")
    qry = ESFactory().es.IS("phoenix_pool_state", "RDY").IS("next_state", "EXC").build()
    #  .IS("phoenix_pool_cpu","SRF-AP") \

    rst = ESFactory().es.execute(timeout=1200, payload=qry)
    # logger.info(rst)
    total = len(rst)
    cnt = 0
    logger.info(f'total size: {len(rst)}')
    for e in rst:
        src = e['_source']
        if re.search(r'--', src['phoenix_pool']):
            cnt += 1
    if cnt:
        logger.warning(
            f'Final number for percentage of autotrigger {cnt}/{total} %: {round(float(cnt / total) * 100, 2)}%'
        )


def test_percentage_autotrigger_for_srf_ap():

    logger.warning("== PERCENTAGE using autotrigger for srf_ap===")
    qry = ESFactory().es.IS("phoenix_pool_state",
                            "RDY").IS("next_state", "EXC").IS("phoenix_pool_cpu", "SRF-AP").build()

    rst = ESFactory().es.execute(timeout=1200, payload=qry)
    total = len(rst)
    cnt = 0
    logger.info(f'total size: {len(rst)}')
    for e in rst:
        src = e['_source']
        if re.search(r'--', src['phoenix_pool']):
            cnt += 1
    if cnt:
        logger.warning(
            f'Final number for percentage of autotrigger in SRF-AP {cnt}/{total} %: {round(float(cnt / total) * 100, 2)}%'
        )


def test_duration_from_rdy_exc_without_at():

    logger.warning("== test_duration_from_rdy_exc_without_at")
    qry = ESFactory().es.IS("phoenix_pool_state", "RDY").IS("next_state", "EXC").build()

    rst = ESFactory().es.execute(timeout=1200, payload=qry)
    data = []
    logger.info(f'total size: {len(rst)}')
    for e in rst:
        src = e['_source']
        if not re.search(r'--', src['phoenix_pool']):
            data += [src[ESFactory().duration_key]]
            # logger.info(f"{src['phoenix_pool']} from RDY to {src['next_state']}")
    if data:
        logger.warning(
            f'Final median duration from RDY to EXC w/o AT {numpy.median(data)} {ESFactory().unit}')
        logger.warning(
            f'Final mean duration from RDY to EXC w/o AT {round(numpy.mean(data), 2)} {ESFactory().unit}'
        )


def test_duration_from_rdy_exc_with_at():

    logger.warning("== test_duration_from_rdy_exc_with_at")
    qry = ESFactory().es.IS("phoenix_pool_state", "RDY").IS("next_state", "EXC").build()

    rst = ESFactory().es.execute(timeout=1200, payload=qry)
    data = []
    cnt, failure = 0, 0
    logger.info(f'total size: {len(rst)}')
    for e in rst:
        src = e['_source']
        if re.search(r'--', src['phoenix_pool']) and not re.search(r'PCE', src['phoenix_pool']):
            cnt += 1
            try:
                cs_poolname_parser(src['phoenix_pool'])
                data += [src[ESFactory().duration_key]]
            except Exception:
                failure += 1
                pass
    if data:
        logger.warning(
            f'Final median duration from RDY to EXC with AT {numpy.median(data)} {ESFactory().unit}'
        )
        logger.warning(
            f'Final mean duration from RDY to EXC with AT {round(numpy.mean(data), 2)} {ESFactory().unit}'
        )
    if failure:
        logger.warning(f'man error rate  {round(float(failure / cnt) * 100, 2)} %')


def test_duration_from_rdy_exc_with_at_plus_exception():

    logger.warning("== test_duration_from_rdy_exc_with_at_plus_man_handle")
    qry = ESFactory().es.IS("phoenix_pool_state", "RDY").IS("next_state", "EXC").build()

    rst = ESFactory().es.execute(timeout=1200, payload=qry)

    data = []
    cnt, failure = 0, 0
    logger.info(f'total size: {len(rst)}')
    for e in rst:
        src = e['_source']
        if re.search(r'--', src['phoenix_pool']):
            cnt += 1
            try:
                cs_poolname_parser(src['phoenix_pool'])
                data += [src[ESFactory().duration_key]]
            except Exception:
                failure += 1
                pass
    if data:
        logger.warning(
            f'Final median duration from RDY to EXC with AT plus exception {numpy.median(data)} {ESFactory().unit}'
        )
        logger.warning(
            f'Final mean duration from RDY to EXC with AT plus exception {round(numpy.mean(data), 2)} {ESFactory().unit}'
        )
    if failure:
        logger.warning(f'man error rate  {round(float(failure / cnt) * 100, 2)} %')


def test_duration_from_rer_rdy_or_exc():

    logger.warning("== test_duration_from_rer_rdy_or_exc ===")
    qry = ESFactory().es.IS("phoenix_pool_state", "RER").oneOf("next_state", ["EXC", "RDY"]).build()

    rst = ESFactory().es.execute(timeout=1200, payload=qry)

    data = []
    cnt, failure = 0, 0
    logger.info(f'total size: {len(rst)}')
    for e in rst:
        src = e['_source']
        if re.search(r'--', src['phoenix_pool']):
            cnt += 1
            try:
                cs_poolname_parser(src['phoenix_pool'])
                data += [src[ESFactory().duration_key]]
            except Exception:
                failure += 1
                pass
    if data:
        logger.warning(
            f'Final median duration from RER to EXC or RDY {numpy.median(data)} {ESFactory().unit}')
        logger.warning(
            f'Final mean duration from RER to EXC or RDY {round(numpy.mean(data), 2)} {ESFactory().unit}'
        )
    if failure:
        logger.warning(f'man error rate  {round(float(failure / cnt) * 100, 2)} %')


def test_duration_from_com_rdy_or_exc():

    logger.warning("== test_duration_from_com_rdy_or_exc ===")
    qry = ESFactory().es.oneOf("phoenix_pool_state",
                               ["COM", "EXC"]).oneOf("next_state", ["EXC", "RDY"]).build()

    rst = ESFactory().es.execute(timeout=1200, payload=qry)

    data = []
    cnt, failure = 0, 0
    logger.info(f'total size: {len(rst)}')
    for e in rst:
        src = e['_source']
        if re.search(r'--', src['phoenix_pool']):
            cnt += 1
            try:
                cs_poolname_parser(src['phoenix_pool'])
                data += [src[ESFactory().duration_key]]
            except Exception:
                failure += 1
                pass
    if data:
        logger.warning(
            f'Final median duration from COM to EXC or RDY {numpy.median(data)} {ESFactory().unit}')
        logger.warning(
            f'Final mean duration from COM to EXC or RDY {round(numpy.mean(data), 2)} {ESFactory().unit}'
        )
    if failure:
        logger.warning(f'man error rate  {round(float(failure / cnt) * 100, 2)} %')


def test_duration_staying_rdy():

    logger.warning("== test_duration_staying_rdy ===")
    qry = ESFactory().es.IS("phoenix_pool_state", "RDY").build()

    rst = ESFactory().es.execute(timeout=1200, payload=qry)

    data = []
    cnt, failure = 0, 0
    logger.info(f'total size: {len(rst)}')
    error_set = set()
    for e in rst:
        src = e['_source']
        cnt += 1
        try:
            cs_poolname_parser(src['phoenix_pool'])
            data += [src[ESFactory().duration_key]]
        except Exception:
            failure += 1
            error_set.add(src['phoenix_pool'])
            pass
    if data:
        logger.warning(f'Final median duration staying RDY {numpy.median(data)} {ESFactory().unit}')
        logger.warning(
            f'Final mean duration staying RDY {round(numpy.mean(data), 2)} {ESFactory().unit}')
    if failure:
        logger.warning(f'man error rate  {round(float(failure / cnt) * 100, 2)} %')
        for err in error_set:
            print(f'{err}')


def test_percentage_with_at_in_rdy_in_srf_ap():

    logger.warning("== test_percentage_with_at_in_rdy_in_srf_ap ===")
    qry = ESFactory().es.IS("phoenix_pool_state", "RDY").IS("phoenix_pool_cpu", "SRF-AP").build()

    rst = ESFactory().es.execute(timeout=1200, payload=qry)

    data = []
    cnt, failure, total = 0, 0, len(rst)
    logger.info(f'total size: {len(rst)}')
    for e in rst:
        src = e['_source']
        try:
            cs_poolname_parser(src['phoenix_pool'])
            data += [src[ESFactory().duration_key]]
        except Exception:
            failure += 1
            pass
        if re.search(r'--', src['phoenix_pool']) and not re.search(r'PCE', src['phoenix_pool']):
            cnt += 1
    if data:
        logger.warning(
            f'Final percentage of AT in RDY in SRF-AP ({cnt}/{total}) {round(float(cnt / total), 2) * 100} %'
        )
    if failure:
        logger.warning(f'man error rate  {round(float(failure / total) * 100, 2)} %')


def test_percentage_with_at_in_exc_in_srf_ap():

    logger.warning("== test_percentage_with_at_in_rdy_in_srf_ap ===")
    qry = ESFactory().es.IS("phoenix_pool_state", "RDY").IS("phoenix_pool_cpu", "SRF-AP").build()

    rst = ESFactory().es.execute(timeout=1200, payload=qry)

    data = []
    cnt, failure, total = 0, 0, len(rst)
    logger.info(f'total size: {len(rst)}')
    for e in rst:
        src = e['_source']
        try:
            cs_poolname_parser(src['phoenix_pool'])
            data += [src[ESFactory().duration_key]]
        except Exception:
            failure += 1
            pass
        if re.search(r'--', src['phoenix_pool']) and not re.search(r'PCE', src['phoenix_pool']):
            cnt += 1
    if data:
        logger.warning(
            f'Final percentage of AT in RDY in SRF-AP ({cnt}/{total}) {round(float(cnt / total), 2) * 100} %'
        )
    if failure:
        logger.warning(f'man error rate  {round(float(failure / total) * 100, 2)} %')
