import logging

from tasks.xmlcli import load_default  # restoreknobs
from tasks.xmlcli import get_current_knobs, get_knobs_from_sut, progknobs, readknobs
from util import get_cluster_by_naming

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
sut = "r014s012.zp31l10b01"
idsid = "linnelso"

# logger = logging.getLogger(__name__)
# logger.setLevel(logging.DEBUG)


# def test_xmlcli_progknobs():
#     knobs = "BootOrder_0=1"
#     progknobs("icx-1", "r003s006.zp31l10b01", knobs)
#     assert False
def test_xmlcli_progknobs():
    knobs = "serialDebugMsgLvl=4,AttemptFastBoot=0x0,AttemptFastBootCold=0x0,AllowedSocketsInParallel=1"
    logging.info(progknobs(get_cluster_by_naming(sut), sut, idsid, knobs, False))
    assert False


def test_xmlcli_readknobs():
    knobs = "serialDebugMsgLvl=2,AttemptFastBoot=0x0,AttemptFastBootCold=0x0,AllowedSocketsInParallel=1"
    logging.info(readknobs(get_cluster_by_naming(sut), sut, idsid, knobs))
    assert False


def test_get_knobs_from_sut():
    sut = 'fl31ca303as0604'
    logging.info(get_knobs_from_sut(get_cluster_by_naming(sut), sut, idsid="sys_asvauto"))
    logging.info("go with TAG")
    logging.info(get_knobs_from_sut(get_cluster_by_naming(sut), sut, idsid="sys_asvauto",
                                    tag="PNP"))
    assert True


# def test_xmlcli_getbootorder():
#     # 23-13-03-01-00-02-04-05-06-07-08-09-0A-0B-0C-0D-0E-0F-10-11-12-14-15-16-17-18-19-1A-1B-1C-1D-1E-1F-20-21
#     order, mp = _getbootorder("icx-1","r008s019.zp31l10b01")
#     assert False

# def test_xmlcli_progknobs():
#     knobs = "BootOrder_0=0x1B,BootOrder_1=0x06"
#     logger.info(progknobs("icx-1","r003s006.zp31l10b01", knobs))
#     assert False


def test_xmlcli_restore_knob():
    rst = load_default(get_cluster_by_naming(sut), sut, idsid, False)
    print(rst)
    assert False


def test_xmlcli_get_current_knobs():
    print(get_current_knobs(get_cluster_by_naming(sut), sut, idsid))
    assert False
