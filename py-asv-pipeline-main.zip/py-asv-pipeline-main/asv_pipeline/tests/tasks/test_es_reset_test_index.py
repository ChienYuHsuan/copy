import logging

from pytz import timezone

from asv_pipeline.tasks.elasticsearch.es_reset_test_index import (check_dpmo_remainder,
                                                                  check_reset_test)

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def test_check_reset_test():
    sut = "fl31ca102fs0304"
    tz = timezone("Asia/Taipei")
    check_reset_test(sut, tz)
    assert False


def test_check_reset_test_with_remainder():
    nodes = ['fl31ca302bs0607']
    rst = check_dpmo_remainder(nodes, min=60 * 24 * 30)
    logging.info(rst)
