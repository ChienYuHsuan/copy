import logging

from asv_pipeline.tasks.jk import burn_in
from asv_pipeline.util import get_cluster_by_naming

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def test_burn_in():
    sut = "r009s006.op20lmain4"
    logger.info(burn_in(get_cluster_by_naming(sut)))
    assert False


def test_jk_build():

    from asv_pipeline.jk import JenkinsFactory
    jf = JenkinsFactory()
    """
    TODO ClusterScope : READY->EXEC
    """
    last_completed_build = jf.jk.get_job_info(
        "Tests/not-ready-node-srf")['lastCompletedBuild']['number']
    last_build = jf.jk.get_job_info("Tests/not-ready-node-srf")['lastBuild']['number']
    print(last_completed_build, last_build)
    last_build_info = jf.jk.get_build_info("Tests/not-ready-node-srf", last_build)["timestamp"]
    last_completed_build_info = jf.jk.get_build_info("Tests/not-ready-node-srf",
                                                     last_completed_build)["timestamp"]
    print(last_build_info, last_completed_build_info)
