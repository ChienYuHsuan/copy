import logging

from asv_pipeline.tasks.bmc import (get_cpu_cpld, get_debug_cpld, get_dimm0_dimm1, get_pfr_cpld,
                                    get_scm_cpld)
from asv_pipeline.util import get_cluster_by_naming


def test_get_debug_cpld():
    sut = 'fl41ca202gs1107'
    idsid = 'linnelso'
    rst = get_debug_cpld(get_cluster_by_naming(sut), sut, idsid)

    assert rst == '0.25'


def test_get_cpu_cpld():
    sut = 'fl41ca202gs1107'
    idsid = 'linnelso'
    rst = get_cpu_cpld(get_cluster_by_naming(sut), sut, idsid)

    assert rst == '0.25'


def test_get_scm_cpld():
    sut = 'fl41ca202gs1107'
    idsid = 'linnelso'
    rst = get_scm_cpld(get_cluster_by_naming(sut), sut, idsid)

    assert rst == '4.15'


def test_get_pfr_cpld():
    sut = 'fl41ca202gs1107'
    idsid = 'linnelso'
    rst = get_pfr_cpld(get_cluster_by_naming(sut), sut, idsid)

    assert rst == '4.11'


def test_get_dimm0_dimm1():
    sut = 'fl41ca202gs1107'
    idsid = 'linnelso'
    rst1, rst2 = get_dimm0_dimm1(get_cluster_by_naming(sut), sut, idsid)

    assert False


def test_bmc_util():

    from asv_pipeline.clusterscope import handler
    from asv_pipeline.sharepoint.report_util import get_bkc_detail
    node = "fl31ca102fs0206"
    meta = handler.get_metadata_by_nodes([node])
    logging.info(meta)
    logging.info("=====test bkc util func=====")
    logging.info(get_bkc_detail(meta[0]))


def test_bmc_i2ctransfer():
    from asv_pipeline.tasks.bmc import transfer_i2c
    node = "fl41ca202fs0707"
    logging.info(transfer_i2c(get_cluster_by_naming(node), node))


def test_bmc_interact_sol():
    import pexpect

    from asv_pipeline.tasks.bmc import interact_sol_for_ip_loss
    node = "fl31ca102gs0906"
    logging.info("=====test bmc interact sol=====")
    try:
        out = interact_sol_for_ip_loss(get_cluster_by_naming(node), node)
        logging.info(out.split("\r\n")[-10:-1])
    except pexpect.exceptions.TIMEOUT:
        logging.error("Timeout")
        assert False
    assert True
