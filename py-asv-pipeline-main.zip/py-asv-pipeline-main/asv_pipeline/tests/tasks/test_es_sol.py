import logging
from datetime import datetime, timedelta

import pytz

import asv_pipeline.config as cfg
from asv_pipeline.es import ES
from asv_pipeline.tasks.elasticsearch import es_sol
from asv_pipeline.util import get_cluster_by_naming, parse_time_for_es

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def test_es_sol_icx():
    cluster = "icx-1"
    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now()
    _begin = _now - timedelta(minutes=10)
    print(_now, _begin)
    qry = es.index('sol') \
            .oneOf('host', ["r003s006.zp31l10b01"]) \
            .range(_begin, _now, "+08:00").build()
    rst = es.execute(timeout=300, payload=qry)
    for x in rst:
        logger.info(
            "%(time)s-%(host)s : %(msg)s" % {
                "time": parse_time_for_es(x['_source']["@timestamp"], pytz.timezone("Asia/Taipei")),
                "msg": x['_source']["message"],
                "host": x['_source']["host"],
            })
        if "iPXE initialising devices...ok" in x['_source']["message"]:
            return True
    assert False


def test_es_sol_opus():
    cluster = "opus-spr"
    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now()
    _begin = _now - timedelta(minutes=10)
    print(_now, _begin)
    qry = es.index('sol') \
            .oneOf('host', ["r009s006.op20lmain4"]) \
            .range(_begin, _now, "+08:00").build()
    rst = es.execute(timeout=300, payload=qry)
    for x in rst:
        logger.info(
            "%(time)s-%(host)s : %(msg)s" % {
                "time": parse_time_for_es(x['_source']["@timestamp"], pytz.timezone("Asia/Taipei")),
                "msg": x['_source']["message"],
                "host": x['_source']["host"],
            })
        if "iPXE initialising devices...ok" in x['_source']["message"]:
            return True
    assert False


def test_es_sol_heart_beat():
    sut = "fl41ca202gs1002"
    rst = es_sol.check_heartbeat(get_cluster_by_naming(sut), sut)
    logging.info(rst)


def test_es_sol_dimm_type():
    sut = "fl41ca202hs0209"
    rst = es_sol.get_dimm_type(get_cluster_by_naming(sut), sut)
    logging.info(rst)

    sut = "fl31ca102ds0109"
    rst = es_sol.get_dimm_type(get_cluster_by_naming(sut), sut)

    logging.info(rst)


def test_es_sol_heart_beat_AT():
    sut = "fl41ca201fs0305"
    end = datetime(2024, 6, 13, 1, 58, 10).astimezone(pytz.UTC)
    start = end - timedelta(minutes=10)
    cluster = get_cluster_by_naming(sut)
    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    logging.info("from:%s, to:%s", start, end)
    qry = es.index('sol-')\
            .IS('host', sut) \
            .oneOf('message', ['SOL Heartbeat'])\
            .range(start, end)\
            .build()

    rst = es.execute(timeout=300, payload=qry)

    qry_raw = es.index('sol_raw-').IS('host', sut).oneOf('message',
                                                         ['Heartbeat']).range(start, end).build()
    rst_raw = es.execute(timeout=300, payload=qry_raw)
    if isinstance(rst, list) or isinstance(rst_raw, list):
        logging.info(len(rst))
        logging.info(len(rst_raw))


def test_es_sol_validate():
    sut = "fl41ca201fs0305"
    assert es_sol.validate_sol_index(get_cluster_by_naming(sut), sut)


def test_is_amt_test():
    sut = "fl31ca103fs0803"
    assert es_sol.is_amt_test(get_cluster_by_naming(sut), sut, range=(12, 0))

    sut = "fl41ca201fs0305"
    assert es_sol.is_amt_test(get_cluster_by_naming(sut), sut, range=(12, 0))
