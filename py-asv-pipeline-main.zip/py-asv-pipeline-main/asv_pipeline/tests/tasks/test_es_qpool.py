import logging
from datetime import datetime, timedelta

import pytz

from asv_pipeline.tasks.elasticsearch.es_qpool import check_heart_beat, verify_knob
from asv_pipeline.util import get_cluster_by_naming

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def test_es_qpool_verify_knob():
    sut = "r009s001.zp31l10b01"
    cluster = get_cluster_by_naming(sut)
    _begin = (datetime.now() - timedelta(hours=4)).astimezone(pytz.timezone("Asia/Taipei"))
    assert verify_knob(cluster, sut, pytz.timezone("Asia/Taipei"), _begin)


def test_es_qpool_heart_beat():
    sut = "fl31ca303as0608"
    rst = check_heart_beat(get_cluster_by_naming(sut), sut)
    logging.info(rst)
