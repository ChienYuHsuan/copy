import logging
import re

from asv_pipeline.tasks.cscript import crashdump

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def test_crashdump():
    rst = crashdump("icx-1", "r003s006.zp31l10b01")
    logger.info(rst)
    assert re.search(r'crashdump_\w+_\w+\.json', rst)
