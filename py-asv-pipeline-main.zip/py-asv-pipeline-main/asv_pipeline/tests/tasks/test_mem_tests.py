import logging
import os

from asv_pipeline.tasks.mem_tests import query_amt, query_os_margin, query_rmt

logging.basicConfig(level=logging.DEBUG)

cluster = 'bhs'
rst = {'fl41ca201hs0508': 'Ready', 'fl41ca201hs0509': 'Ready'}
os.environ["START"] = "Tue 02 Apr 2024 11:05:44 PM UTC"
os.environ["END"] = "Wed 10 Apr 2024 12:14:55 AM UTC"


def test_query_amt():
    amt = query_amt(cluster, rst, 'sol-')
    logging.debug(amt)

    assert amt['fl41ca201hs0508']['results'] == 'No Data' and amt['fl41ca201hs0509'][
        'results'] == 'Pass'


def test_query_amt_raw():
    amt_raw = query_amt(cluster, rst, 'sol_raw-')
    logging.debug(amt_raw)
    assert amt_raw['fl41ca201hs0508']['results'] == 'No Data' and amt_raw['fl41ca201hs0509'][
        'results'] == 'Pass'


def test_query_rmt():
    rmt = query_rmt(cluster, rst)
    logging.debug(rmt)
    assert rmt['fl41ca201hs0508']['status'] == 'Pass (15)' and rmt['fl41ca201hs0509'][
        'status'] == 'Pass (15)'


def test_query_os_margin():
    os_margin = query_os_margin(rst)
    logging.debug(os_margin)
    assert os_margin['fl41ca201hs0508']['results'] == [
        'Fail (Bandwidth avg is 0)'
    ] and os_margin['fl41ca201hs0509']['results'] == ['Pass']
