import logging

from asv_pipeline.tasks.elasticsearch import es_eventlog
from asv_pipeline.util import get_cluster_by_naming


def test_es_eventlog():
    sut = 'fl41ca201ds0607'
    logging.info(get_cluster_by_naming(sut))
    logging.info(es_eventlog.check_critical_event(get_cluster_by_naming(sut), sut, range=(28, 30)))
