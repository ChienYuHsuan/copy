import pytest

from asv_pipeline.tasks.es_eventrouter import extract_log


@pytest.fixture
def TI():

    class Task_instance:

        def __init__(self):
            self.data = {}

        def xcom_push(self, key, value):
            self.data[key] = value

    return Task_instance()


def test_extract_es_eventrouter(TI):
    try:
        rst = extract_log(params={'cluster': 'icx-1', 'period': 16}, ti=TI)
    except Exception as e:
        print(e)
    for log in rst:
        if log['verb'] == "ADDED":
            assert True
            return
    assert False
