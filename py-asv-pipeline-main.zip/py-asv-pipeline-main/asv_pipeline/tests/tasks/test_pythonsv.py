import logging
import re

from tasks.pythonsv import check_stepping_qdf, get_dimm_freq, gnr_mca_error, pure_mca_error, unlock

from asv_pipeline.pythonsv.analyzer import errordump
from asv_pipeline.sharepoint import SharePointFactory
from asv_pipeline.tasks.pythonsv.fstream import stream_upload
from asv_pipeline.util import get_cluster_by_naming
from fixtures.context import generic_mca_fixture, pythonsv_errordump  # noqa: F401

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def test_upload(generic_mca_fixture):  # noqa: F811
    sut = "zp3110b001s0902"
    logging.info(generic_mca_fixture)
    rst, relative = stream_upload(sut, generic_mca_fixture)
    logging.info(rst)
    logging.info(relative)
    assert False


def test_parse_error_dump(pythonsv_errordump):  # noqa: F811
    rst = errordump(pythonsv_errordump)
    assert len(rst) == 54


def test_parse_error_dump_in_real():
    shared_link = "https://intel.sharepoint.com/:t:/s/ScaleInternalCluster/ERSAfqbd13xEr4wiVHXrVogBD-SH8FXM5uRINW194-_P1g"
    matcher = re.match(r'https:.*:t:\/s\/(.*)\/.*', shared_link)
    if not matcher:
        raise Exception(f"cannot parse site info from {shared_link}")
    site = matcher.group(1)
    logging.info(f"site : {site}")
    with SharePointFactory.build(sp_site=f'https://intel.sharepoint.com/sites/{site}'
                                 ).download_from_shared_link(shared_link) as f:
        logging.info(f"File is located at : {f}")
        with open(f) as file:
            ctx = file.read()
            logging.info(len(errordump(ctx)))


def test_unlock():
    sut = "fl31ca102fs0201"
    out = unlock(get_cluster_by_naming(sut), sut)
    logger.info(out)
    assert "Running PMC address WA" in out


def test_pure_mca_emr():
    sut = "zp3110b001s0902"
    out = pure_mca_error(get_cluster_by_naming(sut), sut)
    logging.info(out)
    rst, relative = stream_upload(sut, out)
    logging.info(rst)
    logging.info(relative)
    assert False


def test_check_stepping_qdf():
    sut = "zp3110b001s0902"
    out = check_stepping_qdf(get_cluster_by_naming(sut), sut)
    logger.info(out)

    assert False


def test_get_dimm_info():
    sut = "fl41ca201fs0508"
    out = get_dimm_freq(get_cluster_by_naming(sut), sut)
    logging.info(out)

    assert False


def test_gnr_mca_error():

    import concurrent.futures

    def internal(sut):
        psv = unlock(get_cluster_by_naming(sut), sut, idsid="sys_asvauto", close_required=False)
        psv.eb.timeout = 3600 * 6 + 300
        logging.info("gnr mca error collection")
        outstream = gnr_mca_error(get_cluster_by_naming(sut), sut, idsid="sys_asvauto",
                                  pythonsv=psv)

        logging.info(outstream)

    with concurrent.futures.ThreadPoolExecutor() as executor:
        executor.submit(internal, "fl31ca102hs0103")
        executor.submit(internal, "fl31ca102hs0202")
