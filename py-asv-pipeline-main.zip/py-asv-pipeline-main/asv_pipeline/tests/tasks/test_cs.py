import logging
from unittest.mock import MagicMock, patch

from asv_pipeline.clusterscope.handler import get_pool_name, get_state, update_pool_name
from asv_pipeline.tasks.clusterscope import (get_condidate_for_pool_name_with_pattern_indesc,
                                             get_condidate_for_pool_name_with_prefix_indesc,
                                             get_cpu)
from fixtures.clusterscope import poolname_with_dbg_state  # noqa: F401


def test_get_cpu():
    suts = ["r008s002.zp31l10b01", "fl31ca105bs0117", "fl31ca105bs0201", "fl31ca105bs0210"]
    logging.info(get_cpu(suts))

    assert False


@patch("asv_pipeline.clusterscope.handler.get_pool_by_nodes", return_value=MagicMock())
def test_get_state(mock_fn_get_pool_by_nodes, poolname_with_dbg_state):  # noqa: F811
    suts = ["zp3110b001s0402"]
    mock_fn_get_pool_by_nodes.return_value = {"zp3110b001s0402": poolname_with_dbg_state}, {}
    mp = get_state(suts)
    logging.info(mp)
    assert mp["zp3110b001s0402"] == "DBG"
    mock_fn_get_pool_by_nodes.assert_called()


def test_update_poolname_for_dpmo():
    suts = ["fl31ca102fs0204"]

    update_pool_name(suts, {
        "state": "EXC",
        "assignto": "PLN",
        "subclustername": "PIV",
        "test_description": "TEST-Sirlon"
    })
    rst = get_pool_name(suts)
    print("== start to check result == ")
    for x in rst:
        print(rst[x])


def test_update_poolname_for_at():
    suts = ["fl41ca201fs1209"]

    update_pool_name(suts, {"state": "EXC", "assignto": "PLN", "subclustername": "PIV"})
    rst = get_pool_name(suts)
    print("== start to check result == ")
    for x in rst:
        print(rst[x])


def test_get_condidate_for_pool_name_with_prefix_indesc():
    suts = ['fl41ca201es1105', 'fl41ca201es1108']
    execution, non_execution = get_condidate_for_pool_name_with_prefix_indesc(suts, ['SFT'])
    logging.info("executable")
    for k, v in execution.items():
        ctx = f'{k}:{v}'
        logging.info(ctx)
    logging.info("=" * 33)
    logging.info("non executable")
    for k, v in non_execution.items():
        ctx = f'{k}:{v}'
        logging.info(ctx)

    assert False


def test_get_condidate_for_pool_name_with_pattern_indesc():
    suts = ['fl41ca201es1105', 'fl41ca201es1108']
    execution, non_execution = get_condidate_for_pool_name_with_pattern_indesc(suts, ['SFT'])
    logging.info("executable")
    for k, v in execution.items():
        ctx = f'{k}:{v}'
        logging.info(ctx)
    logging.info("=" * 33)
    logging.info("non executable")
    for k, v in non_execution.items():
        ctx = f'{k}:{v}'
        logging.info(ctx)

    assert False
