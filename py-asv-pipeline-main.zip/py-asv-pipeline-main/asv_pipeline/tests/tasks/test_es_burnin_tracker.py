import logging

from asv_pipeline.tasks.elasticsearch.es_burning_tracker import check_burnin_tracker


def test_check_burnin_tracker():
    suts = ["fl31ca102hs0207"]
    logging.info(check_burnin_tracker(suts))
