import logging

from tasks.kubernetes import (get_all_nodes, get_derivatives_by_namespace, get_labels, get_ns,
                              get_resources, join_cluster, ready)
from util import get_cluster_by_naming, label_4_pipeline


def test_ready():
    assert ready("opus-spr", "r01s17.op20lmain3")


def test_join_cluster():
    join_cluster("icx-1", "r003s006.zp31l10b01")
    pass


def test_get_resources():
    node = "r017s008.fl30lne001"
    ns = "spr-sf-hbmb3-phase2"
    logging.debug(get_resources(get_cluster_by_naming(node), ns))

    assert False


def test_get_without_resources():
    node = "r017s008.fl30lne001"
    ns = "spr-tdx"
    logging.debug(get_resources(get_cluster_by_naming(node), ns))

    assert False


def test_get_labels():
    node = "r017s008.fl30lne001"
    rst = get_labels(get_cluster_by_naming(node), node)

    logging.debug(rst)
    logging.debug(label_4_pipeline({node: rst}))
    assert False


def test_get_nodes():
    cluster = 'icx-1'
    rst = get_all_nodes(cluster)

    logging.debug(rst)
    assert False


def test_get_ns():
    ns = 'srf-ap-main1-ww26-3-srf'
    assert True == get_ns('srf', ns)
    ns = 'fake-srf-ap-main1-ww26-3-srf'
    assert False == get_ns('srf', ns)


def test_get_derivatives_by_namespace():
    ns = "srf-ap-dbg-burnin-sjlealru"
    logging.info(get_derivatives_by_namespace('bhs', ns))

    derivatives = get_derivatives_by_namespace('bhs', ns)
    if derivatives:
        i = 2
        set_derivatives = set(derivatives)
        while i < 1000:
            nxt_ns = f'{ns}-{i}'
            if nxt_ns not in set_derivatives:
                ns = nxt_ns
                break
            else:
                i += 1
    logging.info(ns)
    assert "srf-ap-dbg-burnin-sjlealru-5" == ns
    ns = "fake-srf-ap-dbg-burnin"
    logging.info(get_derivatives_by_namespace('bhs', ns))

    derivatives = get_derivatives_by_namespace('bhs', ns)
    if derivatives:
        i = 2
        set_derivatives = set(derivatives)
        while i < 1000:
            nxt_ns = f'{ns}-{i}'
            if nxt_ns not in set_derivatives:
                ns = nxt_ns
                break
            else:
                i += 1
    logging.info(ns)
    assert "fake-srf-ap-dbg-burnin" == ns
