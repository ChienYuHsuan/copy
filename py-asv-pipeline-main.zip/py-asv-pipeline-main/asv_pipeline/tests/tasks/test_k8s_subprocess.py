import logging

import pytest

from asv_pipeline.tasks.k8s_subprocess import extract_k8s_nodes, extract_k8s_pods

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


@pytest.fixture
def TI():

    class Task_instance:

        def __init__(self):
            self.data = {}

        def xcom_push(self, key, value):
            self.data[key] = value

    return Task_instance()


def test_extract_k8s_nodes(TI):
    try:
        rst = extract_k8s_nodes(params={'cluster': 'icx-1'}, ti=TI)
    except Exception as e:
        logger.error(str(e))

    for k, v in rst.items():
        if v['status'] == 'Ready':
            assert True
            return
    assert False


def test_extract_k8s_pods(TI):
    try:
        rst = extract_k8s_pods(params={'cluster': 'icx-1'}, ti=TI)
    except Exception as e:
        logger.error(str(e))

    for k, v in rst.items():
        logger.info(v)
        for el in v:
            if el['ns'] == 'kube-system':
                assert True
                return
    assert False
