import logging
from datetime import datetime

from asv_pipeline.k8s import Pod
from asv_pipeline.tasks.elasticsearch.es_not_ready_reporting import (change_pythonsv_readiness,
                                                                     push_dpmo_into_index,
                                                                     push_nrn_into_index)

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


# Remember to change below in config.py:
# idx_nrn_reporting = "test_nrn_reporting-%(cpu)s-%(date)s"
def test_push_nrn_into_index():
    rst = {
        'srf-c0-main-pnp-bkc79-ww20-4': [
            Pod(name='paiv-pnp-srf-main-mlc-idle-latency-nzxpz', ns='srf-c0-main-pnp-bkc79-ww20-4',
                life='5h44m', status='Terminating', ip='10.75.45.197', node='fl41ca201es0301')
        ],
        'srf-main-2-c0-ww20-4': [
            Pod(name='sgx-virt-5zgx8', ns='srf-main-2-c0-ww20-4', life='20h', status='Running',
                ip='100.64.53.10', node='fl41ca201es0804')
        ]
    }
    cpu = 'srf'
    creation_time = datetime.utcnow()
    push_nrn_into_index(cpu, rst, creation_time)

    assert False


def test_push_dpmo_into_index():
    res_dpmo = {
        'fl41ca201ds0703': {
            'timestamp': '2024-05-13T20:17:35',
            'reset_type': 'Cold_Reset_Redfish',
            'repetition': 'repetition 483',
            'log': 'Error, unexpected amount of devices/speed detected',
            'bkc_name': 'SRF_DPMO-PV1-C0_BKC79_VAL',
            'target': '2000',
            'cpu': 'SRF-SP'
        }
    }
    cpu = 'srf'
    creation_time = datetime.utcnow()
    push_dpmo_into_index(cpu, res_dpmo, creation_time)

    assert False


def test_change_pythonsv_readiness():
    node_list = ['fl41ca201ds0703', 'fl41ca201es0301', 'fl41ca201es0804']
    cpu = 'srf'
    change_pythonsv_readiness(cpu, node_list)

    assert False
