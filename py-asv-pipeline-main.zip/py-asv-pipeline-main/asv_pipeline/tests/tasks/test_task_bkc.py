import logging
import time

from asv_pipeline.tasks import os, task_bkc
from asv_pipeline.util import get_cluster_by_naming

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.DEBUG)


def test_set_pxe_as_first_boot_device():
    # s = "r008s019.zp31l10b01"
    # c = get_cluster_by_naming(s)
    # order, mp = xmlcli.getbootorder(get_cluster_by_naming(s), s)
    # logging.info(order)
    # logging.info(mp)
    # mp = {'04': 'centos', '03': 'UEFI Misc Device', '02': 'Boot Device List', '00': 'Enter Setup', '01': 'UEFI Internal Shell', '05': 'UEFI INTEL SSDPFCKE064T9 PHAG0275001Q6P4CGN', '06': 'UEFI INTEL SSDPFCKE064T9 PHAG0275001Q6P4CGN', '07': 'UEFI PXEv4 (MAC:984FEE0067B6)', '08': 'UEFI PXEv6 (MAC:984FEE0067B6)', '09': 'UEFI HTTPv4 (MAC:984FEE0067B6)', '0A': 'UEFI HTTPv6 (MAC:984FEE0067B6)', '0B': 'UEFI PXEv4 (MAC:B496919B7980)', '0C': 'UEFI PXEv6 (MAC:B496919B7980)', '0D': 'UEFI HTTPv4 (MAC:B496919B7980)', '0E': 'UEFI HTTPv6 (MAC:B496919B7980)', '0F': 'UEFI PXEv4 (MAC:B496919B7981)', '10': 'UEFI PXEv6 (MAC:B496919B7981)', '11': 'UEFI HTTPv4 (MAC:B496919B7981)', '12': 'UEFI HTTPv6 (MAC:B496919B7981)', '13': 'UEFI PXEv4 (MAC:40A6B72679FC)', '14': 'UEFI PXEv6 (MAC:40A6B72679FC)', '15': 'UEFI HTTPv4 (MAC:40A6B72679FC)', '16': 'UEFI HTTPv6 (MAC:40A6B72679FC)', '17': 'UEFI PXEv4 (MAC:40A6B72679FD)', '18': 'UEFI PXEv6 (MAC:40A6B72679FD)', '19': 'UEFI HTTPv4 (MAC:40A6B72679FD)', '1A': 'UEFI HTTPv6 (MAC:40A6B72679FD)', '1B': 'UEFI PXEv4 (MAC:B496919B7258)', '1C': 'UEFI PXEv6 (MAC:B496919B7258)', '1D': 'UEFI HTTPv4 (MAC:B496919B7258)', '1E': 'UEFI HTTPv6 (MAC:B496919B7258)', '1F': 'UEFI PXEv4 (MAC:B496919B7259)', '20': 'UEFI PXEv6 (MAC:B496919B7259)', '21': 'UEFI HTTPv4 (MAC:B496919B7259)', '22': 'UEFI HTTPv6 (MAC:B496919B7259)'}
    # order =  ['04', '03', '02', '00', '01', '05', '06', '07', '08', '09', '0A', '0B', '0C', '0D', '0E', '0F', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '1A', '1B', '1C', '1D', '1E', '1F', '20', '21', '22']
    # goal = task_bkc.set_pxe_as_first_boot_device(c,s, order, mp)
    # logging.info(goal)
    # time.sleep(180)
    # task_bkc.set_pxe_back(c,s,  goal)
    # task_bkc.set_pxe_back(c,s,{'oid': 4, 'tidx': 36, 'tid': 11})
    assert False


def test_verfication_version_from_sut():
    sut = "fl31ca302as0701"
    task_bkc.check_bkc_version(get_cluster_by_naming(sut), sut, None, "SRF-AP", "26")


def test_verfication_version():
    expected = {
        "ucode": "",
        "ifwi": "0084.D.24.WAVE2 ",
        "CPLD-1": "344.4 ",
        "CPLD-2": "",
        "CPLD-Hash":
        "9e9eca227327a3adb1c1c7851f8794984a323eb795c5698519ae829c576719d8e1f978b8f8a38e8a02b1cd44b3993524",
        "os": "5.15.0-spr.bkc.pc.7.7.4.x86_64",
        "BMC": "0.91-194 ",
        "nic-fortville-firmware": "8.60",
        "nic-columbiaville-firmware": "2.40",
        "nic-fortville-driver": "i40e-2.19.1_rc48"
    }

    sut = "fl31ca302as0701"
    rst, mp = task_bkc.check_version(get_cluster_by_naming(sut), sut, expected)
    logging.info(rst)
    logging.info(mp)
    assert False


def test_set_pxe_boot_order():
    sut = "r012s018.zp31l10b01"
    _, kv = os.ethtool(get_cluster_by_naming(sut), sut)
    old, new = task_bkc.set_pxe_as_first_boot_device(get_cluster_by_naming(sut), sut, kv)
    logging.info(old)
    logging.info(new)

    time.sleep(600)
    out = task_bkc.set_pxe_back(get_cluster_by_naming(sut), sut, old)
    logging.info(out)
    assert False


def test_bmc_naming():
    sut = "fl31ca102fs0703"
    ret = task_bkc.get_bkc_naming(get_cluster_by_naming(sut), sut)
    logging.info(ret)
    assert True
