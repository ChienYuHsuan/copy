import getopt
import os
import sys
import time
from abc import ABC

# import aspectlib
import pexpect

DEO_INFRA_PASSWORD = "intel$123"  # please modify it with internal password
AS_JENKINS_PASSWORD = "ANew21DigitPassword!"  # please modify it with internal password
i_idsid = "sys_asvauto"  # please modify it with internal password
i_password = ""  # please modify it with internal password

_DEA = "ssh -o StrictHostKeyChecking=no %(idsid)s@login01.deacluster.intel.com -i ~/.ssh/%(idsid)s.pem"
_ZP31 = "ssh -o StrictHostKeyChecking=no %(idsid)s@login01.l10b2.deacluster.intel.com -i ~/.ssh/%(idsid)s.pem"
_FLEX_ADMIN = "ssh -o StrictHostKeyChecking=no %(idsid)s@10.45.128.39 -i ~/.ssh/%(idsid)s.pem"
_FLEX_BMC = 'ssh -o StrictHostKeyChecking=no %(idsid)s@10.45.128.31 -i ~/.ssh/%(idsid)s.pem'
# _FLEX_ADM_GNR = "ssh -o StrictHostKeyChecking=no %(idsid)s@10.45.128.183 -i ~/.ssh/%(idsid)s.pem"
_FLEX_ADM_GNR = "ssh -o StrictHostKeyChecking=no %(idsid)s@10.45.130.126 -i ~/.ssh/%(idsid)s.pem"
_DEO = "ssh -o StrictHostKeyChecking=no -o IdentitiesOnly=yes -o PubkeyAuthentication=no -o PreferredAuthentications=password piv@deo-infra02.deacluster.intel.com"
_OPUS = "ssh -o StrictHostKeyChecking=no opus"
_OPUS_ADMIN = "ssh -o StrictHostKeyChecking=no a01s19"
_DEO_RAW = "ssh -o StrictHostKeyChecking=no -o IdentitiesOnly=yes -o PubkeyAuthentication=no -o PreferredAuthentications=password piv@10.219.26.27"
_AS_JEKKINS = "ssh -o StrictHostKeyChecking=no -o IdentitiesOnly=yes -o PubkeyAuthentication=no -o PreferredAuthentications=password sys_dpv@10.11.185.15"
_KUBECONFIG = "export KUBECONFIG=/srv/kube/config.%(env)s"
_SYSMAN_CMD = "sysman -am -M %(node)s"
_FLEX_ADM_CWF = "ssh -o StrictHostKeyChecking=no %(idsid)s@10.235.67.15 -i ~/.ssh/%(idsid)s.pem"

# @aspectlib.Aspect
# def ex_expect(*args, **kwargs):
#     import time
#     time.sleep(0.5)
#     # print("Sleep 2")
#     # print(args)
#     yield aspectlib.Proceed

# aspectlib.weave(pexpect.spawnbase.SpawnBase.expect, ex_expect)


class ExpectBuilder(ABC):

    def spawn(self, url):
        # self.client = pexpect.spawn(url, use_poll=True, dimensions=(4096,4096))
        # TERM as dumb has better compatible
        self.client = pexpect.spawn(url, use_poll=False, encoding="utf-8", timeout=20,
                                    dimensions=(4096, 4096), env={"TERM": "dumb"})
        self.client.delaybeforesend = 0.1
        # def get_terminal_size():
        #     s = struct.pack("HHHH", 0, 0, 0, 0)
        #     a = struct.unpack('hhhh', fcntl.ioctl(sys.stdout.fileno(), termios.TIOCGWINSZ, s))
        #     return a[0], a[1]

        # def sigwinch_passthrough(sig, data):
        #     if 'TIOCGWINSZ' in dir(termios):
        #         TIOCGWINSZ = termios.TIOCGWINSZ
        #     else:
        #         TIOCGWINSZ = 1074295912  # assume
        #     s = struct.pack("HHHH", 0, 0, 0, 0)
        #     a = struct.unpack('HHHH', fcntl.ioctl(sys.stdout.fileno(), TIOCGWINSZ, s))
        #     self.client.setwinsize(a[0], a[1])

        try:
            # print(get_terminal_size())
            # self.client.setwinsize(*get_terminal_size())
            # signal.signal(signal.SIGWINCH, sigwinch_passthrough)
            self.client.setecho(True)
            sz = os.get_terminal_size()
            if sz.lines > 0 and sz.columns > 0:
                self.client.setwinsize(sz.lines, sz.columns)

        except Exception:
            ...
        """
        https://bugzilla.redhat.com/show_bug.cgi?id=1914843#c4
        """
        self.client.sendline('set enable-bracketed-paste off')
        """
        stty reacts incorrect win-size
         
        The problem is a race condition.
        Closing -- You are sending SIGWINCH before bash is available to handle it.
        An additional sleep statement, or expecting the bash prompt to be ready resolves it.
        Additionally, command: shopt -s checkwinsize may be needed on some systems/versions of bash 
        to explicitly instruct it to handle it after we setwinsize.
        refer to https://github.com/pexpect/pexpect/issues/97
        """
        # self.client.sendline("shopt -s checkwinsize")
        if self.verbose:
            self.client.logfile_read = sys.stdout
            pass
        return self.client

    # def interact(self):
    #     def fn(data):
    #         # if self.client.before:
    #         #     self.client.expect(r'.+')
    #         return data
    #     self.client.interact(output_filter=fn)
    def __init__(self, verbose=True) -> None:
        self.client = None
        self.flushed = None
        self.verbose = verbose


def _go_DEO_RAW(cluster):
    eb = ExpectBuilder(False).spawn(_DEO_RAW)
    bastion = "_DEO_RAW"
    rst = eb.expect([
        r"Are you sure you want to continue connecting", r"piv@10.219.26.27's password",
        pexpect.TIMEOUT
    ], 10)
    if rst == 2:
        eb = ExpectBuilder(False).spawn(_AS_JEKKINS)
        bastion = "_AS_JEKKINS"
        rst = eb.expect([
            r"Are you sure you want to continue connecting", r"sys_dpv@10.11.185.15's password",
            pexpect.TIMEOUT
        ], 10)
        if rst == 0:
            eb.sendline("yes")
            eb.expect(r"sys_dpv@10.11.185.15's password")
        elif rst == 2:
            raise pexpect.ExceptionPexpect(pexpect.TIMEOUT)
        eb.sendline(AS_JENKINS_PASSWORD)
        time.sleep(1)
        eb.sendline('sudo su')
        eb.expect(r'sudo] password for sys_dpv')
        eb.sendline(AS_JENKINS_PASSWORD)
        eb.sendline('exit')
        eb.expect(r"@.*[\$|#]")
    elif rst <= 1:
        if rst == 0:
            eb.sendline("yes")
            eb.expect(r"piv@10.219.26.27's password")
        eb.sendline(DEO_INFRA_PASSWORD)
        eb.expect(r"@.*[\$|#]")
    cmd_as_jenkins = "alias kc='sudo kubectl --kubeconfig=/srv/kube/config.%(env)s --insecure-skip-tls-verify=true'"
    cmd_deo_raw = "alias kc='kubectl --kubeconfig=/srv/kube/config.%(env)s --insecure-skip-tls-verify=true'"
    if cluster == "opus-spr":
        eb.sendline(
            (cmd_deo_raw if bastion == '_DEO_RAW' else cmd_as_jenkins) % {"env": "opus-spr"})
    elif cluster == "flex":
        eb.sendline((cmd_deo_raw if bastion == '_DEO_RAW' else cmd_as_jenkins) % {"env": "flex"})
    elif cluster == "icx-1":
        eb.sendline((cmd_deo_raw if bastion == '_DEO_RAW' else cmd_as_jenkins) % {"env": "icx-1"})
    elif cluster == 'zp31':
        eb.sendline((cmd_deo_raw if bastion == '_DEO_RAW' else cmd_as_jenkins) % {"env": "zp31"})
    elif cluster == 'bhs':
        eb.sendline((cmd_deo_raw if bastion == '_DEO_RAW' else cmd_as_jenkins) % {"env": "bhs"})
    eb.sendcontrol('C')
    eb.expect(r"@.*[\$|#]")
    eb.sendline(_KUBECONFIG % {"env": cluster})
    eb.interact()


"""
being admin for FLEX
"""


def _goto_flex_for_bmc(idsid, password=None):
    child = ExpectBuilder(False).spawn(_FLEX_BMC % locals())
    rst = child.expect(
        [r'Are you sure you want to continue connecting', r's password:', r"a001admin001:"])
    if rst == 0:
        child.sendline('yes')
        nested_rst = child.expect([r's password:', r"a001admin001:"])
        if nested_rst == 0 and password:
            child.sendline(password)
    elif rst == 1 and password:
        child.sendline(password)
    child.interact()


"""
debugging for FLEX
"""


def _goto_flex_for_adm(idsid, password=None, node=None):
    child = ExpectBuilder(False).spawn(_FLEX_ADMIN % locals())
    rst = child.expect(
        [r'Are you sure you want to continue connecting', r's password:', r'debug001:'])
    if rst == 0:
        child.sendline('yes')
        nested_rst = child.expect([r's password:', r'debug001:'])
        if nested_rst == 0 and password:
            child.sendline(password)
    elif rst == 1 and password:
        child.sendline(password)
    if node:
        child.sendline(_SYSMAN_CMD % locals())
    child.interact()


def _goto_flex_for_adm_gnr(idsid, password=None):
    child = ExpectBuilder(False).spawn(_FLEX_ADM_GNR % locals())
    rst = child.expect(
        [r'Are you sure you want to continue connecting', r's password:', r'\w+@\w+(:~)?'])
    if rst == 0:
        child.sendline('yes')
        nested_rst = child.expect([r's password:', r'\w+@\w+(:~)?'])
        if nested_rst == 0 and password:
            child.sendline(password)
    elif rst == 1 and password:
        child.sendline(password)
    child.interact()


def _goto_opus_for_bmc(idsid, password=None):
    child = ExpectBuilder(False).spawn(_DEA % locals())
    rst = child.expect([r'Are you sure you want to continue connecting', r"@login01 ~\]"])
    if rst == 0:
        child.sendline('yes')
        child.expect(r'@login01 ~\]')
    child.sendline(_OPUS)
    child.interact()


def _goto_opus_for_adm(idsid, password=None, node=None):
    child = ExpectBuilder(False).spawn(_DEA % locals())

    rst = child.expect([r"Are you sure you want to continue connecting", r"@login01 ~\]"])
    if rst == 0:
        child.sendline('yes')
        child.expect(r"@login01 ~\]")
    child.sendline(_OPUS)
    child.expect(r"a01s01 ~\]\$")
    child.sendline(_OPUS_ADMIN)
    if node:
        child.expect(r"a01s19 ~\]\$")
        child.sendline(_SYSMAN_CMD % locals())
    child.interact()


def _goto_gdc_for_bmc(idsid, password=None):
    child = ExpectBuilder(False).spawn(_DEA % locals())
    # child.expect(r"@login01 ~\]")
    child.interact()


def _goto_gdc_for_adm(idsid, password=None, node=None):
    child = ExpectBuilder(False).spawn(_DEA % locals())
    rst = child.expect([r"Are you sure you want to continue connecting", r"@login01 ~\]"])
    if rst == 0:
        child.sendline('yes')
        child.expect(r"@login01 ~\]")
    if node:
        child.sendline(_SYSMAN_CMD % locals())
    child.interact()


def _goto_zp31_for_bmc(idsid, password=None):
    child = ExpectBuilder(False).spawn(_ZP31 % locals())
    # child.expect(r"@login01 ~\]")
    child.interact()


def _goto_zp31_for_adm(idsid, password=None, node=None):
    child = ExpectBuilder(False).spawn(_ZP31 % locals())
    rst = child.expect([r"Are you sure you want to continue connecting", r"@login01 ~\]"])
    if rst == 0:
        child.sendline('yes')
        child.expect(r"@login01 ~\]")
    if node:
        child.sendline(_SYSMAN_CMD % locals())
    child.read_nonblocking(size=4096, timeout=1)
    child.interact()


def _goto_bhs_for_adm(idsid, password=None, node=None):
    child = ExpectBuilder(False).spawn(_FLEX_ADM_GNR % locals())
    rst = child.expect(
        [r'Are you sure you want to continue connecting', r's password:', r'\w+@\w+(:~)?'])
    if rst == 0:
        child.sendline('yes')
        nested_rst = child.expect([r's password:', r'\w+@\w+(:~)?'])
        if nested_rst == 0 and password:
            child.sendline(password)
    elif rst == 1 and password:
        child.sendline(password)
    child.interact()


def _goto_bhs_for_bmc(idsid, password=None):
    child = ExpectBuilder(False).spawn(_FLEX_BMC % locals())
    rst = child.expect(
        [r'Are you sure you want to continue connecting', r's password:', r"a001admin001:"])
    if rst == 0:
        child.sendline('yes')
        nested_rst = child.expect([r's password:', r"a001admin001:"])
        if nested_rst == 0 and password:
            child.sendline(password)
    elif rst == 1 and password:
        child.sendline(password)
    child.interact()


# ========================================================================================


def goto_flex(idsid, password=None, is_admin_purpose=False, is_bmc_purpose=False, node=None):
    if is_bmc_purpose:
        _goto_flex_for_bmc(idsid, password)
    elif is_admin_purpose:
        _goto_flex_for_adm(idsid, password, node)


def goto_gdc(idsid, password=None, is_admin_purpose=False, is_bmc_purpose=False, node=None):
    if is_admin_purpose:
        _goto_gdc_for_adm(idsid, password, node)
    elif is_bmc_purpose:
        _goto_gdc_for_bmc(idsid, password)


def goto_zp31(idsid, password=None, is_admin_purpose=False, is_bmc_purpose=False, node=None):
    if is_admin_purpose:
        _goto_zp31_for_adm(idsid, password, node)
    elif is_bmc_purpose:
        _goto_zp31_for_bmc(idsid, password)


def goto_bhs(idsid, password=None, is_admin_purpose=False, is_bmc_purpose=False, node=None):
    if is_admin_purpose:
        _goto_bhs_for_adm(idsid, password, node)
    elif is_bmc_purpose:
        _goto_bhs_for_bmc(idsid, password)


def goto_cwf(idsid=None, password=None):
    eb = ExpectBuilder().spawn(_FLEX_ADM_CWF % locals())
    rst = eb.expect(
        [r"Are you sure you want to continue connecting", r's password:', r'\w+@\w+[:~]'])
    if rst == 0:
        eb.sendline('yes')
        nested_rst = eb.expect([r's password:', r'\w+@\w+[:~]'])
        if nested_rst == 0:
            if not password:
                raise Exception("No keypair be injected ! Contact infra team for help")
            eb.sendline(password)
            eb.expect(r'\w+@\w+[:~]')
    elif rst == 1:
        if not password:
            raise Exception("No keypair be injected ! Contact infra team for help")
        eb.sendline(password)
        eb.expect(r'\w+@\w+[:~]')
    eb.interact()


def goto_opus(idsid, password=None, is_admin_purpose=False, is_bmc_purpose=False, node=None):
    if is_bmc_purpose:
        _goto_opus_for_bmc(idsid, password)
    elif is_admin_purpose:
        _goto_opus_for_adm(idsid, password, node)


if __name__ == "__main__":

    opts, args = getopt.getopt(sys.argv[1:], "mbi:p:c:",
                               ["mgmt", "idsid:", "password:", "bmc", "cpu:"])
    _is_admin_purpose = False
    _is_bmc_purpose = False
    _cpu = None
    _idsid, _passowrd, DEO_INFRA_PASSWORD = os.getenv("I_IDSID", i_idsid), os.getenv(
        "I_PASSWORD", i_password), os.getenv("DEO_INFRA_PASSWORD", DEO_INFRA_PASSWORD)
    if not DEO_INFRA_PASSWORD:
        print(
            "please modify the /usr/local/bin/goto or goto.py, and fill out the DEO_INFRA_PASSWORD password"
        )

    if not _idsid:
        print("please execute the command")
        print("$ export I_IDSID=<your IDSID>")

    if not _passowrd:
        print("please execute the command")
        print("$ export I_PASSWORD=<your idsid related password>")

    assert DEO_INFRA_PASSWORD is not None
    assert AS_JENKINS_PASSWORD is not None
    assert _idsid is not None
    assert _passowrd is not None

    if opts:
        for k, v in opts:
            if k in ["-m", "--mgmt"]:
                _is_admin_purpose = True
            elif k in ["-i", "--idsid"]:
                _idsid = v
            elif k in ["-p", "--password"]:
                _passowrd = v
            elif k in ["-b", "--bmc"]:
                _is_bmc_purpose = True
            elif k in ["-c", "--cpu"]:
                _cpu = v

    if args:
        for _x in args:
            x = str.lower(_x)

            if x == "where":
                print("current support :")
                print(",".join(["flex", "gdc", "opus", "zp31"]))
            if not _is_admin_purpose and not _is_bmc_purpose:
                print(f'Goto kubernete cluster client ------> {x}')
                _go_DEO_RAW(x)
            elif x == "flex":
                if _cpu and _cpu.lower() == "gnr" and _is_admin_purpose:
                    _goto_flex_for_adm_gnr(_idsid, _passowrd)
                else:
                    goto_flex(_idsid, _passowrd, _is_admin_purpose, _is_bmc_purpose,
                              " ".join(args[1:]) if len(args) > 1 else None)
            elif x == "opus-spr":
                goto_opus(_idsid, _passowrd, _is_admin_purpose, _is_bmc_purpose,
                          " ".join(args[1:]) if len(args) > 1 else None)
            elif x == "gdc":
                goto_gdc(_idsid, _passowrd, _is_admin_purpose, _is_bmc_purpose,
                         " ".join(args[1:]) if len(args) > 1 else None)
            elif x == "zp31":
                goto_zp31(_idsid, _passowrd, _is_admin_purpose, _is_bmc_purpose,
                          " ".join(args[1:]) if len(args) > 1 else None)
            elif x == "bhs":
                goto_bhs(_idsid, _passowrd, _is_admin_purpose, _is_bmc_purpose,
                         " ".join(args[1:]) if len(args) > 1 else None)
            elif x == "cwf":
                goto_cwf(_idsid, _passowrd)
