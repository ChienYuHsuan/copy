# if sys.version_info.major == 3 and sys.version_info.minor < 9
from __future__ import annotations

import logging
import sys
from enum import Enum
from typing import Any

import pymsteams
import requests
from ratelimit import limits, sleep_and_retry

import asv_pipeline.config as cfg
from asv_pipeline.util import get_ww_tpe

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger()
log.setLevel(logging.DEBUG)

TABLE_TPL = {"type": "Table", "columns": [{"width": 1}, {"width": 1}], "rows": []}
LINK = "https://goto/channel_for_notreadynode"
PERIOD = 30
MAX_CALLS_PER_PERIOD = 60
"""
Limit outgoing HTTP requests based on Teams's document:
https://learn.microsoft.com/en-us/microsoftteams/platform/webhooks-and-connectors/how-to/connectors-using?tabs=cURL
"""


class CHANNEL(Enum):
    AUTOTRIGGER = 'auto-trigger'
    PYTHONSV_COLLECTOR = "pythonsv-collector"
    STOP_ON_FAILURE = "stop-on-failure"


def _mention_builder(mentioneds: list[str]):
    owner_details = {}
    for _, owner in cfg.triage_owner.items():
        owner_details[owner['idsid'].lower()] = owner

    body_list, entities = [], []
    for _mentioned in mentioneds:
        if _mentioned.lower() in owner_details:
            body_list += [f'<at>{_mentioned.upper()}</at>']
            entities += [
                {
                    "type": "mention",
                    "text": f"<at>{_mentioned.upper()}</at>",
                    "mentioned": {
                        "id": f"{owner_details[_mentioned.lower()]['email']}",
                        "name": f"{owner_details[_mentioned.lower()]['name']}"
                    }
                },
            ]
        else:
            msg = f"{_mentioned} aren't enlisted in the config, please reach out the maintainers."
            logging.warning(msg)
    return ",".join(body_list), entities


@sleep_and_retry
@limits(calls=MAX_CALLS_PER_PERIOD, period=PERIOD)
def notify_via_teams_using_adativecard(subject: str, body: list[dict], mentioned: Any,
                                       channel: CHANNEL):
    logging.info("Start sending messages in Teams channel")
    logging.info(body)
    if channel == CHANNEL.AUTOTRIGGER:
        teams = pymsteams.connectorcard(cfg.teams_webhook_url_autotrigger)
    if channel == CHANNEL.PYTHONSV_COLLECTOR:
        teams = pymsteams.connectorcard(cfg.teams_webhook_url_pythonsv_collector)

    if isinstance(mentioned, str):
        mentioned = [mentioned]

    body_str, entities = _mention_builder(mentioned)
    if teams:
        payload = {
            "type":
            "message",
            "attachments": [{
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": {
                    "type":
                    "AdaptiveCard",
                    "body": [{
                        "type": "TextBlock",
                        "text": f"{body_str}"
                    }, {
                        "type": "TextBlock",
                        'color': 'Good',
                        "text": f"{subject}"
                    }],
                    "$schema":
                    "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version":
                    "1.5",
                    "msteams": {
                        "width": "Full",
                        "allowExpand": True,
                        "entities": entities
                    }
                }
            }]
        }
        for x in body:
            logging.info(x)
            payload["attachments"][0]["content"]["body"] += [x]
        logging.info(payload)
        teams.payload = payload
        try:
            teams.send()
        except Exception:
            raise
    else:
        raise Exception("no available connector")


@sleep_and_retry
@limits(calls=MAX_CALLS_PER_PERIOD, period=PERIOD)
def notify_via_teams_using_workflow(body, channel: CHANNEL):
    logging.info("Start sending messages in Teams channel through workflow")
    url = ""
    try:
        if channel == CHANNEL.AUTOTRIGGER:
            url = cfg.teams_webhook_url_autotrigger
        elif channel == CHANNEL.PYTHONSV_COLLECTOR:
            url = cfg.teams_webhook_url_pythonsv_collector
        elif channel == CHANNEL.STOP_ON_FAILURE:
            url = cfg.teams_webhook_url_pythonsv_collector_sof
        else:
            logging.error(f"Incorrect type to send Teams message: {channel}")
            return
    except Exception as e:
        logging.error(str(e))
        return
    payload = {
        "type":
        "message",
        "attachments": [{
            "contentType": "application/vnd.microsoft.card.adaptive",
            "content": {
                "type": "AdaptiveCard",
                "body": body,
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "version": "1.2",
                "msteams": {
                    "width": "Full",
                },
            }
        }]
    }
    logging.debug(body)
    headers = {'Content-Type': 'application/json'}

    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        logging.info('Send message successfully')
    except requests.exceptions.RequestException as e:
        logging.error('Request failed: %s', e)


@sleep_and_retry
@limits(calls=MAX_CALLS_PER_PERIOD, period=PERIOD)
def notify_via_teams(ctx, channel: CHANNEL):
    logging.info("Start sending messages in Teams channel")
    if channel == CHANNEL.AUTOTRIGGER:
        teams = pymsteams.connectorcard(cfg.teams_webhook_url_autotrigger)
    if channel == CHANNEL.PYTHONSV_COLLECTOR:
        teams = pymsteams.connectorcard(cfg.teams_webhook_url_pythonsv_collector)
    if teams:
        teams.text(ctx)
        try:
            teams.send()
        except Exception:
            raise
    else:
        raise Exception("no available connector")


@sleep_and_retry
@limits(calls=MAX_CALLS_PER_PERIOD, period=PERIOD)
def send_teams_messages(rst, cpu):
    if cpu not in cfg.teams_webhook_url:
        log.error("Unrecognized CPU: %s" % cpu)
        sys.exit(1)
    log.info("Start sending messages in Teams channel: %s" % cpu)
    myTeamsMessage = pymsteams.connectorcard(cfg.teams_webhook_url[cpu])

    ns_to_remove = [ns for ns in rst if not rst[ns]]
    for ns in ns_to_remove:
        del rst[ns]

    filename = "output-%s.txt" % cpu
    with open(filename, "w") as f:
        for key, val in rst.items():
            f.write(key + '\n')
            for v in val:
                f.write('\t' + str(v).partition('|')[-1] + '\n')

    with open(filename, 'r') as file:
        lines = file.read().splitlines()

    if '' not in lines:
        with open(filename, "w") as file:
            for line in lines:
                print(line + "\n", file=file)

    ww = get_ww_tpe()
    _cpu = 'srf-sp' if cpu == 'srf' else cpu
    index = cfg.idx_nrn_reporting % {"cpu": _cpu, "date": ww.lower()}
    url = cfg.dejavu_url % {"index": index}

    with open(filename, 'r') as file:
        data = file.read()
        if data:
            if cpu == 'srf':
                data += "Please visit this link for detail: %s\n" % url

    myTeamsMessage.text(data)
    try:
        if myTeamsMessage.send():
            log.info("Send results to channel %s successfully" % (LINK))
    except Exception:
        myTeamsMessage.text("No NotReady nodes since last reporting.")
        myTeamsMessage.send()
        log.warn("No NotReady nodes since last reporting.")


def send_teams_message_with_body(body, cpu, type="nrn"):
    logging.info(f"Start sending messages in Teams channel through Workflow: {cpu}")

    url = ""
    try:
        if type == 'dpmo':
            url = cfg.teams_webhook_url_dpmo[cpu]
        elif type == 'dpmo_comp':
            url = cfg.teams_webhook_url_dpmo_comp[cpu]
        elif type == 'nrn':
            url = cfg.teams_webhook_url[cpu]
        else:
            logging.error(f"Incorrect type to send Teams message: {type}")
            return
    except Exception as e:
        logging.error(str(e))
        return

    payload = {
        "type":
        "message",
        "attachments": [{
            "contentType": "application/vnd.microsoft.card.adaptive",
            "content": {
                "type": "AdaptiveCard",
                "body": body,
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "version": "1.2",
                "msteams": {
                    "width": "Full",
                },
            }
        }]
    }

    headers = {'Content-Type': 'application/json'}

    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        logging.info('Send message successfully')
    except requests.exceptions.RequestException as e:
        logging.error('Request failed: %s', e)


def send_teams_message_thu_workflow(rst, cpu):
    body = []
    tpl = {"type": "TextBlock", "text": ""}

    ns_to_remove = [ns for ns in rst if not rst[ns]]
    for ns in ns_to_remove:
        del rst[ns]

    for ns, pods in rst.items():
        body.append({**tpl, "text": ns})

        pod_text = ""
        for pod in pods:
            # To use bullet point in body, please follow below format:
            # - fl31ca102fs0705|jasper-combo-02-nnvl2|Running|7h30m \r
            pod_info = f"- {str(pod).partition('|')[-1]} \r"
            pod_text += pod_info
        body.append({**tpl, "text": pod_text})

    logging.info(f"Body: {body}")
    if not body:
        body = [{"type": "TextBlock", "text": "No NotReady nodes since last reporting."}]
    else:
        # Add AutoTriage link in message
        autotriage_url = 'https://hsdes-pre.intel.com/appstore/phoenixatscaleapps/#/auto-triage-app?loc_product=%(cpu)s'
        columnset = {
            "type":
            "ColumnSet",
            "columns": [{
                "type":
                "Column",
                "items": [
                    {
                        "type": "TextBlock",
                        "weight": "bolder",
                        "text": "",
                        "wrap": True
                    },
                ],
                "width":
                "stretch"
            }]
        }
        _cpu = 'srf-sp' if cpu == 'srf' else cpu
        url = autotriage_url % {"cpu": _cpu.upper()}

        if _cpu == 'gnr':
            gnr_ap_url = autotriage_url % {"cpu": 'GNR-AP'}
            new_item = {
                "type": "TextBlock",
                "text": "[%s](%s)\n" % (gnr_ap_url, gnr_ap_url),
                "wrap": True
            }
            columnset["columns"][0]["items"].append(new_item)
            gnr_sp_url = autotriage_url % {"cpu": 'GNR-SP'}
            columnset["columns"][0]["items"][0][
                "text"] = "Please visit AutoTriage Dashboard for detail: [%s](%s)\n" % (gnr_sp_url,
                                                                                        gnr_sp_url)
        else:
            columnset["columns"][0]["items"][0][
                "text"] = "Please visit AutoTriage Dashboard for detail: [%s](%s)\n" % (url, url)

        body.append(columnset)

    send_teams_message_with_body(body, cpu)


def create_text_block(text, size="medium", weight="bolder", style="heading", wrap=True):
    return {
        "type": "TextBlock",
        "size": size,
        "weight": weight,
        "text": text,
        "style": style,
        "wrap": wrap
    }


def create_container_text(*text):
    return {
        "type": "Container",
        "items":
        [create_text_block(t, size='default', weight='default', style="default") for t in text]
    }


def create_table_row(*cell_texts, cell_style="accent"):
    cells = [{
        "type": "TableCell",
        "items": [{
            "type": "TextBlock",
            "text": text,
            "wrap": True
        }],
        "style": cell_style
    } for text in cell_texts]

    return {"type": "TableRow", "cells": cells}
