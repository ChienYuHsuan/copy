import ast
import logging
import time

import requests

from asv_pipeline.tasks.elasticsearch.es_qpool import push_mem_err_to_es

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logging.getLogger('elasticsearch').setLevel(logging.WARNING)
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)


class Prometheus:

    def __init__(self):
        self.url = 'https://prom-oob-ras-bhs.flex.sova.intel.com/api/v1/query_range'

    def get_url(self):
        return f"http://{self.host}:{self.port}"

    def query(self, query):
        # Placeholder for querying Prometheus
        pass

    def query_range(self, query, start, end, step):
        # Placeholder for range querying Prometheus
        pass

    def fetch_data(self, suts, metrics, period=300, step='1m'):
        suts = ast.literal_eval(suts) if isinstance(suts, str) else suts
        instances_regex = '|'.join(suts)
        query = f'{metrics}{{instance=~"{instances_regex}"}}'

        # Calculate the start and end times for the last 5 minutes
        end_time = time.time()  # Current time in seconds since the epoch
        start_time = end_time - period  # Default: 5 minutes ago

        log.info(f"Start time: {start_time}, End time: {end_time}")

        # Define the parameters for the query
        params = {
            'query': query,
            'start': start_time,
            'end': end_time,
            'step': step  # Adjust the step as needed (e.g., 1m, 1h, 1d)
        }
        log.info(f"Params: {params}")

        # Send the HTTP GET request to the Prometheus server
        response = requests.get(self.url, params=params,
                                verify=False)  # Set verify=False if you have SSL issues

        # Check if the request was successful
        if response.status_code == 200:
            data = response.json()
            log.info(f"{data}")
            for result in data['data']['result']:
                metric = result['metric']
                log.info(f"Metric: {metric}")
                node = metric['instance']
                for value in result['values']:
                    timestamp = value[0]
                    metric_value = int(value[1])
                    log.info(f"Node: {node}, Timestamp: {timestamp}, Value: {metric_value}")

                    if metric_value > 0:
                        log.info(f"Node {node} has {metrics} > 0. Remove it.")
                        if node in suts:
                            suts.remove(node)
                        log.info(f"Remaining SUTS: {suts}")
                        # Push metric to ES here
                        push_mem_err_to_es(metric, timestamp, metric_value)
                        return node, suts
            return None, None
        else:
            log.error(
                f"Error: Unable to fetch data from Prometheus. Status code: {response.status_code}")
            return None, None
