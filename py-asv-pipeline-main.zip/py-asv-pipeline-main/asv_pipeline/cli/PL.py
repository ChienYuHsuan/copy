import concurrent.futures
import logging
import os
import re
import sys
import time

import fire

import asv_pipeline.clusterscope.handler as cs_handler
from asv_pipeline.jk import JenkinsFactory
from asv_pipeline.sharepoint.report_util import get_bkc_detail
from asv_pipeline.tasks.elasticsearch.es_qpool import verify_knob as es_verify_knob
from asv_pipeline.tasks.kubernetes import add_label_and_ns
from asv_pipeline.tasks.kubernetes import delete_ns as k8s_delete_ns
from asv_pipeline.tasks.kubernetes import get_labels2 as k8s_get_labels2
from asv_pipeline.tasks.kubernetes import get_resources as k8s_get_resources
from asv_pipeline.tasks.kubernetes import join_cluster, ready, remove_label_and_ns
from asv_pipeline.tasks.kubernetes import unlabel as k8s_unlabel
from asv_pipeline.tasks.os import is_reachable as os_is_reachable
from asv_pipeline.tasks.os import pingable
from asv_pipeline.tasks.pythonsv import clear_cmos
from asv_pipeline.tasks.sysman import ac_cycle
from asv_pipeline.tasks.xmlcli import (load_default, progknobs, progknobs_from_sut, readknobs,
                                       readknobs_from_sut)
from asv_pipeline.util import get_cluster_by_naming

MAX_CONCURRENT_WORKERS = 8
# handler = logging.StreamHandler(sys.stdout)
# handler.setLevel(logging.DEBUG)
# formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# handler.setFormatter(formatter)

# log = logging.getLogger(__name__)
# log.addHandler(handler)
# log.setLevel(logging.DEBUG)
# logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
#                     level=logging.INFO)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
sys.path.insert(0, ROOT)


class PL(object):

    def bkc(self, *L):
        for x in list(L):
            meta = cs_handler.get_metadata_by_nodes([x])
            print(get_bkc_detail(meta[0]))

    def dimm(self, *L):
        rst = []
        for x in list(L):
            # rst += [get_memory_info(get_cluster_by_naming(x),x)]
            # print(isDIMMSamsung5600(get_cluster_by_naming(x),x))
            from asv_pipeline.tasks.pythonsv import get_dimm_freq
            get_dimm_freq(get_cluster_by_naming(x), x)
        print(rst)

    def load_default(self, *L):
        for x in list(L):
            if os_is_reachable(get_cluster_by_naming(x), x, None, timeout=(10, 5)):
                logger.info(load_default(get_cluster_by_naming(x), x, None))

    def prog_knob(self, *L):
        knob = L[0]
        for x in list(L[1:]):
            if os_is_reachable(get_cluster_by_naming(x), x, None, timeout=(10, 5)):
                logger.info(progknobs(get_cluster_by_naming(x), x, None, knob))

    def prog_knob_from_sut(self, *L):
        for x in list(L):
            if os_is_reachable(get_cluster_by_naming(x), x, None, timeout=(10, 5)):
                logger.info(progknobs_from_sut(get_cluster_by_naming(x), x, None, True))

    def read_knob(self, *L):
        knob = L[0]
        for x in list(L[1:]):
            if os_is_reachable(get_cluster_by_naming(x), x, None, timeout=(10, 5)):
                logging.info(readknobs(get_cluster_by_naming(x), x, None, knob))

    def read_knob_from_sut(self, *L):
        for x in list(L):
            if os_is_reachable(get_cluster_by_naming(x), x, None, timeout=(10, 5)):
                logger.info(readknobs_from_sut(get_cluster_by_naming(x), x, None))

    def reachable(self, *suts):
        for x in list(suts):
            if not os_is_reachable(get_cluster_by_naming(x), x, None, timeout=(10, 60)):
                logger.info("%s is not reachable, waitting for ac_cycling" % x)

    def ready(self, *sut):
        rst_future = {}
        rst = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_CONCURRENT_WORKERS) as executor:
            for x in list(sut):
                future = executor.submit(ready, get_cluster_by_naming(x), x)
                rst_future[x] = future
        for n, f in rst_future.items():
            try:
                rst[n] = f.result()
            except Exception as e:
                print(f'An error occurred: {e}')
        print(rst)

    def ac(self, *sut, force=False, clear_cmos=False):
        print(force, clear_cmos)

        def _internal(cluster, x, force=force, clear_cmos=clear_cmos):
            if not os_is_reachable(cluster, x, None, timeout=(10, 2)) or force:
                logger.info("start to ac cycle %s" % x)
                ac_cycle(cluster, x, need_clear_cmos=clear_cmos)
            print(f'cycle {x} done')

        with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_CONCURRENT_WORKERS) as executor:
            for x in list(sut):
                executor.submit(_internal, get_cluster_by_naming(x), x, force, clear_cmos)

    def join_cluster(self, *sut):
        rst_future = {}
        rst = {}

        def _internal(cluster, n):
            if not ready(cluster, n):
                try:
                    join_cluster(cluster, n)
                    time.sleep(2)
                    return ready(cluster, n)
                except Exception as e:
                    logger.error("%s cannot join the cluster due to %s" % (n, str(e)))
            else:
                logger.info("%s is in Ready status" % n)
                return True

        with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_CONCURRENT_WORKERS) as executor:
            for x in list(sut):
                future = executor.submit(_internal, get_cluster_by_naming(x), x)
                rst_future[x] = future
        for n, f in rst_future.items():
            try:
                rst[n] = f.result()
            except Exception as e:
                print(f'An error occurred: {e}')
        return rst

    def ns_label(self, *p):
        A = list(p)
        logger.info("namespace and label would be %s" % A[0])
        for x in A[1:]:
            logger.info("%s starts to label and create ns" % x)
            add_label_and_ns(get_cluster_by_naming(x), x, A[0])

    def remove_ns_label(self, *p):
        A = list(p)
        logger.info("take off %s namespace and label" % A[0])
        for x in A[1:]:
            logger.info("%s start to take off the namespace & label" % x)
            remove_label_and_ns(get_cluster_by_naming(x), x, A[0])

    def verify_knob(self, *sut):
        for x in list(sut):
            if not es_verify_knob(get_cluster_by_naming(x), x):
                logger.error("%s cannot pass verification of knob" % x)
            else:
                logger.info("%s pass verification of knob" % x)

    def clean(self, *p):
        mp, empty = self.resources(*p)
        rst = {}
        logging.info(mp)
        logging.info(empty)
        print(mp, empty)
        # {'r014s009.zp31l10b01': {'spr-dbg-googlestress-1026-kloh': ['killer-pod-4bjxb']}
        for x in mp:  # traverse iteratively nodes
            for k, v in mp[x].items():  # traverse k=> namespace, v=> [pods]
                if k in empty:
                    # {'spr-dbg-googlestress-1122-2-kloh': {'icx-1'}}
                    for c in empty[k]:
                        k8s_delete_ns(c, k)

                if not v:
                    logger.info("there's no jobs on the %s" % k)
                    logger.info("will unlabel %s of %s, and ns %s" % (k, x, k))
                    k8s_unlabel(get_cluster_by_naming(x), x, k)
                else:
                    rst[x] = {k: mp[x][k]}
        logger.info("not yet clean up : ")
        logger.info(rst)
        return rst

    def cluster(self, *p):
        out = {}
        for x in list(p):
            out[x] = get_cluster_by_naming(x)
        logger.debug(out)
        return out

    def labels(self, *p):
        out = {}
        for x in list(p):
            ret = k8s_get_labels2(get_cluster_by_naming(x), x)
            out[x] = ret
        # print( label_4_pipeline(out))
        # logger.debug(out)

        # for x in list(p):
        #     print(k8s_get_labels2(get_cluster_by_naming(x), x))
        # return label_4_pipeline(out)
        return out

    def resources(self, *p):
        mp = self.labels(*p)
        rst = {}
        empty = {}
        for x in mp:  # traverse iteratively nodes
            rst[x] = {}
            for ns in mp[x]:
                # logger.info("NS:%s" % ns)
                if re.search(r'.*/.*', ns):
                    continue
                if re.search(r'^nfd$', ns):
                    continue
                if re.search(r'feature\.node', ns):
                    continue
                rs = k8s_get_resources(get_cluster_by_naming(x), ns)
                if x in rs:
                    rst[x][ns] = rs[x]  # rs[x] = :Dict, {ns : [pods]}
                else:
                    if not rs:
                        if ns not in empty:
                            empty[ns] = set()
                        empty[ns].add(get_cluster_by_naming(x))
                    rst[x][ns] = []
                # logger.info(rst[x])
        removed_keys = [k for k, v in rst.items() if not v]

        for k in removed_keys:
            del rst[k]
        return rst, empty

    def ping(self, *p):
        rst_future = {}
        rst = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_CONCURRENT_WORKERS) as executor:
            for n in list(p):
                future = executor.submit(pingable, get_cluster_by_naming(n), n)
                rst_future[n] = future
        for n, f in rst_future.items():
            try:
                rst[n] = f.result()
            except Exception as e:
                print(f'An error occurred: {e}')
        return rst

    def cmos(self, *p):
        rst = {}
        for n in list(p):
            rst[n] = clear_cmos(get_cluster_by_naming(n), n)
        return rst


class JK():

    def result(self, task, id):
        logger.info(JenkinsFactory().get_build_result_by_buildid(task, id))

    def abort(self, task, id):
        JenkinsFactory().abort(task, id)


class CS():

    def cpu(self, *node):
        a, b = cs_handler.get_pool_by_nodes(list(node))
        cache = [a, b]
        rst = {}
        for k, v in a.items():
            rst[k] = str(v)
        for k, v in b.items():
            rst[k] = v
        logger.info(rst)
        logger.info(cs_handler.get_cpu(list(node), cache))
        logger.info(cs_handler.get_stepping(list(node), cache))

    def pattern_update(self, *args, no_presub: bool = True, state: str = 'RDY'):

        if len(args) < 3:
            raise Exception("lack parameters")
        logger.info(f'from: {args[0]}')
        logger.info(f'to : {args[1]}')
        rst = cs_handler.get_pool_name(args[2:])
        desc_node = {}
        for n, p in rst.items():
            logger.info(p.test_description)
            if no_presub:
                match = re.search(rf'.*?({args[0]}.*)', p.test_description)
                if match:
                    s = match.group(1)
                    logger.info(s)
                    s = re.sub(rf'{args[0]}', f'{args[1]}', s)
                    logger.info(f'after : {s}')
                    if s not in desc_node:
                        desc_node[s] = []
                    desc_node[s] += [n]
                else:
                    logger.info("---")
            else:
                if re.search(rf'{args[0]}', p.test_description):
                    s = re.sub(rf'{args[0]}', f'{args[1]}', p.test_description)
                    logger.info(f'after: {s}')
                    if s not in desc_node:
                        desc_node[s] = []
                    desc_node[s] += [n]
                else:
                    logger.info("---")
        for desc, nodes in desc_node.items():
            cs_handler.update_pool_name(nodes, {
                "test_description": desc,
                "state": state,
            })


class BMC():

    def reset(self, *nodes):
        from asv_pipeline.rf.handler import bmc_reset
        for n in list(nodes):
            bmc_reset(n)


class SharePoint():

    def upload(self, path, target_dir, site, client_id, client_secret):
        from asv_pipeline.sharepoint import SharePointFactory
        print(site, client_id, client_secret)
        sp = SharePointFactory.build(f"https://intel.sharepoint.com/sites/{site}", client_id,
                                     client_secret)
        sp.upload(path, f"Shared Documents/{target_dir}")


class PythonSV():

    def gnr_mca(self):

        from asv_pipeline.tasks.pythonsv import gnr_mca_error, unlock

        def internal(sut):
            psv = unlock(get_cluster_by_naming(sut), sut, idsid="sys_asvauto", close_required=False)
            psv.eb.timeout = 3600 * 6 + 300
            print("gnr mca error collection")
            outstream = gnr_mca_error(get_cluster_by_naming(sut), sut, idsid="sys_asvauto",
                                      pythonsv=psv)
            print("====print out ======")
            print(outstream)

        with concurrent.futures.ThreadPoolExecutor() as executor:
            # executor.submit(internal, "fl31ca102hs0202")
            executor.submit(internal, "fl31ca102hs0103")


class Pipeline(object):

    def __init__(self):
        self.wkl = PL()
        self.jk = JK()
        self.cs = CS()
        self.bmc = BMC()
        self.psv = PythonSV()
        self.sp = SharePoint()


def main():
    fire.Fire(Pipeline)


if __name__ == "__main__":
    main()
