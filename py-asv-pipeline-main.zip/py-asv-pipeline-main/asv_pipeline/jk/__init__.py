import logging
import os
import time

import jenkins as jenkins
import requests
from requests.auth import HTTPBasicAuth

import asv_pipeline.config as cfg

assert cfg.jenkins_username is not None
assert cfg.jenkins_password is not None

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.DEBUG)


class JenkinsFactory(object):

    @staticmethod
    def get_buildid_url(job, build_id):
        url = cfg.jenkins_endpoint
        _seg = job.split("/")
        seg = [x for x in _seg if x]
        rst = f'{url}/job/{"/job/".join(seg)}'
        rst += f'/{build_id}/'
        return rst

    def __init__(self):
        self.jk = jenkins.Jenkins(cfg.jenkins_endpoint, username=cfg.jenkins_username,
                                  password=cfg.jenkins_password, timeout=300)
        user = self.jk.get_whoami()
        version = self.jk.get_version()
        # jobs = svr.get_jobs()
        logging.debug('Hello %s from Jenkins %s' % (user['fullName'], version))
        # print('Hello %s from Jenkins %s' % (user['fullName'], version))

    def build_job(self, name, params=None):
        """
        the name is provided by the jobs permlink, but remove out the `jobs`.
        for example,
        http://atscale-jenkins.amr.corp.intel.com/job/Tests/job/xmlcli-run/
        the job name is Tests/xmlcli-run

        http://<jenkins url>/job/Sapphire/job/Debug Pipelines/job/SPR-DBG-BURNIN-CONCURRENT-OPUS/ 
        the job name is Sapphire/Debug Pipelines/SPR-DBG-BURNIN-CONCURRENT-OPUS
        """
        return self.jk.build_job(name, params)

    def get_console_output(self, name, build_number=None):
        logging.info(self.jk)
        if not build_number:
            logging.debug(self.jk.get_job_info(name))
            build_number = self.jk.get_job_info(name)['lastBuild']['number']
        return self.jk.get_build_console_output(name, build_number)

    def get_build_info(self, name, num=None):
        logging.info("Getting builds logs of %s" % name)
        rst = self.jk.get_build_info(name, num)
        return rst

    def get_build_id_by_queueid(self, name, queue_id):
        """
        after you invoke build_job, you will get the queue id
        put this queue id, you can turn this number to build number, 
        """
        for _ in range(10):
            rst = JenkinsFactory().get_queue_item(queue_id)
            if "executable" in rst:
                build_id = rst.get('executable').get('number')
                logging.debug(build_id)
                return build_id
            else:
                time.sleep(2)

    def get_build_result_by_buildid(self, name, build_id):
        rst = JenkinsFactory().get_build_info(name, build_id)
        logging.debug(rst)
        result = rst.get("result")
        building = "BUILDING" if rst.get('building') else "OTHER"
        return result if result else building

    def get_build_url_by_buildid(self, name, build_id):
        rst = JenkinsFactory().get_build_info(name, build_id)
        logging.debug(rst)
        result = rst.get("url")
        return result

    def get_build_result_by_queueid(self, name, queue_id):
        """
        after you invoke build_job, you will get the queue id
        put this queue id, you can turn this number to build number, 
        and get the related status
        """
        for _ in range(10):
            rst = JenkinsFactory().get_queue_item(queue_id)
            if "executable" in rst:
                build_id = rst.get('executable').get('number')
                logging.debug(build_id)
                rst = JenkinsFactory().get_build_info(name, build_id)
                logging.debug(rst)
                return rst.get('result')
            else:
                time.sleep(2)

    def get_builds_status(self, name, num=None):
        logging.info("Getting job status of %s" % name)
        status = {}
        output = self.jk.get_job_info(name)
        for build in output['builds']:
            info = self.jk.get_build_info(name, build['number'])
            if info['building']:
                logging.info("Build %d is WIP" % build['number'])
                status[build['number']] = 'WIP'
            else:
                logging.info("Build %d %s" % (build['number'], info['result']))
                status[build['number']] = info['result']
        return status

    def get_queue_item(self, num: int):
        return self.jk.get_queue_item(num)

    def abort(self, task, id):
        jenkins_url = f"{cfg.jenkins_endpoint}/job/{task}/{id}/stop"
        print(jenkins_url)
        response = requests.post(jenkins_url, auth=HTTPBasicAuth(cfg.jenkins_username,
                                                                 cfg.jenkins_password))
        if response.status_code == 200:
            logging.info(f"Successfully aborted job {task} with id {id}")
        else:
            logging.error(
                f"Failed to abort job {task} with id {id}. Status code: {response.status_code}")

    def get_pipeline_stage_results(url=None):
        res = {}

        # Expected URL format: http://atscale-jenkins.deacluster.intel.com/job/Granite/job/Main%20pipelines/job/GNR-Burn-in-Pipeline-Auto/36/
        build_url = url if url else os.environ.get('BUILD_URL', 'NA')

        # Construct the URL to get the pipeline stages
        url = f"{build_url}/wfapi/describe"

        # Make the request to Jenkins API
        response = requests.get(url, auth=HTTPBasicAuth(cfg.jenkins_username, cfg.jenkins_password))

        if response.status_code == 200:
            pipeline_data = response.json()
            stages = pipeline_data.get('stages', [])

            for stage in stages:
                stage_name = stage.get('name')
                stage_status = stage.get('status')
                logging.info(f"Stage: {stage_name}, Status: {stage_status}")
                res[stage_name] = stage_status
        else:
            logging.warning(
                f"Failed to get pipeline data: {response.status_code} - {response.text}")

        return res


# if __name__ == "__main__":
# jobs = svr.get_jobs()

# with open('jobs.out','w') as f:
#     json.dump(jobs, f)
# print(jobs)

# job = svr.get_job_config('Sapphire/Debug Pipelines/SPR-DBG-BURNIN-CONCURRENT-OPUS')
# print(job)
# print("="*63)
# job = svr.get_job_config('Sapphire/Debug Pipelines/SPR-DBG-RESETS-ALVARO-GDC')
# print(job)
