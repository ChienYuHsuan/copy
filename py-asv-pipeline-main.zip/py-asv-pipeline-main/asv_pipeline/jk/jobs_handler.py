import datetime
import logging

import requests

import asv_pipeline.config as cfg

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')


class JK_JOB_Handler:

    def __init__(self, auth=None):
        self.base_url = cfg.jenkins_endpoint
        self.auth = auth
        self._cache = {}
        self._cache_expiry = datetime.timedelta(days=1)

    def get_all_jobs(self):
        """
        Fetch all jobs from Jenkins, using in-memory cache if available and valid.
        """
        now = datetime.datetime.now()

        # Check if cached data exists and is still valid
        if self.base_url in self._cache:
            cached_data, timestamp = self._cache[self.base_url]
            if now - timestamp < self._cache_expiry:
                # Return cached data
                return cached_data

        try:
            # Fetch data from Jenkins API
            url = f"{self.base_url}/api/json?tree=jobs[name,url,jobs[name,url,jobs[name,url]]]"
            resp = requests.get(url, auth=self.auth, timeout=300)
            resp.raise_for_status()
            data = resp.json()

            # Update cache
            self._cache[self.base_url] = (data, now)
            return data
        except requests.exceptions.Timeout:
            raise TimeoutError("The request to Jenkins API timed out.")
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"An error occurred while fetching data from Jenkins API: {e}")

    @staticmethod
    def normalize(s):
        return s.lower().replace(' ', '').replace('_', '')

    def pre_normalize_jobs(self, jobs):
        """Pre-normalize job names for efficiency."""
        for job in jobs:
            job['normalized_name'] = self.normalize(job['name'])
            if 'jobs' in job and job['jobs']:
                self.pre_normalize_jobs(job['jobs'])

    def match_longest_job(self, jobs, tokens, start):
        """
        Match the longest job name from tokens[start:] in jobs.
        Returns (matched_name, matched_length, matched_job) or (None, 0, None).
        """
        max_len = 0
        matched_job = None
        matched_name = None
        n = len(tokens)
        for length in range(1, n - start + 1):
            candidate = "-".join(tokens[start:start + length])
            candidate_norm = self.normalize(candidate)
            for job in jobs:
                if candidate_norm == job['normalized_name']:
                    if length > max_len:
                        max_len = length
                        matched_job = job
                        matched_name = job['name']
        return matched_name, max_len, matched_job

    def find_job_path(self, jobs, tokens, start=0):
        """
        Recursively find the full job path in the Jenkins jobs tree.
        Returns the job path list and the last matched job dict.
        """
        if start >= len(tokens):
            return [], None

        matched_name, length, matched_job = self.match_longest_job(jobs, tokens, start)
        if length == 0:
            return None, None  # No match found

        if 'jobs' in matched_job and matched_job['jobs']:
            rest_path, last_job = self.find_job_path(matched_job['jobs'], tokens, start + length)
            if rest_path is not None:
                return [matched_name] + rest_path, last_job
        else:
            # Reached the bottom-level job
            if start + length == len(tokens):
                return [matched_name], matched_job
            else:
                # Tokens not fully matched but reached the bottom level
                return None, None

    def get_jenkins_url(self, job_str):
        """
        Build the Jenkins URL for a specific job and build number.
        """
        final_url = "N/A"
        try:
            if not job_str.startswith("jenkins-"):
                raise ValueError("Job string must start with 'jenkins-'")

            trimmed = job_str[len("jenkins-"):]
            parts = trimmed.split("-")

            # Build number is the last part and must be numeric
            build_number = parts[-1]
            if not build_number.isdigit():
                raise ValueError("The last part must be a build number")

            tokens = parts[:-1]

            # Fetch Jenkins job tree
            jobs_data = self.get_all_jobs()  # Uses cache if available
            self.pre_normalize_jobs(jobs_data['jobs'])  # Pre-normalize job names

            job_path, last_job = self.find_job_path(jobs_data['jobs'], tokens)
            if job_path is None:
                raise ValueError(f"Could not find a matching job path for tokens: {tokens}")

            # Construct URL in the format /job/folder/job/subfolder/job/jobname/build_number/console
            url_path = "/".join(f"job/{requests.utils.quote(part)}" for part in job_path)
            if self.base_url.endswith("/"):
                final_url = f"{self.base_url}{url_path}/{build_number}/console"
            else:
                final_url = f"{self.base_url}/{url_path}/{build_number}/console"
            return final_url
        except Exception as e:
            logging.error(f"Error processing Jenkins URL for qpool-buildtag {job_str}: {e}")

        return "N/A"
