import logging
import os
import sys

import pandas as pd
from openpyxl import load_workbook

import asv_pipeline.config as cfg
from asv_pipeline.jk import JenkinsFactory

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)


def add_sheet(path, name):
    try:
        writer = pd.ExcelWriter(path, engine='openpyxl')
    except Exception as e:
        log.error(str(e))
        sys.exit(1)
    df = pd.DataFrame({'Build': [], 'Status': []})
    df.to_excel(writer, sheet_name=name, index=False)
    writer.save()


if __name__ == "__main__":
    writer = None

    if not os.path.isfile(cfg.sheet_path):
        try:
            writer = pd.ExcelWriter(cfg.sheet_path, engine='openpyxl')
        except Exception as e:
            log.error(str(e))
            sys.exit(1)
        df = pd.DataFrame({'Build': [], 'Status': []})
        for p in cfg.burnin_pipelines:
            # Note: Sheet name lenght limit is 31 so we truncate name to 31 characters
            df.to_excel(writer, sheet_name=p.split('/')[-1][:31], index=False)
        writer.save()

    for p in cfg.burnin_pipelines:
        try:
            writer = pd.ExcelWriter(cfg.sheet_path, engine='openpyxl', mode='a',
                                    if_sheet_exists='overlay')
        except Exception as e:
            log.error(str(e))
            sys.exit(1)
        book = load_workbook(cfg.sheet_path)
        writer.workbook = book

        name = p.split('/')[-1]
        # Note: Sheet name lenght limit is 31 so we truncate name to 31 characters
        if name[:31] not in writer.sheets:
            print(name[:31], 'is not in current sheets. Add one for it')
            add_sheet(cfg.sheet_path, name[:31])

        current_df = pd.read_excel(cfg.sheet_path, sheet_name=name[:31])

        status = JenkinsFactory().get_builds_status(p)
        for k, v in status.items():
            if (current_df['Build'].eq(k)).any():
                idx = current_df.index[current_df['Build'] == k].tolist()
                if current_df['Status'][idx[0]] == 'WIP' and v != 'WIP':
                    print("Build %s status changed from WIP to %s" % (k, v))
                    current_df.at[idx[0], 'Status'] = v
                continue
            else:
                df = pd.DataFrame({"Build": [k], "Status": [v]})
                current_df = pd.concat([current_df, df], ignore_index=True)

        current_df.to_excel(writer, sheet_name=name[:31], index=False)
        writer.close()
