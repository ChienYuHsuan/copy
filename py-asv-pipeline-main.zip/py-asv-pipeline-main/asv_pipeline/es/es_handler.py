"""
Helper functions in ES
"""
# if sys.version_info.major == 3 and sys.version_info.minor < 9
from __future__ import annotations

import logging
from datetime import datetime, timedelta

import asv_pipeline.config as cfg
from asv_pipeline.es import ES
from asv_pipeline.tasks.elasticsearch.es_qpool import _get_es_endpoint
from asv_pipeline.util import get_cluster_by_naming

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)


def get_burnin_phase(cluster, node, ns=""):
    end = datetime.utcnow()
    start = end - timedelta(hours=120)
    current_phase = ""
    test = ""
    pipeline = ""
    es = _get_es_endpoint(cluster)

    if ns:
        body = es.index("qpool-").IS('log', 'test-start-indicator').IS('kubernetes.host', node).IS(
            'kubernetes.namespace_name', ns).range(start, end).build()
    else:
        body = es.index("qpool-").IS('log', 'test-start-indicator').IS('kubernetes.host',
                                                                       node).range(start,
                                                                                   end).build()
    try:
        docs = es.execute(timeout=600, payload=body)
    except Exception as e:
        log.error(str(e))
        pass

    if docs:
        test = docs[0]['_source']['metadata']['test']['name']
        pipeline = docs[0]['_source']['metadata']['test']['pipeline']
        for p in cfg.burnin_phases:
            if test in cfg.burnin_phases[p]:
                current_phase = p
                log.info("Node %s: Last running test is \"%s (%s)\"" % (node, test, current_phase))
                break
        else:
            log.info("Node %s: No match phase for %s" % (node, test))
    else:
        log.info("Node %s: No results when querying the last test-start-indicator" % node)

    return test, current_phase, pipeline


def get_reboot_count(node, ns):
    end = datetime.utcnow()
    start = end - timedelta(hours=120)
    reboot_count = "na"
    cluster = get_cluster_by_naming(node)

    es = _get_es_endpoint(cluster)

    body = es.index("qpool-").IS('log', 'REBOOT COUNT').notIS('log', 'cluster-reboot-count').IS(
        'kubernetes.host', node).IS('kubernetes.namespace_name', ns).range(start, end).build()
    try:
        docs = es.execute(timeout=600, payload=body)
    except Exception as e:
        log.error(str(e))
        pass

    if docs:
        log.info(docs[0]['_source']['log'])
        reboot_count = docs[0]['_source']['log'].split(' ')[-1]
        log.info("Node %s, REBOOT COUNT: %s" % (node, reboot_count))
    else:
        log.info("Node %s, No REBOOT COUNT in namespace %s" % (node, ns))

    return reboot_count


def get_mem_type(cluster, node, day=7):
    '''
    To get memory type
    :param str cluster : Cluster name
    :param str node: Node name
    Example results:
    ret_type = 'RDIMM'
    ret_card = '1Rx4 (R/C-F)'
    '''
    ret_type, ret_card = '', ''

    if cluster == 'bhs' or cluster == 'srf':
        es = 'jf'
    else:
        es = 'zp31'

    end = datetime.utcnow()
    start = end - timedelta(days=day)

    try:
        es = ES(url=cfg.es_endpoints[es], name=cfg.es_username[es],
                password=cfg.es_password[es]).index("ras_bootinfo_current")
        body = es.IS('host', node).range(start, end, timestamp="timestamp").build()
        docs = es.execute(timeout=600, payload=body)
    except Exception as e:
        logging.error(str(e))
        return '', ''

    if not docs:
        log.warning('Node %s is not in ras_bootinfo_current index' % node)
        return '', ''

    try:
        type = docs[0]['_source']['socket_table']['cpu0']['type'].split()
        size = docs[0]['_source']['socket_table']['cpu0']['size'].split()

        table_of_raw = {'SR': '1R', 'DR': '2R', 'QR': '4R'}
        ret_type = type[1] if len(type) > 1 else ''  # 'RDIMM'
        raw_card_1 = type[2][:5] if len(type) > 2 else ''  # 'R/C-A'
        raw_card_2 = size[1][-2:] if len(type) > 1 else ''  # x8
        raw_card_3 = size[2][:2] if len(type) > 1 else ''  # DR
        log.debug("raw_card_3 %s" % raw_card_3)
        row = table_of_raw.get(raw_card_3, raw_card_3)

        ret_card = "%s%s (%s)" % (row, raw_card_2, raw_card_1)
    except Exception as e:
        logging.error(str(e))
        return '', ''

    return ret_type, ret_card
