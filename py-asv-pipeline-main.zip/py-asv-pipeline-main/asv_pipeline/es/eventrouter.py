import json


def extract_events(rst):
    logs = []
    for el in rst:
        src = el.get('_source')
        logs += [json.loads(src.get('log'))]
    return logs
