import copy
import json
import logging
import os
import sys
from datetime import datetime, timedelta

import pandas as pd
import urllib3
from elasticsearch import Elasticsearch, helpers

import asv_pipeline.config as cfg

sys.path.insert(1, os.path.abspath('.'))
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

FORMAT = "%Y-%m-%d" 'T' "%H:%M:%S"
key = 'icx-1'


class ES(object):

    def __init__(self, url=cfg.es_endpoints.get(key), name=cfg.es_username.get(key),
                 password=cfg.es_password.get(key)):
        self.es = Elasticsearch([url], verify_certs=False, ssl_show_warn=False,
                                http_auth=(name, password))
        self._index = "*"
        _query = """
{
  "sort": [
    {
      "@timestamp": {
        "order": "desc",
        "unmapped_type": "boolean"
      }
    }
  ],
  "query": {
    "bool": {
      "filter": [
      ],
      "must_not": [
      ]
    }
  }
}
        """
        self._tmpl = json.loads(self.clean_json(_query))
        self._range = None
        self.query = json.loads(self.clean_json(_query))
        self.range()

    def index(self, idx):
        self._index = idx + "*"
        return self

    def IS(self, field, value):
        self.query['query']['bool']["filter"] += [{'match_phrase': {field: {'query': value}}}]
        return self

    def notIS(self, field, value):
        self.query['query']['bool']["must_not"] += [{'match_phrase': {field: {'query': value}}}]
        return self

    def exists(self, field):
        self.query['query']['bool']["filter"] += [{'exists': {'field': field}}]
        return self

    def notExists(self, field):
        self.query['query']['bool']["must_not"] += [{'exists': {'field': field}}]
        return self

    def range(self, f=datetime.now() - timedelta(minutes=15), t=datetime.now(), timezone="+00:00",
              timestamp="@timestamp"):
        # allow to use it once
        ts = {
            timestamp: {
                "format": "strict_date_optional_time",
                "time_zone": timezone,
                "gte": f.strftime(FORMAT),
                "lte": t.strftime(FORMAT)
            }
        }
        self._range = {"range": ts}
        if timestamp != '@timestamp':
            self.query['sort'][0][timestamp] = self.query['sort'][0]['@timestamp']
        return self

    def oneOf(self, field, values):
        el = {'should': [], "minimum_should_match": 1}
        if not isinstance(values, list):
            values = [values]
        for val in values:
            el['should'] += [{"match_phrase": {field: val}}]
        self.query['query']['bool']["filter"] += [{'bool': el}]
        return self

    def notOneof(self, field, values):
        el = {'should': [], "minimum_should_match": 1}
        if not isinstance(values, list):
            values = [values]
        for val in values:
            el['should'] += [{"match_phrase": {field: val}}]
        self.query['query']['bool']["must_not"] += [{'bool': el}]
        return self

    def sort(self, v):
        pass

    def clean_json(self, s):
        import re
        s = re.sub(",[ trn]+}", "}", s)
        s = re.sub(",[ trn]+]", "]", s)
        return s

    def reset(self):
        self.query = copy.deepcopy(self._tmpl)

    def build(self):
        self.query['query']['bool']["filter"] += [self._range]
        rst = self.query
        self.reset()
        return rst
        # return self.es

    def execute(self, timeout=600, payload=None):
        data = []
        # print('%s'%self._index)
        if payload:
            page = self.es.search(index='%s' % self._index, request_timeout=timeout, body=payload,
                                  size=5000, scroll='2m')

            sid = page.get('_scroll_id')
            if sid is None:
                return []
            total = page['hits']['total']['value']

            data += page.get('hits').get('hits')
            while (total > 0):
                page = self.es.scroll(scroll_id=sid, scroll='2m')
                sid = page.get('_scroll_id')
                if sid is None:
                    break
                total = len(page['hits']['hits'])
                data += page.get('hits').get('hits')
        return data

    def bulk(self, body, idx):
        helpers.bulk(self.es, body, index=idx)

    @staticmethod
    def to_df(data):
        _in = []
        for x in data:
            _dict = x['_source']
            _dict['_index'] = x['_index']
            _dict['_id'] = x['_id']
            _in += [_dict]
        return pd.DataFrame(_in)

    def update(self, data):

        def _prepare():
            if isinstance(data, pd.DataFrame):
                logging.debug(data.columns)
                for i, row, in data.iterrows():
                    _idx = row['_index']
                    _id = row['_id'] if '_id' in data.columns else row.name
                    doc = row.drop(['_index', '_id']).to_dict()
                    yield {
                        "_op_type": "update",
                        "_index": _idx,
                        "_id": _id,
                        "doc": doc,
                    }
            elif isinstance(data, list):
                # df.to_dict(orient='records')
                logging.debug("List")
                for d in data:
                    clone = d.copy()
                    _idx = clone.pop('_index', None)
                    _id = clone.pop('_id', None)
                    yield {
                        "_op_type": "update",
                        "_index": _idx,
                        "_id": _id,
                        "doc": clone,
                    }

        helpers.bulk(self.es, _prepare())

    def update_with_id(self, body, idx, id):
        self.es.update(index=idx, id=id, body=body)


# def init():
#     print(key, cfg.es_endpoints.get(key),  cfg.es_username.get(key), cfg.es_password.get(key))
#     es = Elasticsearch([cfg.es_endpoints.get(key)],
#                        verify_certs=False,
#                        ssl_show_warn=False,
#                        http_auth=(cfg.es_username.get(key),cfg.es_password.get(key)))
#     index = '*'

#     res = es.search(index='{0}'.format(index), request_timeout=600,
#                     body={"query": {"bool": {"minimum_should_match": 1,
#                                     "should": [{"match_phrase": {"host": "r012s008.fl30lne001"}},
#                                                {"match_phrase": {"host": "r003s007.fl30lne001"}},
#                                                {"match_phrase": {"host": "r003s006.fl30lne001"}}
#                       ]}}})
#     print(res)
#     with open('data.json', 'r', encoding='utf-8') as f:
#         data = json.load(f)
#         for e in data.get('hits').get('hits'):
#             print(e.get('_source').get('message'))

# if __name__ == "__main__":
#     init()
#     pass
