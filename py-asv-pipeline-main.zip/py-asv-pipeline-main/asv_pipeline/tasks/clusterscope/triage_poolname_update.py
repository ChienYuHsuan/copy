import argparse
import logging
import re

import asv_pipeline.clusterscope.poolname as cspoolname
from asv_pipeline.clusterscope.handler import get_pool_name, update_pool_name

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)


def get_file_content(filename):
    with open(filename, "r") as file:
        lines = [line.strip() for line in file]
    return lines


def remove_notready_suffix(s):
    return s.replace("-NOTREADY", "")


def remove_hsd(s):
    pattern = r'^HSD-\d+-'
    result = re.sub(pattern, '', s)
    return result


def process_poolnames(suts, idsid, type, hsd=None, appenddesc=None):

    if isinstance(suts, str):
        # If suts is a string, assuming it's a filename and attempting to read content
        suts = get_file_content(suts)

    if not suts:
        raise ValueError("No SUTs provided. Please provide at least 1 SUT.")

    log.info("Update poolname of SUTs: ")
    log.info(suts)

    idsid = idsid.upper().strip()

    if not idsid:
        raise ValueError("IDSID is required.")

    log.info(f"Nodes will assign to: {idsid}")
    log.info(f"Update Type: {type}")
    if hsd:
        log.info(f"HSD: {hsd}")

    if type in ['triage', 'rer', 'dbg']:
        for sut in suts:
            try:
                rst = get_pool_name([sut])
                desc = cspoolname.parse(str(rst[sut])).test_description

                if type == "rer":
                    if appenddesc:
                        desc = desc + "-" + appenddesc.upper().strip()
                    update_pool_name(
                        [sut], {
                            "state": "RER",
                            "assignto": "PLN",
                            "idsid": idsid,
                            "test_description": remove_hsd(desc),
                        })
                elif type == "triage":
                    update_pool_name([sut], {
                        "test_description": remove_notready_suffix(desc),
                        "idsid": idsid
                    })
                elif type == "dbg":
                    new_description = remove_notready_suffix(desc)
                    if hsd:
                        new_description = hsd.upper().strip() + "-" + new_description
                    update_pool_name([sut], {
                        "test_description": new_description,
                        "idsid": idsid,
                        "state": "DBG",
                    })
            except Exception as e:
                log.error(f"poolname parsing error, node = {sut} , {e}")
    else:
        raise ValueError("Type invalid, only provide triage/dbg/rer")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="poolname update from triage perspective")
    parser.add_argument("-sf", "--sutfilename", required=False, help="SUTs list filename")
    parser.add_argument("-s", "--suts", nargs='*', required=False, help="List of SUTs")
    parser.add_argument("-id", "--idsid", required=True, help="Target Owner's IDSID")
    parser.add_argument("-t", "--type", choices=['triage', 'dbg', 'rer'], required=True,
                        help="Update poolname type to triage/dbg/rer")
    parser.add_argument("-hsd", "--hsd", required=False, help="HSD add to description")
    parser.add_argument("-ad", "--appenddesc", required=False, help="append string to description")

    args = parser.parse_args()

    suts = []

    try:
        if args.suts:
            suts = args.suts
        elif args.sutfilename:
            suts = get_file_content(args.sutfilename)
        else:
            raise ValueError("No SUTs provided. Please use -s/--suts or -sf/--sutfilename.")

        # Validate that we have at least one SUT to process
        if not suts:
            raise ValueError("No SUTs provided. Please use -s/--suts or -sf/--sutfilename.")

        process_poolnames(suts, args.idsid, args.type, args.hsd, args.appenddesc)

    except FileNotFoundError as e:
        log.error(f"File not found: {e}")
    except ValueError as e:
        log.error(e)
    except Exception as e:
        log.error(f"An unexpected error occurred: {e}")
