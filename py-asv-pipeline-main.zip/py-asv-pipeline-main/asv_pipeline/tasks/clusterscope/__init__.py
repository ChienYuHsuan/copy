# if sys.version_info.major == 3 and sys.version_info.minor < 9
from __future__ import annotations

import logging
import re

import tenacity

import asv_pipeline.config as cfg
from asv_pipeline.clusterscope import ClusterScope, handler
from asv_pipeline.util import get_cluster_by_naming

logging = logging.getLogger(__name__)


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def get_cpu(nodes: list[str], cache=None):
    rst = handler.get_cpu(nodes, cache)
    logging.debug(rst)
    return rst


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def get_stepping(nodes: list[str], cache=None):
    rst = handler.get_stepping(nodes, cache)
    logging.debug(rst)
    return rst


def get_condidate_for_pool_name_with_prefix_indesc(nodes: list[str], prefx: list[str] = None):
    rst = handler.get_pool_name(nodes)
    executions = {}
    non_executions = {}
    for _n in rst:
        for _prefix in prefx:
            if re.search(r'^' + _prefix, rst[_n].test_description):
                executions[_n] = rst[_n]

        if _n not in executions:
            non_executions[_n] = rst[_n]
    # handler.update_pool_name(nodes, expected_fields_values, None, executions)
    return executions, non_executions


def get_condidate_for_pool_name_with_pattern_indesc(nodes: list[str], pattern: str = None):
    rst = handler.get_pool_name(nodes)

    executions = {}
    non_executions = {}

    for _n in rst:
        if any(x in rst[_n].test_description for x in pattern):
            executions[_n] = rst[_n]
        else:
            non_executions[_n] = rst[_n]

    return executions, non_executions


def update_poolname(nodes: list[str], target: str):
    node_cs_mp = {}

    if nodes:
        node_cs_mp = {n: ClusterScope(cfg.clusterscopes[get_cluster_by_naming(n)]) for n in nodes}
        # cs = ClusterScope(cfg.clusterscopes[get_cluster_by_naming(nodes[0])])

        res, _ = handler.get_pool_by_nodes(nodes)
        locations = handler.get_location_by_nodes(nodes)
    else:
        logging.debug("No available node to modify pool name. Return.")
        return

    for n in nodes:
        if n not in res:
            logging.debug("Node %s doesn't have correct pool name" % n)
            continue

        logging.debug("Target pool name for node %s: %s" % (n, target))
        try:
            res[n].update_node(n, locations[n]).update_pool(target)
            handler.update_pool_by_names(node_cs_mp[n], res[n])
        except Exception as e:
            logging.error("%s, %s" % (n, str(e)))
            continue
