# Tasks

## Overview

* [airflow-decorators reference](https://www.astronomer.io/guides/airflow-decorators/)
* Make DAG readable and with fewer codes

## Usage

Decorate a function that is imported from our library, for example:
```python
from asv_pipeline.tasks.es_eventrouter import extract_log

@task(trigger_rule=None)
def extract():
    extract_log()
```

