"""
Modules tasks.kubeneretes V.S. asv_pipeline.kubernetes 

The tasks.kubernetes modules is for workflow engine. That is to say, 
we don't know where the workflow engine would run, and we need to manipulate the cluster properly.
We should go proper bastion to access the corresponding clusters.

On the other hand, if the executor of the python can access the cluster directly but access the bastion instead.
you can directly invoke asv_pipeline.kubernetes module to call kubectl CLI.

In other words, use asv_pipeline.kubernetes when you can access the cluster locally; 
otherwise, you should use tasks.kubernetes.  

"""
import json
# import concurrent.futures
import logging
import re

import pexpect

import asv_pipeline.clusterscope.handler as handler
import asv_pipeline.config as cfg
from asv_pipeline.clusterscope import ClusterScope
from asv_pipeline.es import es_handler
from asv_pipeline.k8s import Node, Pod
from asv_pipeline.util import expect_handler, fully_ansi_escape, is_older, str2labels

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def add_ns(cluster, namespace, terminate: bool = True, eb=None):
    if not cluster and not namespace:
        raise Exception("failing task becuase there's no designate cluster or namespace or node")
    if not eb:
        eb = expect_handler.k8s(cluster)
    eb.timeout = 60
    # actually, I don't need to pull the image first,
    # the container will help us to do so, if the image doesn't exist in local
    eb.sendline("kc create ns %(ns)s" % {"ns": namespace})
    eb.expect([
        "namespace/%(ns)s created" % {
            'ns': namespace
        },
        'namespaces \"%(ns)s\" already exists' % {
            'ns': namespace
        }, 'Error from server'
    ])
    logger.info(eb.before)
    if terminate:
        eb.sendline('quit')
    return eb


def get_ns(cluster, namespace, terminate: bool = True, eb=None):
    if not cluster and not namespace:
        raise Exception("failing task becuase there's no designate cluster or namespace or node")
    if not eb:
        eb = expect_handler.k8s(cluster)
    eb.timeout = 60
    eb.sendline(f"kc get ns {namespace}")
    patterns = [
        f'namespaces "{namespace}" not found',
        'Error from server (NotFound)',
        'STATUS\s+AGE'  # noqa: W605
    ]
    rst = eb.expect(patterns)
    if terminate:
        eb.sendline('quit')
    logging.debug(f'you {"have" if rst == 2 else "do not have"} namespace {namespace} ')
    return False if rst < 2 else True


def get_derivatives_by_namespace(cluster: str, namespace: str, terminate: bool = True, eb=None):
    if not cluster and not namespace:
        raise Exception("failing task becuase there's no designate cluster or namespace or node")
    if not eb:
        eb = expect_handler.k8s(cluster)
    eb.timeout = 60
    rst = []
    if get_ns(cluster, namespace, terminate=terminate, eb=eb):
        eb.sendline(f"kc get ns | grep {namespace}; echo '>>>>>'")
        eb.expect(['kc get ns.*\r\n'])
        eb.expect(['>>>>>.*\r\n'])
        lines = eb.before
        for line in lines.split("\n"):
            if line:
                logging.info(line)
                rst += [re.split(r'\s+', line)[0].strip()]
    if terminate:
        eb.sendline('quit')
    return rst


def add_label(cluster, node, namespace, terminate: bool = True, eb=None):
    if not cluster and not namespace and not node:
        raise Exception("failing task becuase there's no designate cluster or namespace or node")
    if not eb:
        eb = expect_handler.k8s(cluster)
    eb.timeout = 60
    # actually, I don't need to pull the image first,
    # the container will help us to do so, if the image doesn't exist in local
    eb.sendline("kc label node %(node)s %(ns)s=true" % {'node': node, 'ns': namespace})
    rst = eb.expect([
        "node/%(node)s labeled" % {
            "node": node
        },
        "'%(ns)s' already has a value" % {
            "ns": namespace
        },
        'nodes "%(node)s" not found' % {
            "node": node
        },
        "node/%(node)s not labeled" % {
            "node": node
        },
    ])

    if rst == 2:
        logger.error(eb.before)
    else:
        logger.info(eb.before)

    if terminate:
        eb.sendline('quit')
    return eb


def add_label_and_ns(cluster, node, namespace):
    """
    Label the node and create the NS in particular k8s cluster
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :param str ns     : the namespace; the namespace will be created
    :return
    :raises Exception: if the cluster doesn't exist
    """
    eb = add_ns(cluster, namespace, False)
    add_label(cluster, node, namespace, True, eb)


def remove_label_and_ns(cluster, node, namespace):
    """
    housekeeping : unlabel the node and delete the NS in particular k8s cluster
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :param str ns     : the namespace; the namespace will be created
    :return
    :raises Exception: if the cluster doesn't exist
    """

    if not cluster or not namespace or not node:
        raise Exception("failing task becuase there's no designate cluster or namespace or node")

    eb = expect_handler.k8s(cluster)
    eb.timeout = 120
    # actually, I don't need to pull the image first,
    # the container will help us to do so, if the image doesn't exist in local

    eb.sendline("kc label node %(node)s %(ns)s-" % {'node': node, 'ns': namespace})
    eb.expect(
        ["node/%(node)s labeled" % {
            "node": node
        }, 'label "%(ns)s" not found' % {
            "ns": namespace
        }])
    eb.sendline("kc delete ns %(ns)s --force" % {"ns": namespace})
    eb.expect([r'namespace "' + namespace + r'" force deleted', r'(NotFound)'])
    logger.info(eb.before)


def delete_ns(cluster, ns):
    """
    housekeeping : unlabel the node and delete the NS in particular k8s cluster
    :param str cluster: option [opus,flex,icx-1..]
    :param str ns     : the namespace; the namespace will be created
    :return
    :raises Exception: if the cluster doesn't exist
    """

    if not cluster or not ns:
        raise Exception("failing task becuase there's no designate cluster or namespace or node")
    eb = expect_handler.k8s(cluster)
    eb.timeout = 60
    # actually, I don't need to pull the image first,
    # the container will help us to do so, if the image doesn't exist in local
    eb.sendline("kc delete ns/%(ns)s" % {"ns": ns})
    rst = eb.expect(
        ['namespace "%(ns)s" deleted' % {
            "ns": ns
        }, 'Error from server ', pexpect.TIMEOUT])
    logger.info(eb.before)
    return rst != 2


def unlabel(cluster, node, label):
    """
    housekeeping : unlabel the node and delete the NS in particular k8s cluster
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :param str label     : the label
    :return
    :raises Exception: if the cluster doesn't exist
    """
    if not cluster or not label or not node:
        raise Exception("failing task becuase there's no designate cluster or namespace or node")

    eb = expect_handler.k8s(cluster)
    eb.timeout = 30
    # actually, I don't need to pull the image first,

    # the container will help us to do so, if the image doesn't exist in local
    eb.sendline("kc label node/%(node)s %(ns)s-" % {'node': node, 'ns': label})
    rst = eb.expect([
        "node/%(node)s labeled" % {
            "node": node
        },
        "node/%(node)s unlabeled" % {
            "node": node
        },
        'label "%(ns)s" not found' % {
            "ns": label
        }, pexpect.TIMEOUT
    ])
    logger.info(eb.before)
    return rst != 3


def ready(cluster, node):
    """
    check node status in particular k8s cluster
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :return
    """
    eb = expect_handler.k8s(cluster)
    eb.timeout = 10
    # actually, I don't need to pull the image first,
    # the container will help us to do so, if the image doesn't exist in local
    # eb.sendcontrol("r")
    eb.sendcontrol('C')
    # eb.expect(r'\]\$')
    eb.expect(r"@.*[\$|#]")
    eb.sendline(f"kc get node {node}")
    eb.sendcontrol('D')
    eb.expect([pexpect.EOF, r'closed', pexpect.TIMEOUT])

    rst = eb.before.split("\r\n")
    j = 1
    for i, line in enumerate(rst, 1):
        if re.search(r'^NAME', line):
            j = i
            break
    # logging.info(rst[3].split("   "))
    A = re.split(r'\s+', rst[j])
    logger.debug("\n\n%s from %s\n\n" % (A[1], rst[j]))

    if "Ready" == A[1]:
        return True
    return False


def get_all_nodes(cluster):
    """
    Get all nodes in particular k8s cluster
    :param str cluster: option [opus-spr,flex,icx-1..]
    :return
    """
    eb = expect_handler.k8s(cluster)
    eb.timeout = 20
    eb.sendline("kc get node")
    eb.sendcontrol('D')
    eb.expect([pexpect.EOF, r'closed', pexpect.TIMEOUT])

    ret, rst = eb.before.split("\r\n"), {}

    for line in ret:
        if re.search(r'^NAME', line):
            continue
        if re.search(r'(?:No)?Ready', line):
            A = re.split(r'\s+', line)
            rst[A[0]] = A[1]
    logging.info(f"totoal size:{len(rst)}")
    return rst


def get_resources(cluster, ns):
    """
    get corresponding resources by namespace
    return :Dict
    e.g.
    {'r014s009.zp31l10b01':['killer-pod-4bjxb']}  
    """
    eb = expect_handler.k8s(cluster)
    eb.timeout = 10
    # actually, I don't need to pull the image first,
    # the container will help us to do so, if the image doesn't exist in local
    # eb.sendcontrol("r")
    eb.sendcontrol('C')
    # eb.expect(r'\]\$')
    eb.expect(r"@.*[\$|#]")
    eb.sendline("kc get pod -n %s -owide" % ns)
    eb.sendcontrol('D')
    eb.expect([pexpect.EOF, r'closed', pexpect.TIMEOUT])
    rst = eb.before.split("\r\n")
    out = {}
    if "No resources found" in eb.before:
        logger.info("No resource found for %s" % ns)
        return out
    start_parsing = False
    logger.debug(rst)

    for line in rst:
        if start_parsing:
            if re.search(r'\s+', line):
                logger.debug(len(re.split(r"\s+", line)))
                logger.info(line)
                if len(re.split(r"\s+", line)) == 9:
                    A = re.split(r"\s+", line)
                    if A[6] not in out:
                        out[A[6]] = []
                    out[A[6]] += [A[0]]
                else:
                    break
        if re.search(r'^NAME', line):
            start_parsing = True

    return out


def get_labels(cluster, node):
    """
    get particular nodes' label in particular k8s cluster
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :return 
    e.g. ['spr-dbg-reset-linnelso']
    """
    eb = expect_handler.k8s(cluster)
    eb.timeout = 10
    # actually, I don't need to pull the image first,
    # the container will help us to do so, if the image doesn't exist in local
    # eb.sendcontrol("r")
    eb.sendcontrol('C')
    # eb.expect(r'\]\$')
    eb.expect(r"@.*[\$|#]")
    eb.sendline(f"kc get node {node} --show-labels; echo '>>>>>'")
    eb.expect(r' --show-labels.*')
    eb.expect(r'>>>>>')
    rst = re.split(r'\r?\n', eb.before.strip())
    eb.sendcontrol('D')
    eb.expect([pexpect.EOF, r'closed', pexpect.TIMEOUT])
    start_parsing = False
    for line in rst:
        if start_parsing:
            if re.search(r'\s+', line):
                if len(re.split(r'\s+', line)) == 6:
                    return str2labels(re.split(r'\s+', line)[5])
                else:
                    break
        if re.search(r'^NAME', line):
            start_parsing = True
    return []


def get_labels2(cluster, node):
    eb = expect_handler.k8s(cluster)
    eb.timeout = 30

    eb.sendcontrol('C')
    eb.expect("@.*[\$|#]")  # noqa: W605
    eb.sendline(f"""kubectl get node {node} -o json | jq -rM '.metadata.labels';echo '>>>>>' """)
    # eb.expect('metadata.labels*\r\n')
    eb.expect('>>>*\r\n')
    rst = eb.before
    i = 0
    lines = rst.split("\r\n")
    while i < len(lines):
        if lines[i] != '{':
            i = i + 1
            continue
        else:
            break
    rst = []
    for k, v in json.loads("".join(lines[i:])).items():
        if "-" in k and "/" not in k and v == 'true':
            rst += [k]
    print(rst)
    return rst


def join_cluster(cluster, node, idsid=None, timout=600):
    """
    curl -x proxy-dmz.intel.com:912 -OL https://<token>@raw.githubusercontent.com/intel-innersource/applications.infrastructure.data-center.test-cluster.cluster-infra/main/scripts/setup_system.sh
    chmod +x setup_system.sh
    mv /etc/modules-load.d/saf.conf /root/
    export TOKEN=<token>;./setup_system.sh -c flex
    unset http_proxy
    unset https_proxy
    kubeadm join 10.45.128.9:6666 --token <token> --discovery-token-ca-cert-hash sha256:fe875eb9d09b78861756e1599f97df407d463982c1988712e7383b77c56ff434
    sudo systemctl enable systemd-resolved.service
    sudo systemctl start systemd-resolved.service
    sudo systemctl restart containerd kubelet
    """
    """
    > sudo systemctl enable systemd-resolved.service
    > sudo systemctl start systemd-resolved.service
   
    These steps are very important, otherwise we will confront the error; 
    "Failed to create pod sandbox: open /run/systemd/resolve/resolv.conf: no such file or director"
    """
    token = cfg.innersource_token
    _cluster = cluster
    eb = expect_handler.sut(cluster, node, idsid)
    eb.timeout = timout
    eb.sendline(
        "curl -x proxy-dmz.intel.com:912 -OL https://%(token)s@raw.githubusercontent.com/intel-innersource/applications.infrastructure.data-center.test-cluster.cluster-infra/main/scripts/setup_system.sh"
        % locals())
    eb.sendline("chmod +x setup_system.sh")
    eb.sendline("mv /etc/modules-load.d/saf.conf /root/")
    if _cluster == 'srf':
        eb.sendline("export TOKEN=%(token)s;./setup_system.sh -c bhs" % locals())
    elif _cluster == 'cwf':
        eb.sendline("export TOKEN=%(token)s;./setup_system.sh -c ctrls" % locals())
    else:
        eb.sendline("export TOKEN=%(token)s;./setup_system.sh -c %(_cluster)s" % locals())
    eb.expect(r'setup_system.sh completed')
    logging.info(eb.before)
    eb.sendline("unset http_proxy;unset https_proxy")
    if cluster == "icx-1":
        eb.sendline(
            "no_proxy=10.219.0.0/16 kubeadm join 10.219.23.25:6666 --token tdud0a.0zpgjpjtg0jtk9sm --discovery-token-ca-cert-hash sha256:9d730c8740052d8c9c087772d66ac0f1ee7eca811bb8caed6b90d8dd85986285"
        )
    elif cluster == "opus-spr":
        # eb.sendline("no_proxy=10.250.0.0/16 kubeadm join 10.250.0.135:6444 --token 0dpxqd.709zwbqzks1mbcoa --discovery-token-ca-cert-hash sha256:c8087cde98bbcffbf9990dd5301e97cfa3f2b671920329bfa0f15e2fa3728a45")
        eb.sendline(
            "no_proxy=10.250.0.0/16 kubeadm join 10.250.254.226:6666 --token rd2l90.66ezyz7gi20c48o2 --discovery-token-ca-cert-hash sha256:6510357d0d2c3472a1e002d0a7d8b25d1c6ca2ddbd2fea3a67f9d9a36aa7baf6"
        )
    elif cluster == "flex":
        eb.sendline(
            "no_proxy=10.45.0.0/16 kubeadm join 10.45.128.9:6666 --token 8q0jjt.cpsex4kfkaiemlcj --discovery-token-ca-cert-hash sha256:1afacb7dddeb5978b65f37ab55df156a76b2f146ef0882a122e448f12255f168"
        )
    elif cluster == 'bhs':
        eb.sendline(
            "no_proxy=10.45.0.0/16 kubeadm join 10.45.128.253:6666 --token 3sz1mt.h3kl12r6vtcgze0i --discovery-token-ca-cert-hash sha256:ec7370f0bd8c2b62cee083963d959a753fe22c7c8741bf151c94e39d76d14f71"
        )
    elif cluster == 'srf':
        eb.sendline(
            "no_proxy=10.45.0.0/16 kubeadm join 10.45.129.177:6666 --token gyapwl.j7hg1s4cgd6rpyua --discovery-token-ca-cert-hash sha256:780d2a3a17358613fef3a2a0559f72ebed27d8a25ae06f3e39608874418bcb0a"
        )
    elif cluster == "zp31":
        eb.sendline(
            "no_proxy=10.219.0.0/16 kubeadm join 10.219.26.212:6443 --token ii7q9z.0s8qzclm4qr2yxe3 --discovery-token-ca-cert-hash sha256:65de30171224df549416c7e9b1690613f707d490423996f039cea31c554069bb"
        )
    elif cluster == "cwf":
        eb.sendline(
            "no_proxy=10.45.0.0/16 kubeadm join 10.235.68.55:6666 --token 5kkkhv.ljbyp78wjk8yc5qu --discovery-token-ca-cert-hash sha256:a44dde1e17bc551ac1c585d9cc37f722a96ddff7d54c4a8cda393a5f568701ce"
        )
    eb.sendline("exit")
    eb.expect([
        "logout", pexpect.EOF, "Overwrite, Append, or", "press RETURN",
        "This node has joined the cluster"
    ])
    logger.info(eb.before)


def semi_async_get_ns(cluster, idsid=None):
    """
    In this task package, you should try to put your code as asynchronization
    and parallel using Airflow.
    """
    _GET_ALL_LAVID_NS = """
kubectl --kubeconfig=/srv/kube/config.%(cluster)s get ns -o=custom-columns=NAME:.metadata.name \
--no-headers | grep -v -E 'dev|dbg|misc';echo ">>>>>"
"""

    eb = expect_handler.k8s(cluster, idsid)
    # get all ns
    eb.send(_GET_ALL_LAVID_NS % locals())
    eb.expect(r"grep -v -E .*")
    eb.expect([r'>>>>>'])

    rst = []
    for line in re.split(r'\r?\n', fully_ansi_escape(eb.before.strip())):
        # if not l.startswith(cpu):
        #     continue
        rst += [line]
    logging.debug(rst)
    return rst


def semi_async_get_notready_nodes_by_label(cluster, cpu, ns_by_not_read, idsid=None):
    _GET_NOTREADY_NODES_WITH_LABEL = """
kubectl --kubeconfig=/srv/kube/config.%(cluster)s --insecure-skip-tls-verify get nodes -l=%(ns)s=true | grep NotReady;echo '>>>>>'
"""
    _GET_ALL_PODS_IN_NAMESPACES_BY_NODE = """
kubectl --kubeconfig=/srv/kube/config.%(cluster)s --insecure-skip-tls-verify get pod -n %(ns)s -owide | grep %(node_name)s;echo '>>>>>'
"""

    eb = expect_handler.k8s(cluster, idsid)
    rst, nodes, ns_node_mp = {}, {}, {}
    removing_labels, deleting_nss = set(), set()

    def _get_notready_nodes_with_label(cluster, cpu, ns):
        eb.send(_GET_NOTREADY_NODES_WITH_LABEL % locals())
        eb.expect(r' --insecure-skip-tls-verify .*', timeout=90)
        eb.expect(r'>>>>>', timeout=90)
        out = eb.before

        if out and 'No resources found' not in out:
            for line in re.split(r'\r?\n', fully_ansi_escape(out.strip())):
                A = re.split(r'\s+', line.strip())
                n = Node(A[0], A[1], A[3], str2labels(ns))
                node_name = n.name
                eb.send(_GET_ALL_PODS_IN_NAMESPACES_BY_NODE % locals())
                eb.expect(r' --insecure-skip-tls-verify .*', timeout=90)
                eb.expect(r'>>>>>', timeout=90)
                out_all_pods = fully_ansi_escape(eb.before.strip())
                logging.debug(f']]{out_all_pods}')
                logging.debug(f']]{n}')

                if not out_all_pods or "No resources found" in out_all_pods or "Unable to connect to the server" in out_all_pods:
                    logging.info(
                        f'[DEBUG]: No resources found in {node_name} and will remove label')
                    removing_labels.add((node_name, ns))
                    continue

                for _pod in re.split(r'\r?\n', fully_ansi_escape(out_all_pods.strip())):
                    A = re.split(r'\s+', _pod)
                    logging.info(A)
                    if '(' in A[4]:
                        pod = Pod(A[0], ns, A[6], A[2], A[7], A[8])
                    else:
                        pod = Pod(A[0], ns, A[4], A[2], A[5], A[6])
                    if pod.ns in ["monitoring", "mgmt"]:
                        continue
                    if any(_x in pod.ns for _x in ['dev', 'dbg', 'misc']):
                        continue
                    ns_node_mp[pod.node] = pod.ns
                    if cpu in pod.ns and ((is_older(pod.life, "6h") and "killer-pod" in pod.name) or
                                          "killer-pod" not in pod.name):
                        if pod.ns not in rst:
                            rst[pod.ns] = []
                        rst[pod.ns] += [pod]

                        if cluster not in nodes:
                            nodes[cluster] = set()
                        nodes[cluster].add(pod.node)
                        removing_labels.add((pod.node, ns))
                        deleting_nss.add(ns)
                logging.info("Results of NRN: %s" % rst)
                logging.info("Start updating pool name: %s" % nodes)

    def _remove_duplicates():
        cleaned_dict = {}
        for ns, pods in rst.items():
            latest_pods = {}
            for pod in pods:
                # Only keep the latest pod
                if pod.node not in latest_pods or is_older(latest_pods[pod.node].life, pod.life):
                    latest_pods[pod.node] = pod
            # Now latest_pods contains only the latest pod for each node within the current namespace
            cleaned_dict[ns] = list(latest_pods.values())
        return cleaned_dict

    def _filter_nodes(cpu):
        nodes_to_skip = []
        logging.info(len(nodes))
        logging.info(nodes)

        try:
            for _cluster, _nodes in nodes.items():
                res, _ = handler.get_pool_by_nodes(_nodes)
                locations = handler.get_location_by_nodes(_nodes)
                states = handler.get_state(_nodes)
                asignto = handler.get_asignto(_nodes)
                cs = ClusterScope(cfg.clusterscopes[_cluster])
                for n in _nodes:
                    if n not in res:
                        logging.info("Node %s doesn't have correct pool name format" % n)
                        if states[n] != 'EXC' or asignto[n] == 'INF' or asignto[n] == 'IVE':
                            logging.info("Node %s is skipped (State: %s, Asign To: %s)" %
                                         (n, states[n], asignto[n]))
                            nodes_to_skip.append(n)
                        continue
                    if res[n].asignto == 'INF' or res[n].asignto == 'IVE' or 'MAINT' in res[
                            n].test_description:
                        logging.info("Node %s is skipped (%s)" % (n, res[n]))
                        nodes_to_skip.append(n)
                        continue
                    if any(x in res[n].test_description for x in ['NOTREADY', 'HSD']):
                        logging.info("Node %s is skipped (%s)" % (n, res[n]))
                        continue
                    _, phase, _ = es_handler.get_burnin_phase(cluster, n, ns_node_mp[n])
                    if phase:
                        expected_desc = f"{res[n].test_description}-NOTREADY-{phase}"
                    else:
                        expected_desc = f"{res[n].test_description}-NOTREADY"
                    owner = cfg.triage_owner[cpu]['idsid']
                    if cpu in ('spr', 'emr') and res[n].subclustername == 'UOE':
                        owner = 'AAZAMUDI'
                    elif cpu == 'gnr' and 'AWS' not in res[n].test_description:
                        owner = 'ANJALIYA'
                    target = target = f"{res[n].cpu}_{res[n].stepping}_PIV_NTR_{res[n].subclustername}_{expected_desc}_{owner}"
                    logging.info("Target pool name for node %s: %s" % (n, target))
                    res[n].update_node(n, locations[n]).update_pool(target)
                    try:
                        handler.update_pool_by_names(cs, res[n])
                    except Exception as e:
                        logging.error("%s, %s" % (n, str(e)))
                        continue
        except Exception as e:
            logging.error("Error when updating pool name %s" % str(e))
        for val in rst.values():
            for v in val:
                if v.node in nodes_to_skip:
                    print("Node %s is skipped due to be assigned to INFRA or in MAINT state." %
                          v.node)
                    val.remove(v)
                    continue

    # ns_by_not_read = ['gnr-dbg-astera-cxl', 'gnr-dbg-main-alpha-nacho']
    logging.info("ns_by_not_read %s" % ns_by_not_read)
    for ns in ns_by_not_read:
        if not ns.startswith(cpu) or (cpu == 'srf' and ns.startswith('srf-ap')):
            continue
        try:
            _get_notready_nodes_with_label(cluster, cpu, ns)
        except Exception:
            import time
            time.sleep(5)
            _get_notready_nodes_with_label(cluster, cpu, ns)
    rst = _remove_duplicates()
    _filter_nodes(cpu)
    if rst or removing_labels or deleting_nss:
        logging.debug((rst, removing_labels, deleting_nss))
    return (rst, removing_labels, deleting_nss)


def get_node_list(kubeconfig, label):
    cmd = "kubectl %(kubeconfig)s --insecure-skip-tls-verify get node -l %(label)s --no-headers;echo '>>>>>>'" % {
        "kubeconfig": kubeconfig,
        "label": label
    }
    cluster = kubeconfig.split(".")[-1]
    eb = expect_handler.k8s(cluster)
    eb.timeout = 10
    eb.sendcontrol('C')
    eb.expect(r"@.*[\$|#]")
    eb.sendline(cmd)
    eb.expect(r' --insecure-skip-tls-verify .*', timeout=90)
    eb.expect(r'>>>>>', timeout=90)
    rst = re.split(r'\r?\n', eb.before.strip())
    eb.sendcontrol('D')
    eb.expect([pexpect.EOF, r'closed', pexpect.TIMEOUT])

    ret = {}
    for node in rst:
        A = node.split()
        ret[A[0]] = A[1]

    return ret
