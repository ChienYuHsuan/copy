import re

from asv_pipeline.clusterscope import handler
from asv_pipeline.cscript import CSCript
from asv_pipeline.pythonsv import PythonSV


def crashdump(cluster, node, idsid=None):
    """
    crashdump invoke the crashdump CMD through cscript
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :return
    """
    cpu = handler.get_cpu([node])[node]
    if re.search("CWF", cpu.upper()):
        rst = PythonSV(cluster, idsid).cscript(node).series([
            ("error.crashdump()", r"crashdump\(\) log file created at"),
        ], 3600 * 4).close()
    else:
        rst = CSCript(cluster, idsid).target(node, 3600 * 4).series([
            ("error.crashdump()", r"crashdump\(\) log file created at"),
        ], 3600 * 4).close()
    return rst
