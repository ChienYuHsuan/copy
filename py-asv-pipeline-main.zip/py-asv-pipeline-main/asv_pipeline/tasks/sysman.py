import logging

import pexpect

import asv_pipeline.clusterscope.handler as cs_handler
from asv_pipeline.util import expect_handler

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def status(cluster, node, idsid=None):
    cpu = cs_handler.get_cpu([node])[node]
    sysman = expect_handler.sysman(cluster, idsid, cpu)
    sysman.timeout = 300
    sysman.sendline("sysman --status -M %(node)s" % locals())
    # sysman.expect(r'CATERR count*')

    # rst = sysman.before
    logger.debug(sysman.before)
    sysman.sendline("exit")
    sysman.expect([pexpect.EOF, r'closed'])
    return sysman.before


def ac_cycle(cluster, node, idsid=None, need_clear_cmos=True):
    cpu = cs_handler.get_cpu([node])[node]
    sysman = expect_handler.sysman(cluster, idsid, cpu)
    # SRF sometimes needs 35-40 mins to do PDU ac cycle
    sysman.timeout = 3600
    sysman.sendline(f"sysman {'--clear-cmos ' if need_clear_cmos else ''}-am -M {node}")
    # sysman.expect(r'CATERR count*')
    logger.debug(sysman.before)
    patterns = [
        r'BMC is available. Cycle completed', r'TEST FAIL',
        r'Unable to connecto to connect to the BMC'
    ]
    rst = sysman.expect(patterns)
    if rst:
        msg = f"failed due to [{patterns[rst]}]"
        raise Exception(msg)
    # rst = sysman.befores
    sysman.sendline("exit")
    sysman.expect([pexpect.EOF, r'closed'])
    return sysman.before
