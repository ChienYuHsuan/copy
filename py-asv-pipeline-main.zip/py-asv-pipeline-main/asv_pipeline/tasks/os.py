import json
import logging
import re
import time

import pexpect
import tenacity

import asv_pipeline.clusterscope.handler as cs_handler
import asv_pipeline.config as cfg
from asv_pipeline.util import ansi_escape, expect_handler

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def sys_check(cluster, node, idsid=None, ctr=1):
    """
    sys_check, the node in particular k8s cluster run the sys_check
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :return
    """
    cpu = cs_handler.get_cpu([node])[node]
    eb = expect_handler.sysman(cluster, idsid, cpu)
    eb.timeout = 360

    eb.sendline('clear')
    token = cfg.innersource_token
    eb.sendline(
        "curl -x proxy-dmz.intel.com:912 -OL https://%(token)s@raw.githubusercontent.com/intel-sandbox/py-asv-pipeline/main/bin/kernel_test.sshpass.sh"
        % locals())
    eb.sendline("chmod +x kernel_test.sshpass.sh")
    eb.sendline("./kernel_test.sshpass.sh " + node)
    eb.sendline('exit')
    # eb.sendcontrol('D')

    code = eb.expect([pexpect.TIMEOUT, pexpect.EOF, r'closed'])
    if code == 0:
        if ctr >= 3:
            raise pexpect.TIMEOUT('try 3 times and still get timeout')
        else:
            return sys_check(cluster, node, idsid, ctr + 1)
    rst = eb.before
    logger.info(rst)
    return rst


def verify_sys_check_result(data):
    failure_set = set([
        "kernel panic", "rebooting in 10 seconds", "machine check bank", "Corrected error",
        "machine check", "Failure detected -", "UPI: LL Rx detected CRC error",
        "[WheaBERT] CheckAndUpdatePrevBootErrors:", "**ERROR! PCODE", "PCIe error",
        "Hardware error from APEI Generic Hardware Error Source", "general processor error",
        "error overflow", "uncorrected error", "[Hardware Error]: DIMM location",
        "uma read integrity error", "UMA Read/Write timeout", "PXE boot failed!",
        "Find imaged based on IP", "blk_update_request: I/O error",
        "nvme nvme0: controller is down", "[Hardware Error]: command:",
        "[Hardware Error]: It has been corrected by h/w and requires no further action",
        "[Hardware Error]: event severity: corrected",
        "[Hardware Error]:  Error 0, type: corrected", "[Hardware Error]:  fru_text: ",
        "[Hardware Error]:   section_type: memory error",
        "[Hardware Error]:   error_status: 0x0000000000000400",
        "[Hardware Error]:   physical_address:", "[Hardware Error]:   node:",
        "[Hardware Error]:   error_type: 2, single-bit ECC", "[Hardware Error]:   DIMM location: ",
        "PMIC Enable Failure:", "Apply 1.2V VDDIO Failure:", "PPR resource not available",
        "Error on rising strobe:", "RC_FATAL_ERROR!", "Major Warning Code", "Minor Warning Code",
        "Major Checkpoint", "Minor Checkpoint", "DisableRank()", "CheckMemoryBootError"
    ])
    rst = True

    other_issues = {
        "kernel_test.sh: Permission denied", "kernel_test.sh: No such file or directory",
        "Bad owner or permissions"
    }
    for el in other_issues:
        if el in data:
            rst = False
            logger.info("find the issue to execute the kernel_test :%s" % el)
    if rst:
        for el in failure_set:
            if el in data:
                rst = False
                logger.info("find the failure key_word:%s" % el)

    return rst


def ethtool(cluster, node, idsid=None, ctr=1):
    """
    using ethtool to check the interface
    """
    eb = expect_handler.sut(cluster, node, idsid, timeout=(20, 3))
    eb.expect(r'\[root@.*')
    eb.sendline("nmcli device status")
    time.sleep(1)
    eb.expect(r'\[root@.*')
    # eb.sendline('clear')

    for line in eb.before.split("\r\n"):
        x = re.search(r'ens\w+', line)
        if x:
            eb.sendline("ethtool -i " + x.group())
            eb.sendline(
                """ip -o link | grep ether | awk '$2 != "lo:" {print $2 " [" $17 "]"}' | grep --color=never %s"""
                % x.group())
            eb.sendline(
                """ip -o a | grep -E 'inet ' | awk '$2 != "lo:" {print $2 " [" $4 "]"}' | grep --color=never %s"""
                % x.group())

    # eb.sendline("ethtool -i ens1f0")
    # eb.sendline("ethtool -i ens2f0")
    time.sleep(1)
    eb.sendline('exit')
    # eb.expect('logout')
    eb.sendcontrol('D')
    eb.expect([pexpect.EOF, r'closed'])
    rst = eb.before
    # eb.sendcontrol('D')
    # eb.expect(pexpect.EOF)
    # log.info(rst)
    """
    parse
    """
    mp = {}
    A = rst.split("ethtool -i")
    for x in A:
        print(f'&{x}&')
        print(x.splitlines())
        # if x and  re.search(r'(?<=\s).*(?:\n|\r\n?)(?=.*driver)', x):
        #     interface = re.search(r'(?<=\s).*(?:\n|\r\n?)(?=.*\r?\n?driver:)', x,  re.MULTILINE|re.DOTALL)[0].strip()
        #     driver = re.search(r'(?<=driver:).*(?:\n|\r\n?)(?=.*\r?\n?version:)', x, re.MULTILINE|re.DOTALL)[0].strip()
        #     version = re.search(r'(?<=version:).*(?:\n|\r\n?)(?=.*\r?\n?firmware-version:)', x, re.MULTILINE|re.DOTALL)[0].strip()
        #     fw_version = re.search(r'(?<=firmware-version:).*(?:\n|\r\n?)(?=.*\r?\n?expansion-rom-version:)',
        #                            x,  re.MULTILINE|re.DOTALL)[0].strip()
        interface, driver, version, fw_version = None, None, None, None

        for line in x.splitlines():
            if re.search(r'(?<=\s)ens.*', line):
                interface = re.search(r'(?<=\s)ens.*', line)[0].strip()

            if re.search(r'(?<=driver:\s).*', line):
                driver = re.search(r'(?<=driver:\s).*', line)[0].strip()

            if re.search(r'(?<=^(?!firmware-version)version:).*', line):
                version = re.search(r'(?<=^(?!firmware-version)version:).*', line)[0].strip()

            if re.search(r'firmware-version:', line):
                fw_version = re.search(r'(?<=firmware-version:\s).*', line)[0].strip()

        if interface:
            mac, ipaddr = None, None
            pattern = r"(?<=" + interface + r": \[).*(?=\])"
            if re.search(pattern, x, re.IGNORECASE | re.MULTILINE):
                mac = re.search(pattern, x, re.IGNORECASE | re.MULTILINE)[0]
            ptn = r'(?<=' + interface + r' \[).*(?=])'
            if re.search(ptn, x):
                ipaddr = re.search(ptn, x)[0].split('/')[0]

            mp[interface] = {
                "driver": driver,
                "version": version,
                "fw_version": fw_version,
                "mac": mac,
                "ipaddr": ipaddr
            }
    return rst, mp


def bootorder(cluster, sut, idsid=None, ctr=1):
    """
    return : Tuple(List, Dict)
    """
    eb = expect_handler.sut(cluster, sut, idsid, timeout=(20, 3))
    eb.sendline("efibootmgr")
    eb.expect(r'\[root@.*')
    ret = eb.before
    order, mp = [], {}
    for line in ret.split("\r\n"):
        if re.search(r'(?<=BootOrder: ).*(?=[\n|\s]?)', line):
            order = re.search(r'(?<=BootOrder: ).*(?=[\n|\s]?)', line)[0].split(",")
        if re.search(r'(?<=Boot).*(?=\*)', line):
            key = re.search(r'(?<=Boot).*(?=\*)', line)[0]
            mp[key] = re.search(r'(?<=\* ).*', line)[0]

    logger.debug(order)
    logger.debug(mp)
    return order, mp


def setorder(cluster, sut, str_order: str, idsid=None, timeout=(60, 15), ctr=1):
    """
    @param str_order:string
    """
    eb = expect_handler.sut(cluster, sut, idsid, timeout)
    eb.sendline("efibootmgr -o %s" % str_order)
    eb.sendline("init 6")
    for _ in range(2):
        eb.sendline('')
    eb.expect('Connection to')
    ret = eb.before
    for _ in range(2):
        eb.sendline('')
    logger.info(ret)
    logger.info('%s succeed to reboot the system, then wait for the system booting up' % sut)
    rst = 0
    for i in range(timeout[1]):
        eb.sendline("ssh %(sut)s" % locals())
        eb.timeout = timeout[0]
        rst = eb.expect([pexpect.TIMEOUT, r'.*\[root@.*'], int(timeout[0]))
        if rst != 0:
            break
        else:
            logger.info('At %d time, wait for the %s up' % (i, sut))
    if rst == 0:
        logger.info("pexpect.TIMEOUT %d" % i)
        info = 'try %s times and still get timeout' % str(timeout[1] + 1)
        raise pexpect.TIMEOUT(info)
    else:
        time.sleep(2)
        return ret


def is_reachable(cluster, sut, idsid=None, timeout=(60, 15)):
    """
    timeout -> tuple (timeout, cycle)
    """
    try:
        eb = expect_handler.sut(cluster, sut, idsid, timeout)
        logger.info(eb.before)
        logger.info("-" * 63)
        logger.info(eb.after)
        return True
    except Exception as e:
        logging.error(e)
        return False


def get_cvl_cards(cluster, sut, idsid=None, timeout=(60, 2)):

    qsfp_result = []
    qsfp_width_result = {}
    slotDetails = {}

    eb = expect_handler.sut(cluster, sut, idsid, timeout)
    eb.sendline("")
    eb.expect(r'.*\[root@.*')
    eb.sendline("lspci | grep --color=never QSFP; echo '>>>>>'")
    time.sleep(1)
    # eb.expect(r'.*\[root@.*')
    eb.expect("'>>>>>'\r\n")
    eb.expect('>>>>>\r\n')
    rst_qsfp = eb.before.split("\r\n")
    print(rst_qsfp)

    for line in rst_qsfp[0:-1]:
        if "Ethernet" in line:
            line = ansi_escape(line)
            qsfp_result.append(line)

            busAddr = line.strip().split(" ")[0]
            eb.sendline("lspci -vv | grep -A40 " + busAddr +
                        " | grep --color=never 'LnkSta'; echo '>>>>>'")
            time.sleep(1)
            # eb.expect(r'.*\[root@.*')
            eb.expect("'>>>>>'\r\n")
            eb.expect('>>>>>\r\n')

            rst_qsfp_width = eb.before.split("\r\n")

            for wd in rst_qsfp_width[0:-1]:
                wd = ansi_escape(wd)
                qsfp_width_result[busAddr] = wd

            eb.sendline("dmidecode -t slot | grep -A7 -B8 Use | grep -B10 " + busAddr +
                        " | grep --color=never 'Design'; echo '>>>>>'")
            time.sleep(1)
            # eb.expect(r'.*\[root@.*')
            eb.expect("'>>>>>'\r\n")
            eb.expect('>>>>>\r\n')
            rst_slot = eb.before.split("\r\n")
            for slot in rst_slot[0:-1]:
                slot = ansi_escape(slot)
                match_slot = re.search(r'\(([^)]+)\)', slot)
                if match_slot:
                    result = match_slot.group(1)
                    cpu_pos = result[-4]
                    pe_pos = result[-1]
                    slotDetails[busAddr] = "Socket_{}_PciExpress_{}_Bifurcation=0x3".format(
                        cpu_pos, pe_pos)

    eb.sendline('exit')
    eb.expect('logout')
    eb.sendcontrol('D')
    eb.expect([pexpect.EOF, r'closed'])

    return qsfp_result, qsfp_width_result, slotDetails


def get_memory_info(cluster, sut, idsid=None, timeout=(10, 2)):

    eb = expect_handler.sut(cluster, sut, idsid, timeout)
    eb.expect('.*\[root@.?')  # noqa: W605
    eb.sendline(
        """dmidecode -t memory |grep --color=never -m 3 -i 'Manufacturer:\\|Speed:'; echo '>>>>>'"""
    )
    eb.expect("'>>>>>'\r\n")
    eb.expect('>>>>>\r\n')
    # eb.expect(['\r\n>>>>>\r\n'])
    # eb.expect(r'.*\[root@.*')
    spec = eb.before.split("\r\n")
    print([spec])
    eb.sendline("""dmidecode -t memory | grep --color=never -m 1 -i 'Part Number:'; echo '>>>>>'""")
    eb.expect("'>>>>>'\r\n")
    eb.expect('>>>>>\r\n')
    # eb.expect(['\r\n>>>>>\r\n'])
    # eb.expect(r'.*\[root@.*')
    part_number = None

    match = re.match(r'.*Part Number:\s+(.*\w)', eb.before, re.DOTALL)
    if match:
        part_number = match.group(1)

    eb.sendline('exit')
    eb.expect('logout')
    eb.sendcontrol('D')
    eb.expect([pexpect.EOF, r'closed'])

    return (spec, part_number)


def isDIMMSamsung5600(cluster, sut, idsid=None, timeout=(10, 2)):

    isManuSamsung = False
    isSpeed5600 = False
    is1Ynm = False

    # eb = expect_handler.sut(cluster, sut, idsid, timeout)
    # eb.expect(r'.*\[root@.*')
    # eb.sendline("dmidecode -t memory |grep --color=never -m 3 -i 'Manufacturer:\\|Speed:'")
    # time.sleep(1)
    # eb.expect(r'.*\[root@.*')
    # rst_dimm = eb.before.split("\r\n")

    # eb.sendline("dmidecode -t memory | grep --color=never -m 1 -i 'Part Number:'")
    # time.sleep(1)
    # eb.expect(r'.*\[root@.*')
    # memPartNo = ansi_escape(eb.before.split("\r\n")[1])

    # eb.sendline('exit')
    # eb.expect('logout')
    # eb.sendcontrol('D')
    # eb.expect([pexpect.EOF, r'closed'])

    rst_dimm, memPartNo = get_memory_info(cluster, sut, idsid, timeout)

    if memPartNo:
        # component_revision_char = memPartNo.split(": ")[1][9]
        component_revision_char = memPartNo[9]
        if component_revision_char == "B" or component_revision_char == "b":
            is1Ynm = True

    for line in rst_dimm[1:-1]:
        line = ansi_escape(line)

        if "Manufacturer" and "Samsung" in line:
            isManuSamsung = True
        if line.startswith("Speed: 5600"):
            isSpeed5600 = True

    return isManuSamsung & isSpeed5600 & is1Ynm


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def pingable(cluster, sut, idsid=None):
    eh = expect_handler.bastion(cluster, idsid)
    eh.send(f"""
ping -c 5 -q {sut}; echo ">>>>>"
""")
    eh.expect('ping -c 5.*\r\n')
    eh.expect('>>>>>')
    rst = eh.before
    for line in re.split(r'\r?\n', rst):
        matched = re.search(r'\d+ packets transmitted, (\d+) received', line)
        if matched:
            return False if int(matched.group(1)) == 0 else True
    logging.debug(rst)
    return False


def is_tdx(cluster, sut, idsid=None):
    eh = expect_handler.sut(cluster, sut, idsid)
    eh.send("""
dmesg | grep tdx;echo '>>>>>'
""")
    eh.expect(r'.*dmesg.*')
    logging.debug(eh.before)
    eh.expect('>>>>>')
    rst = eh.before
    logging.debug(rst)

    if re.search(r'TDX is disabled', rst):
        return False
    if re.search(r'TDX', rst, re.IGNORECASE):
        return True
    return False


def is_sgx(cluster, sut, idsid=None):
    eh = expect_handler.sut(cluster, sut, idsid)
    eh.send("""
ls /dev/sgx* ;echo '>>>>>'
 """)
    eh.expect(r'.*dev.*')
    eh.expect('>>>>>')
    rst = eh.before
    logging.debug(rst)
    return False if re.search(r'No such file', rst) else True


def _load_hook(eh, cpu=None, mem=None, bkc=None, io=None, tag=None):
    token = cfg.innersource_token
    eh.send(f"""
rm -rf frameworks.automation.sirloin.hook
mkdir frameworks.automation.sirloin.hook
cd frameworks.automation.sirloin.hook
git init
git remote add -f origin https://{token}@github.com/intel-sandbox/frameworks.automation.sirloin.hook.git
    """)
    eh.send("""
git config core.sparsecheckout true
git config -l
            
""")
    time.sleep(2)
    eh.expect('Resolving deltas: 100%', timeout=300)
    eh.send(f"""
echo "{cpu}/" >> .git/info/sparse-checkout
echo "shared_utils/" >> .git/info/sparse-checkout
echo "\!{cpu}/*/" >> .git/info/sparse-checkout
{'echo "{cpu}/{mem}" >> .git/info/sparse-checkout' if mem else ''}
{'echo "{cpu}/{bkc}" >> .git/info/sparse-checkout' if bkc else ''}
{'echo "{cpu}/{io}" >> .git/info/sparse-checkout' if io else ''}
{'echo "{cpu}/{tag}" >> .git/info/sparse-checkout' if tag else ''}
git pull origin master
""")  # noqa: W605
    time.sleep(1)
    eh.expect("\* branch.*\r\n")  # noqa: W605
    logger.debug(eh.before)


def load_bkc_version(cluster, sut, idsid=None, cpu=None, bkc=None, mem=None, io=None, tag=None,
                     need_git_pull=True):
    eh = expect_handler.sut(cluster, sut, idsid)
    if need_git_pull:
        _load_hook(eh, cpu, mem, bkc, io, tag)
    paths = [
        f"~/frameworks.automation.sirloin.hook/{cpu}/{tag}/version.json",
        f"~/frameworks.automation.sirloin.hook/{cpu}/{bkc}/version.json"
    ]

    for path in paths:
        eh.send(f"""
sleep 10;cat {path};echo '>>>>>'
""")
        time.sleep(2)
        eh.expect("frameworks.*\r\n")
        rst = eh.expect(["No such file or directory\r\n", ">>>>>"])
        if rst == 1:
            out = eh.before
            js = json.loads(out)
            logging.debug(js)
            return True, js

    return False, None


def hook_processor(cluster, sut, idsid=None, cpu=None, bkc=None, mem=None, io=None, tag=None,
                   is_preprocess=True, need_git_pull=True):
    eh = expect_handler.sut(cluster, sut, idsid)

    if need_git_pull:
        _load_hook(eh, cpu, mem, bkc, io, tag)
    eh.send(f"sleep 2;cd ~/frameworks.automation.sirloin.hook/{cpu}")
    eh.send(f"""
python3 {"pre.py" if is_preprocess else "main.py"}
    """)
    rst = True
    patterns = ["%Passed%", "%Failed%", "No such file or directory", pexpect.TIMEOUT]
    time.sleep(1)
    _rst = eh.expect(patterns)
    logger.info(_rst)
    if _rst == 1:
        rst = False
    for param in [mem, bkc, io, tag]:
        if param:
            eh.send(f"""
python3 {param}/{"pre.py" if is_preprocess else "main.py"}
            """)
            _rst = eh.expect(patterns)
            if _rst == 1:
                rst = False
    eh.send("""
python3 -c 'print("~"*10)'
    """)
    time.sleep(1)
    eh.expect(['~~~~~~~~~~\r\n'])
    logger.debug(eh.before)
    return rst
    # result = subprocess.run(['./your_script.sh'], capture_output=True, text=True)
    # logging.info(result.stdout)
    # logging.debug(result.stderr)
