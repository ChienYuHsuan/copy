# if sys.version_info.major == 3 and sys.version_info.minor < 9
from __future__ import annotations

import logging
import re
import sys
from copy import deepcopy
from datetime import date, datetime, timedelta

import requests
import tenacity

import asv_pipeline.config as cfg
from asv_pipeline.clusterscope.handler import (get_action_history_by_node, get_metadata_by_nodes,
                                               get_sku)
from asv_pipeline.es import ES, es_handler
from asv_pipeline.k8s import Pod
from asv_pipeline.sharepoint.report_util import get_bkc_detail
from asv_pipeline.sharepoint.update_notready import nrn_template
from asv_pipeline.tasks.elasticsearch.es_eventrouter import get_nrn_time
from asv_pipeline.util import get_cluster_by_naming, get_ww_tpe

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)


def push_notready_nodes_into_index(data: list[Pod]):
    """
    Push results into ES index
    """
    body = []
    for v in data:
        d = {}
        d.update({
            'host': v.node,
            'namespace': v.ns,
            'test': v.name,
            'status': v.status,
            'age': v.life,
            'timestamp': datetime.utcnow()
        })
        body += [d]
    es = ES(url=cfg.es_endpoints['flex'], name=cfg.es_username['flex'],
            password=cfg.es_password['flex'])
    try:
        es.bulk(body, "not_ready_reporting-%(date)s" % {"date": date.today().strftime('%Y.%m.%d')})
    except Exception as e:
        log.error("Error raised during pushing data to ES: %s" % str(e))


def push_nrn_into_index(cpu, body):
    _cpu = 'srf-sp' if cpu == 'srf' else cpu
    ww = get_ww_tpe()

    logging.info("Push NRN body %s to ES" % body)

    # Push NRN results into ES index
    es = ES(url=cfg.es_endpoints['flex'], name=cfg.es_username['flex'],
            password=cfg.es_password['flex'])
    try:
        es.bulk(body, cfg.idx_nrn_reporting % {"cpu": _cpu, "date": ww.lower()})
    except Exception as e:
        log.error("Error raised during pushing data to ES: %s" % str(e))


def pull_nrn_from_es(cpu):
    _cpu = 'srf-sp' if cpu == 'srf' else cpu
    ww = get_ww_tpe()
    res = []

    es = ES(url=cfg.es_endpoints['flex'], name=cfg.es_username['flex'],
            password=cfg.es_password['flex']).index(cfg.idx_nrn_reporting % {
                "cpu": _cpu,
                "date": ww.lower()
            })

    start = datetime.utcnow() - timedelta(hours=7)
    end = datetime.utcnow() + timedelta(days=1)
    body = es.range(start, end, timestamp="Creation Time").build()
    try:
        docs = es.execute(timeout=600, payload=body)
    except Exception as e:
        log.error(str(e))
        sys.exit(1)

    if docs:
        for doc in docs:
            logging.info("Get NRN data from ES: %s" % doc['_source']['Node'])
            doc['_source']['_id'] = doc['_id']
            doc['_source']['Creation Time'] = datetime.strptime(doc['_source']['Creation Time'],
                                                                '%Y-%m-%dT%H:%M:%S.%f')
            doc['_source']['NRN timestamp'] = datetime.strptime(doc['_source']['NRN timestamp'],
                                                                '%Y-%m-%dT%H:%M:%S.%f')
            res.append(doc['_source'])
    else:
        logging.info("No NRN data found in ES")

    logging.info("Pull NRN data from ES: %s" % res)
    return res


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_fixed(60), reraise=True)
def push_nrn_into_autotraige(body):

    def get_at_tpl():
        return {
            "host": "",
            "loc_product": "",
            "triggered_at": "",
            "test_content": "",
            "socket_count": "",
            "stepping": "",
            "owner": "",
            "generic_hsd_id": "",
            "master_hsd_id": "",
            "rec_rc": "",
            "rec_ns": "",
            "act_rc": "",
            "act_ns": "",
            "init_pool": "",
            "final_pool": "",
            "domain": "",
            "is_known_issue": False,
            "node_state": "ALIVE",
            "triage_priority": "MEDIUM"
        }

    base_tpl = get_at_tpl()

    payload = []
    for b in body:
        id_match = re.search(r'",\s*"([^"]+)"\)$', b['automatic presighting'])
        if id_match:
            extracted_id = id_match.group(1)
            log.info("Generic HSD ID: %s" % extracted_id)
        else:
            log.warning("Generic HSD ID not found")
            extracted_id = 'NA'

        _bkc = b['BKC']
        # Split the data into lines
        lines = _bkc.strip().split('\n')

        bkc = {}
        try:
            for line in lines:
                log.debug(line)
                if '-' not in line and 'BKC#' in line:  # For example, BKC#98 (from poolname)
                    match = re.search(r'BKC#(\d+)', line)
                    bkc_version = 'NA'
                    if match:
                        bkc_version = match.group(1)
                        log.info(f"BKC#: {bkc_version}")
                    else:
                        log.info("No BKC# found")
                    bkc['version'] = bkc_version
                    continue
                key, value = line.split(' - ', 1)
                bkc[key.strip()] = value.strip()
        except Exception as e:
            log.error("Error when parsing BKC info: %s" % str(e))

        payload += [{
            **base_tpl,
            "host": b['Node'],
            "loc_product": b['Initial Pool'].split("_")[0],
            "triggered_at": b['Creation Time'].isoformat(),
            "test_content": b['Last test-Subtest'],
            "socket_count": b['Socket Count'],
            "stepping": b['stepping'],
            "generic_hsd_id": extracted_id,
            "init_pool": b['Initial Pool'],
            "prev_pool": b['Previous Pool'],
            "namespace": b['content'],
            "qdf": b['QDF'],
            "ttf": b['TTF'],
            "pythonsv_result": b['PythonSV Result'],
            "pythonsv_url": b['pythonSV_sharepoint_path'],
            "test_pipeline": b['Pipeline'],
            "bkc_version": bkc.get("version"),
            "bmc_version": bkc.get("BMC Version"),
            "bios_version": bkc.get("BIOS Version"),
            "cpld_version": bkc.get("CPLD Version"),
            "cpu_id": bkc.get("cpuId"),
            "microcode": bkc.get("microcode"),
            "me_version": bkc.get("ME Version"),
            "platform": bkc.get("Platform"),
            "cpu_cpld": bkc.get("CPU CPLD"),
            "dbg_cpld": bkc.get("DBG CPLD"),
            "scm_cpld": bkc.get("SCM CPLD"),
            "pfr_cpld": bkc.get("PFR CPLD"),
            "dimm": bkc.get("DIMM"),
        }]

    headers = {'Content-Type': 'application/json', 'X-Api-Key': cfg.at_api_key}
    response = requests.post(cfg.at_url, headers=headers, json=payload, verify=False)
    response.raise_for_status()
    logging.info('Push data to AutoTriage Dashboard successfully')


def change_pythonsv_readiness(cpu, node_list):
    _cpu = 'srf-sp' if cpu == 'srf' else cpu
    log.info("Change PythonSV Readiness: %s %s" % (_cpu, node_list))
    update_body = {"doc": {"PythonSV Readiness": "Completed"}}

    if not node_list:
        log.info("No node list found")
        return

    es = ES(url=cfg.es_endpoints['flex'], name=cfg.es_username['flex'],
            password=cfg.es_password['flex']).index(cfg.idx_nrn_reporting.split('-')[0])

    end = datetime.utcnow()
    start = end - timedelta(days=3)
    body = es.oneOf('Node', node_list).IS('PythonSV Readiness',
                                          'In Progress').range(start, end,
                                                               timestamp="Creation Time").build()
    try:
        docs = es.execute(timeout=600, payload=body)
    except Exception as e:
        log.error(str(e))
        sys.exit(1)

    ww = get_ww_tpe()
    _idx = cfg.idx_nrn_reporting % {"cpu": _cpu, "date": ww.lower()}
    _id = ''
    for doc in docs:
        _id = doc['_id']
        log.info("Change PythonSV Readiness of id %s to Completed" % _id)
        try:
            es.update_with_id(update_body, _idx, _id)
        except Exception as e:
            log.error("Error raised during updating data to ES: %s %s %s" % (str(e), _idx, _id))


def prepare_data_for_nrn(rst, creation_time):
    body = []
    for key, val in rst.items():
        for v in val:
            test = v.name
            try:
                workload, phase, pipeline = es_handler.get_burnin_phase(
                    get_cluster_by_naming(v.node), v.node, key)
            except Exception as e:
                log.error(f"Error raised during prepare_data_for_nrn. {str(e)}")
                continue

            if "killer-pod" in v.name and workload:
                test = v.name + " (after %s)" % workload
            reboot_count = es_handler.get_reboot_count(v.node, v.ns)
            meta = get_metadata_by_nodes([v.node])

            start_date = (datetime.utcnow() - timedelta(5)).strftime('%Y-%m-%d')
            curr_date = (datetime.utcnow() + timedelta(1)).strftime('%Y-%m-%d')
            old_pool = 'NA'
            try:
                node_action_history = get_action_history_by_node(v.node, 1, start_date, curr_date)
                if node_action_history and len(node_action_history) > 0:
                    old_pool = node_action_history[0]['old_pool_name']
            except Exception as e:
                log.error(f"Error raised during get_action_history_by_node. {str(e)}")
                continue
            nrn_time = get_nrn_time(v.node)
            d = deepcopy(nrn_template)
            if meta:
                d.update({
                    "Node":
                    v.node,
                    "content":
                    key,
                    "Initial Pool":
                    meta[0].get('pool', 'NA'),
                    "QDF":
                    meta[0].get('qdf', 'NA'),
                    "stepping":
                    meta[0].get('stepping', 'NA'),
                    "Socket Count":
                    get_sku(v.node, meta[0].get('0', 'NA'), meta[0].get('1', 'NA')),
                    "TTF":
                    "Reboot count: %s" % reboot_count,
                    "BKC":
                    get_bkc_detail(meta[0]),
                    "Last test-Subtest":
                    test,
                    "Creation Time":
                    creation_time,
                    "NRN timestamp":
                    nrn_time,
                    "PythonSV Readiness":
                    "In Progress",
                    "pythonSV_sharepoint_path":
                    "NA",
                    "Previous Pool":
                    old_pool,
                    "Pipeline":
                    pipeline,
                    "_id":
                    "%s_%s" % (v.node, datetime.utcnow().strftime('%Y.%m.%d.%H'))
                })
            else:
                log.warning("%s: No metadata from ClusterScope" % v.node)
                d.update({
                    "Node": v.node,
                    "content": key,
                    "TTF": "Reboot count: %s" % reboot_count,
                    "Last test-Subtest": test,
                    "Creation Time": creation_time,
                    "NRN timestamp": nrn_time,
                    "PythonSV Readiness": "In Progress",
                    "pythonSV_sharepoint_path": "NA",
                    "_id": "%s_%s" % (v.node, datetime.utcnow().strftime('%Y.%m.%d.%H'))
                })
            body += [d]

    logging.info("Prepare NRN body %s to ES" % body)

    return body


def prepare_data_for_dpmo(rst, creation_time):
    body = []
    for key, val in rst.items():
        meta = get_metadata_by_nodes([key])

        start_date = (datetime.utcnow() - timedelta(5)).strftime('%Y-%m-%d')
        curr_date = (datetime.utcnow() + timedelta(1)).strftime('%Y-%m-%d')
        old_pool = 'NA'
        node_action_history = get_action_history_by_node(key, 1, start_date, curr_date)
        if node_action_history and len(node_action_history) > 0:
            old_pool = node_action_history[0]['old_pool_name']
        nrn_time = get_nrn_time(key)
        d = deepcopy(nrn_template)
        if meta:
            d.update({
                "Node": key,
                "content": val['bkc_name'],
                "Initial Pool": meta[0].get('pool', 'NA'),
                "QDF": meta[0].get('qdf', 'NA'),
                "stepping": meta[0].get('stepping', 'NA'),
                "Socket Count": get_sku(key, meta[0].get('0', 'NA'), meta[0].get('1', 'NA')),
                "TTF": val['repetition'],
                "BKC": get_bkc_detail(meta[0]),
                "Last test-Subtest": val['reset_type'],
                "Creation Time": creation_time,
                "NRN timestamp": nrn_time,
                "PythonSV Readiness": "In Progress",
                "pythonSV_sharepoint_path": "NA",
                "Previous Pool": old_pool,
                "_id": "%s_%s" % (key, datetime.utcnow().strftime('%Y.%m.%d.%H'))
            })
        else:
            log.warning("%s: No metadata from ClusterScope" % key)
            d.update({
                "Node": key,
                "content": val['bkc_name'],
                "TTF": val['repetition'],
                "Last test-Subtest": val['reset_type'],
                "Creation Time": creation_time,
                "NRN timestamp": nrn_time,
                "PythonSV Readiness": "In Progress",
                "pythonSV_sharepoint_path": "NA",
                "_id": "%s_%s" % (key, datetime.utcnow().strftime('%Y.%m.%d.%H'))
            })
        body += [d]

    logging.info("Prepare DPMO body %s to ES" % body)

    return body
