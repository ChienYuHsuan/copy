import logging
from datetime import datetime, timedelta

import pytz
import tenacity

import asv_pipeline.config as cfg
from asv_pipeline.es import ES
from asv_pipeline.util import return_last_value

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


@tenacity.retry(stop=tenacity.stop_after_attempt(3),
                wait=tenacity.wait_exponential(min=30, max=120, multiplier=30), reraise=True,
                retry_error_callback=return_last_value,
                retry=tenacity.retry_if_result(lambda result: result is False))
def check_burnin_tracker(nodes, timezone=pytz.utc, days=14, begin=None):

    cluster = 'zp31'

    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(days=days)).astimezone(timezone) if not begin else begin

    logger.info("from:%s, to:%s", _begin, _now)
    qry = es.index('burnin_tracker-') \
            .oneOf('host', nodes) \
            .range(_begin, _now, timezone.zone, timestamp="@start").build()
    rst = es.execute(timeout=300, payload=qry)
    logger.debug(f"logsize : {len(rst)}")
    record = []
    for x in rst:
        el = x["_source"]
        record += [el]

    return record
