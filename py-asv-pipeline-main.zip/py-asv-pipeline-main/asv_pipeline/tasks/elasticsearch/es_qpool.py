import logging
from datetime import date, datetime, timedelta

import pytz
import tenacity

import asv_pipeline.config as cfg
from asv_pipeline.es import ES
from asv_pipeline.util import parse_time_for_es, return_last_value

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def _get_es_endpoint(cluster):
    """
    This is a workaround solution, as the infrastructure team has only scattered the load from BHS to Flex for the qpool index.
    """
    if cluster == 'srf':
        cluster = 'flex'
    return ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
              password=cfg.es_password.get(cluster))


def exist_readknob(cluster, sut, timezone=pytz.utc, begin=None):
    """
    xmlcli_readback:
    """
    es = _get_es_endpoint(cluster)
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(hours=1)).astimezone(timezone) if not begin else begin
    logger.info("from:%s, to:%s", _begin, _now)
    qry = es.index('qpool') \
            .oneOf('kubernetes.host', [sut]) \
            .oneOf('log', ['xmlcli_readback:']) \
            .range(_begin, _now, timezone.zone).build()
    rst = es.execute(timeout=300, payload=qry)
    for x in rst:
        logger.info(
            "%(time)s-%(host)s : %(msg)s" % {
                "time": parse_time_for_es(x['_source']["@timestamp"], timezone),
                "msg": x['_source']["log"],
                "host": x['_source']["kubernetes"]["host"],
            })

    return len(rst) > 0


def verify_knob(cluster, sut, timezone=pytz.utc, begin=None):
    """
    Verify Fail: Knob
    """
    es = _get_es_endpoint(cluster)
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(hours=1)).astimezone(timezone) if not begin else begin
    logger.info("from:%s, to:%s", _begin, _now)
    qry = es.index('qpool') \
            .oneOf('kubernetes.host', [sut]) \
            .oneOf('log', ['Verify Fail: Knob', 'Verify Passed']) \
            .range(_begin, _now, timezone.zone).build()
    rst = es.execute(timeout=300, payload=qry)
    for x in rst:
        logger.info(
            "%(time)s-%(host)s : %(msg)s" % {
                "time": parse_time_for_es(x['_source']["@timestamp"], timezone),
                "msg": x['_source']["log"],
                "host": x['_source']["kubernetes"]["host"],
            })
        if 'Verify Passed' in rst:
            return True
    return len(rst) > 0


def check_pnp_result(cluster, testname, sut=None, ns=None, timezone=pytz.utc, begin=None):
    es = _get_es_endpoint(cluster)
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(hours=1)).astimezone(timezone) if not begin else begin
    logger.debug("from:%s, to:%s", _begin, _now)
    qry = es.index('qpool') \
            .oneOf('log', ['Flag_Cluster_PnP_SPIV_SO_Result']) \
            .IS('kubernetes.labels.name', testname) \

    if ns is not None:
        qry = qry.IS('kubernetes.namespace_name', ns)

    if sut is not None:
        qry = qry.IS('kubernetes.host', sut)

    qry = qry.range(_begin, _now, timezone.zone).build()
    rst = es.execute(timeout=300, payload=qry)
    logger.debug(testname + "_logsize:" + str(len(rst)))

    return rst


def check_ifscli_result(cluster, sut, testname, timezone=pytz.utc, begin=None):
    es = _get_es_endpoint(cluster)
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(hours=1)).astimezone(timezone) if not begin else begin
    logger.debug("from:%s, to:%s", _begin, _now)
    qry = es.index('qpool') \
            .oneOf('kubernetes.host', [sut]) \
            .oneOf('log', ['IFS Test #: 1', 'IFS Test #: 2', 'IFS Test #: 3', 'PASSED']) \
            .IS('kubernetes.labels.name', testname) \
            .range(_begin, _now, timezone.zone).build()
    rst = es.execute(timeout=300, payload=qry)
    logger.debug(testname + "_logsize:" + str(len(rst)))

    return rst


def is_notok_exist(cluster, sut, testname, ns=None, timezone=pytz.utc, begin=None):
    es = _get_es_endpoint(cluster)
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(hours=1)).astimezone(timezone) if not begin else begin
    logger.debug("from:%s, to:%s", _begin, _now)
    qry = es.index('qpool') \
            .oneOf('kubernetes.host', [sut]) \
            .oneOf('log', ['not ok']) \
            .IS('kubernetes.labels.name', testname)

    if ns is not None:
        qry = qry.IS('kubernetes.namespace_name', ns)

    qry = qry.range(_begin, _now, timezone.zone).build()

    rst = es.execute(timeout=300, payload=qry)
    logger.debug(testname + "_logsize:" + str(len(rst)))
    for x in rst:
        logger.debug(
            "%(time)s-%(host)s : %(msg)s" % {
                "time": parse_time_for_es(x['_source']["@timestamp"], timezone),
                "msg": x['_source']["log"],
                "host": x['_source']["kubernetes"]["host"],
            })

    return len(rst) > 0


def check_ras_detail(cluster, testname, targetlog, sut=None, ns=None, timezone=pytz.utc,
                     begin=None):
    es = _get_es_endpoint(cluster)
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(hours=1)).astimezone(timezone) if not begin else begin
    logger.debug("from:%s, to:%s", _begin, _now)

    qry = es.index('qpool') \
            .oneOf('log', [targetlog]) \
            .IS('log', 'ok') \
            .IS('kubernetes.labels.name', testname)

    if ns is not None:
        qry = qry.IS('kubernetes.namespace_name', ns)

    if sut is not None:
        qry = qry.IS('kubernetes.host', sut)

    qry = qry.range(_begin, _now, timezone.zone).build()

    rst = es.execute(timeout=300, payload=qry)
    logger.debug(testname + "_logsize:" + str(len(rst)))
    for x in rst:
        logger.debug(
            "%(time)s-%(host)s : %(msg)s" % {
                "time": parse_time_for_es(x['_source']["@timestamp"], timezone),
                "msg": x['_source']["log"],
                "host": x['_source']["kubernetes"]["host"],
            })

    return rst


def check_ras_knob_set(cluster, testname, sut=None, ns=None, timezone=pytz.utc, begin=None):
    es = _get_es_endpoint(cluster)
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(hours=1)).astimezone(timezone) if not begin else begin
    logger.debug("from:%s, to:%s", _begin, _now)

    qry = es.index('qpool') \
            .IS('log', 'APEI EINJ is not found') \
            .IS('kubernetes.labels.name', testname)

    if ns is not None:
        qry = qry.IS('kubernetes.namespace_name', ns)

    if sut is not None:
        qry = qry.IS('kubernetes.host', sut)

    qry = qry.range(_begin, _now, timezone.zone).build()

    rst = es.execute(timeout=300, payload=qry)
    logger.debug(testname + "_logsize:" + str(len(rst)))
    for x in rst:
        logger.debug(
            "%(time)s-%(host)s : %(msg)s" % {
                "time": parse_time_for_es(x['_source']["@timestamp"], timezone),
                "msg": x['_source']["log"],
                "host": x['_source']["kubernetes"]["host"],
            })

    return rst


@tenacity.retry(stop=tenacity.stop_after_attempt(3),
                wait=tenacity.wait_exponential(min=30, max=120, multiplier=30), reraise=True,
                retry_error_callback=return_last_value,
                retry=tenacity.retry_if_result(lambda result: result is False))
def check_heart_beat(cluster, sut, timezone=pytz.utc, begin=None, range=(0, 20)):
    es = _get_es_endpoint(cluster)
    _now = datetime.now().astimezone(timezone)
    _begin = (
        _now -
        timedelta(hours=range[0], minutes=range[1])).astimezone(timezone) if not begin else begin

    logging.info("from:%s, to:%s", _begin, _now)
    qry = es.index('qpool-')\
            .IS('kubernetes.host', sut) \
            .oneOf('log', ['Heartbeat: '])\
            .range(_begin, _now, timezone.zone)\
            .build()

    rst = es.execute(timeout=300, payload=qry)
    if isinstance(rst, list):
        logging.info(len(rst))
    return True if rst else False


def get_details(cluster, is_fields=None, oneof_fields=None, timezone=pytz.utc, begin=None):
    es = _get_es_endpoint(cluster)
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(hours=1)).astimezone(timezone) if not begin else begin
    logger.debug("from:%s, to:%s", _begin, _now)

    qry = es.index('qpool')
    if is_fields is not None:
        for item, value in is_fields:
            qry = qry.IS(item, value)

    if oneof_fields is not None:
        for item, value in oneof_fields:
            qry = qry.oneOf(item, value)

    qry = qry.range(_begin, _now, timezone.zone).build()

    rst = es.execute(timeout=300, payload=qry)
    logger.debug("logsize:" + str(len(rst)))

    return rst


def push_mem_err_to_es(metric, timestamp, metric_value):
    d = {}
    try:
        d.update({
            '@start': datetime.fromtimestamp(timestamp, pytz.timezone('Asia/Taipei')),
            '@end': datetime.now(pytz.timezone('Asia/Taipei')),
            'metric': metric,
            'value': metric_value
        })
    except Exception as e:
        logging.error(str(e))

    logging.info(f"Push {metric['instance']} memory error {metric['__name__']} record to ES")
    es = ES(url=cfg.es_endpoints['flex'], name=cfg.es_username['flex'],
            password=cfg.es_password['flex'])
    try:
        es.bulk([d], "%(idx)s-%(date)s" % {
            "idx": "pythonsv_mem_error",
            "date": date.today().strftime('%Y.%m.%d')
        })
    except Exception as e:
        logging.error("Error raised during pushing memory error record to ES: %s" % str(e))
