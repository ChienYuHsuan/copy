import logging
import re
import time
from datetime import datetime, timedelta

import pytz
import tenacity
from dateutil import parser

import asv_pipeline.config as cfg
from asv_pipeline.es import ES
from asv_pipeline.util import return_last_value


@tenacity.retry(stop=tenacity.stop_after_attempt(2),
                wait=tenacity.wait_exponential(min=30, max=60, multiplier=30), reraise=True,
                retry_error_callback=return_last_value,
                retry=tenacity.retry_if_result(lambda result: result is False))
def is_amt_test(cluster, sut, timezone=pytz.utc, begin=None, range=(6, 0)):
    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now().astimezone(timezone)
    _begin = (
        _now -
        timedelta(hours=range[0], minutes=range[1])).astimezone(timezone) if not begin else begin

    logging.info("is_amt_test sol index inquiry from:%s, to:%s", _begin, _now)
    target_type_number = [1, 4, 5, 7, 11, 12, 13, 14, 15, 18, 19]
    qry = es.index('sol-')\
            .IS('host', sut) \
            .oneOf('message', [f'TestType {idx} Latency' for idx in target_type_number])\
            .range(_begin, _now, timezone.zone)\
            .build()
    out = es.execute(timeout=300, payload=qry)
    rst = set()
    for el in out:
        rst.add(el['_source']['message'].split('=')[0].strip())

    logging.debug(rst)
    logging.info(len(rst) == len(target_type_number))
    return len(rst) == len(target_type_number)


@tenacity.retry(stop=tenacity.stop_after_attempt(3),
                wait=tenacity.wait_exponential(min=30, max=120, multiplier=30), reraise=True,
                retry_error_callback=return_last_value,
                retry=tenacity.retry_if_result(lambda result: result is False))
def check_heartbeat(cluster, sut, timezone=pytz.utc, begin=None, range=(0, 20)):
    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now().astimezone(timezone)
    _begin = (
        _now -
        timedelta(hours=range[0], minutes=range[1])).astimezone(timezone) if not begin else begin

    logging.info("from:%s, to:%s", _begin, _now)
    qry = es.index('sol-')\
            .IS('host', sut) \
            .oneOf('message', ['SOL Heartbeat'])\
            .range(_begin, _now, timezone.zone)\
            .build()

    rst = es.execute(timeout=300, payload=qry)
    qry_raw = es.index('sol_raw-')\
        .IS('host', sut) \
        .oneOf('message', ['Heartbeat'])\
        .range(_begin, _now, timezone.zone)\
        .build()
    rst_raw = es.execute(timeout=300, payload=qry_raw)
    logging.debug(rst)
    logging.debug(rst_raw)
    logging.info(type(rst))
    logging.info(type(rst_raw))
    if isinstance(rst, list) or isinstance(rst_raw, list):
        logging.info(len(rst))
        logging.info(len(rst_raw))
    return True if rst or rst_raw else False


def get_dimm_type(cluster, sut, timezone=pytz.utc, begin=None, range=30):
    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(days=range)).astimezone(timezone) if not begin else begin

    logging.info("from:%s, to:%s", _begin, _now)
    qry = es.index('sol-')\
            .IS('host', sut) \
            .oneOf('message', ['MRDIMM', 'RDIMM'])\
            .range(_begin, _now, timezone.zone)\
            .build()

    rst = es.execute(timeout=300, payload=qry)

    if rst:
        logging.debug(rst[0]["_source"].get('@timestamp'))
        logging.debug(rst[-1]["_source"].get('@timestamp'))
        matcher = re.search(r'DDR\d+ ([M]?RDIMM)\s+([a-zA-Z0-9\/\-]*)\s+',
                            rst[0]["_source"]["message"])
        return f"{matcher.group(1)} {matcher.group(2)}"
    return None


@tenacity.retry(stop=tenacity.stop_after_attempt(2),
                wait=tenacity.wait_exponential(min=30, max=60, multiplier=30), reraise=True,
                retry_error_callback=return_last_value,
                retry=tenacity.retry_if_result(lambda result: result is False))
def validate_sol_index(cluster, sut, timezone=pytz.utc, begin=None):
    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(minutes=5)).astimezone(timezone) if not begin else begin

    logging.info(f"validate sol on {sut} from:{_begin}, to:{_now}")
    qry = es.index('sol-')\
            .IS('host', sut) \
            .range(_begin, _now, timezone.zone)\
            .build()

    rst = es.execute(timeout=300, payload=qry)
    if not rst:
        return False
    logging.info(rst[0]["_source"]["@timestamp"])
    dt1 = parser.isoparse(rst[0]["_source"]["@timestamp"])
    time.sleep(300)
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(minutes=5)).astimezone(timezone) if not begin else begin

    logging.info(f"validate sol on {sut} from:{_begin}, to:{_now}")
    qry = es.index('sol-')\
            .IS('host', sut) \
            .range(_begin, _now, timezone.zone)\
            .build()

    rst = es.execute(timeout=300, payload=qry)
    if not rst:
        return False
    logging.info(rst[0]["_source"]["@timestamp"])
    dt2 = parser.isoparse(rst[0]["_source"]["@timestamp"])
    if isinstance(rst, list):
        logging.info(len(rst))
    return dt2 > dt1
