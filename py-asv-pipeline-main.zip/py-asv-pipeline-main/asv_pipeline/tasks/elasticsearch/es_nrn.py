import logging
from datetime import datetime, timedelta, timezone
from typing import Iterable, Union

import pandas as pd
import tenacity

import asv_pipeline.config as cfg
from asv_pipeline.es import ES


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def get_nrn_dataframe(hours: int = 2) -> Iterable[Union[pd.DataFrame, ES]]:
    end = datetime.now(timezone.utc)
    end += timedelta(minutes=30)
    start = end - timedelta(hours=hours)
    logging.info("from:%s, to:%s", start, end)
    cluster = "flex"
    es = ES(url=cfg.es_endpoints[cluster], name=cfg.es_username[cluster],
            password=cfg.es_password[cluster]).index("nrn_reporting")
    body = es.range(start, end, timestamp="Creation Time").build()
    df = ES.to_df(es.execute(timeout=600, payload=body))
    logging.debug(df.to_string())
    return df, es


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def update_nrn_dataframe(df: pd.DataFrame, es=None):
    if not es:
        cluster = "flex"
        es = ES(url=cfg.es_endpoints[cluster], name=cfg.es_username[cluster],
                password=cfg.es_password[cluster]).index("nrn_reporting")
    es.update(df)


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def get_nrn_dataframe_by_sutlist(sutlist: list[str],
                                 hours: int = 12) -> Iterable[Union[pd.DataFrame, ES]]:
    end = datetime.now(timezone.utc) + timedelta(minutes=30)
    start = end - timedelta(hours=hours)
    logging.info("from: %s, to: %s", start, end)

    cluster = "flex"
    es = ES(url=cfg.es_endpoints[cluster], name=cfg.es_username[cluster],
            password=cfg.es_password[cluster]).index("nrn_reporting")

    es.range(f=start, t=end, timestamp="Creation Time")

    body = {"query": {"bool": {"must": [{"terms": {"Node.keyword": sutlist}}, es._range]}}}

    df = ES.to_df(es.execute(timeout=600, payload=body))
    logging.debug(df.to_string())
    return df, es
