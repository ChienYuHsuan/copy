import logging
from datetime import datetime, timedelta

import pytz
import tenacity

import asv_pipeline.config as cfg
from asv_pipeline.es import ES
from asv_pipeline.util import return_last_value


@tenacity.retry(stop=tenacity.stop_after_attempt(3),
                wait=tenacity.wait_exponential(min=30, max=120, multiplier=30), reraise=True,
                retry_error_callback=return_last_value,
                retry=tenacity.retry_if_result(lambda result: result is False))
def check_critical_event(cluster, sut, timezone=pytz.utc, begin=None, range=(12, 0)):
    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now().astimezone(timezone)
    _begin = (
        _now -
        timedelta(hours=range[0], minutes=range[1])).astimezone(timezone) if not begin else begin

    logging.info("from:%s, to:%s", _begin, _now)
    qry = es.index('eventlog-')\
            .IS('host', sut) \
            .IS('event.severity', 'Critical')\
            .oneOf('message', ['CPU Error Occurred'])\
            .range(_begin, _now, timezone.zone)\
            .build()

    rst = es.execute(timeout=300, payload=qry)
    logging.debug(rst)
    logging.info(type(rst))
    if isinstance(rst, list):
        logging.info(len(rst))
    return True if rst else False
