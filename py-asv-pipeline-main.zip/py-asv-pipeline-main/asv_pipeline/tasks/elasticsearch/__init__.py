import logging
import os
from datetime import date, datetime

import asv_pipeline.config as cfg
from asv_pipeline.es import ES
from asv_pipeline.util import change_time_format

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)


def push_period_to_elasticsearch():
    d = {}
    try:
        d.update({
            '@start':
            datetime.strptime(change_time_format(os.environ['START']),
                              '%a %d %b %Y %I:%M:%S %p %Z'),
            '@end':
            datetime.strptime(change_time_format(os.environ['END']), '%a %d %b %Y %I:%M:%S %p %Z'),
            'Job name':
            os.environ['JOB_NAME'],
            'Build number':
            os.environ['BUILD_NUMBER'],
            'Namespaces':
            os.environ['NS']
        })
    except Exception as e:
        log.error(str(e))

    log.info("Push start/end of pipeline %s build #%s to Elasticsearch" %
             (os.environ['JOB_NAME'], os.environ['BUILD_NUMBER']))
    es = ES(url=cfg.es_endpoints['zp31'], name=cfg.es_username['zp31'],
            password=cfg.es_password['zp31'])
    try:
        es.bulk([d], "%(idx)s-%(date)s" % {
            "idx": cfg.idx_burnin_period,
            "date": date.today().strftime('%Y.%m.%d')
        })
    except Exception as e:
        log.error("Error raised during pushing data to ES: %s" % str(e))
