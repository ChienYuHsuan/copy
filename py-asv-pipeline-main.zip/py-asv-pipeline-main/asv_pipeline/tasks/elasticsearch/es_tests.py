import logging
from datetime import datetime, timedelta
from typing import List, Tuple

import pytz

import asv_pipeline.config as cfg
from asv_pipeline.es import ES
from asv_pipeline.util import change_time_format

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def get_test_summary(cluster, is_fields: List[Tuple] = None, oneof_fields: List[Tuple] = None,
                     timezone=pytz.utc, begin=None, day=7, start=None, end=None):
    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))

    if day != 0:
        logger.info("Get test summary since last %d days" % day)
        _now = datetime.now().astimezone(timezone)
        _begin = (_now - timedelta(days=day)).astimezone(timezone) if not begin else begin
    else:
        _now, _begin = end, start
    logger.info("begin %s now %s" % (_begin, _now))
    _now = datetime.strptime(change_time_format(str(_now)), '%a %d %b %Y %I:%M:%S %p %Z')
    _begin = datetime.strptime(change_time_format(str(_begin)), '%a %d %b %Y %I:%M:%S %p %Z')

    qry = es.index('tests-')

    if is_fields is not None:
        for item, value in is_fields:
            qry = qry.IS(item, value)

    if oneof_fields is not None:
        for item, value in oneof_fields:
            qry = qry.oneOf(item, value)

    qry = qry.range(_begin, _now, timezone.zone) \
             .build()

    rst = es.execute(timeout=300, payload=qry)
    logger.debug("logsize:" + str(len(rst)))

    return rst
