import logging
import re
from datetime import datetime, timedelta

import pytz

import asv_pipeline.config as cfg
from asv_pipeline.clusterscope.handler import get_cpu, get_state
from asv_pipeline.es import ES
from asv_pipeline.util import get_cluster_by_naming, parse_time_for_reset_test_in_es

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def check_reset_test(sut, timezone=pytz.utc, begin=None, match=False):

    if get_cluster_by_naming(sut) == 'bhs' or get_cluster_by_naming(sut) == 'flex':
        # cluster = 'zp31'
        # https://github.com/intel-innersource/applications.validation.post-silicon.cluster-execution.cycle-tests/blob/main/es_upload/es_upload.sh#L159C4-L159C11
        cluster = 'flex'
    else:
        cluster = 'icx-1'

    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(hours=2)).astimezone(timezone) if not begin else begin

    logger.info("from:%s, to:%s", _begin, _now)
    qry = es.index('reset_test_index') \
            .IS('host', sut) \
            .range(_begin, _now, timezone.zone, "timestamp").build()
    rst = es.execute(timeout=300, payload=qry)
    for x in rst:
        logger.info(
            f'{parse_time_for_reset_test_in_es(x["_source"]["timestamp"], timezone)}s-{x["_source"]["host"]} runs {x["_source"]["repetition"]}'
        )
        reptition = int(re.split(r' ', x["_source"]["repetition"])[1])
        target = int(x["_source"]["target"])
        logger.info(f'we get the number {reptition}/{target}')
        # logger.info(
        #     "%(time)s-%(host)s : %(msg)s" % {
        #         "time": parse_time_for_es(x['_source']["@timestamp"], timezone),
        #         "msg": x['_source']["log"],
        #         "host": x['_source']["kubernetes"]["host"],
        #     })
        #   if 'Verify Passed' in rst:
        #     return True
        if reptition >= 1 and not match:
            return True
        elif match and reptition == target:
            return True
    return False


def check_dpmo_completion(timezone=pytz.utc, min=10, begin=None):

    cluster = 'flex'

    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(minutes=min)).astimezone(timezone) if not begin else begin

    logger.info("from:%s, to:%s", _begin, _now)
    qry = es.index('reset_test_index') \
            .oneOf('log', ['test-end-indicator', 'ENDING-TEST-FAILED'])  \
            .range(_begin, _now, timezone.zone, "timestamp").build()
    rst = es.execute(timeout=300, payload=qry)
    logger.info(f'DPMO check results: {rst}')
    suts = set()
    failed_suts = set()
    suts_comp = []
    for x in rst:
        host = x["_source"]["host"]
        if x["_source"]["log"] == 'ENDING-TEST-FAILED':
            failed_suts.add(host)
            continue
        target = x['_source']['target']
        repetition = x['_source']['repetition']
        match = re.match(r'repetition (\d+)', repetition)
        iteration = 0
        if match:
            iteration = match.group(1)
        if iteration == target:
            suts.add(host)
    suts.difference_update(failed_suts)

    if suts:
        cache = None
        cpus = get_cpu(list(suts), cache)
        states = get_state(list(suts), cache)
        for h, cpu in cpus.items():
            if cpu not in ['SRF-AP', 'SRF-SP'] or (h in states and states[h] != 'EXC'):
                logger.info("Skip node %s" % h)
                continue
            logger.info("%s completes DPMO" % h)
            suts_comp.append(h)
    logger.info("suts_comp %s" % suts_comp)

    # Return node list for Modifying pool name to COM
    return suts_comp


def check_dpmo_remainder(nodes, timezone=pytz.utc, min=10, begin=None):

    cluster = 'flex'

    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(minutes=min)).astimezone(timezone) if not begin else begin

    logger.info("from:%s, to:%s", _begin, _now)
    qry = es.index('reset_test_index') \
            .oneOf('host', nodes) \
            .oneOf('log', ['Successfull after']) \
            .range(_begin, _now, timezone.zone, "timestamp").build()
    rst = es.execute(timeout=300, payload=qry)

    record = {}
    for x in rst:
        target = x['_source']['target']
        repetition = x['_source']['repetition']
        match = re.match(r'repetition (\d+)', repetition)
        iteration = 0
        if match:
            iteration = match.group(1)
        host = x['_source']['host']
        timestamp = x['_source']['timestamp']

        if host not in record:
            logging.debug(
                f'{host} has done with {iteration}/{target} # {repetition} at {timestamp}')
            record[host] = int(target) - int(iteration) if target != iteration else 0
    # out = {}
    # for k,v in record.items():
    #     if v:
    #         out[k] = v
    # return out
    return record
