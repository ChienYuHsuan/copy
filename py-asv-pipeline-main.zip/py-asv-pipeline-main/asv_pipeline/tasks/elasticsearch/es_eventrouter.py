import json
import logging
import sys
from datetime import datetime, timedelta

import asv_pipeline.config as cfg
from asv_pipeline.es import ES
from asv_pipeline.es.eventrouter import extract_events
from asv_pipeline.util import get_cluster_by_naming

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def extract_log(**kwargs):
    """
    Extract the evens log of particular k8s cluster from eventrouter in ElasticSearch
    
    :param str cluster: option [opus,flex,icx-1..]
    :return: list[ log ]
    :raises Exception: if the cluster doesn't exist
    """
    cluster = kwargs.get('params').get('cluster', None)
    period = kwargs.get('params').get('period', 6)
    if not cluster:
        raise Exception("failing task becuase there's no designate cluster")

    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now()
    logger.info("period %d" % (period))
    _begin = _now - timedelta(hours=int(period))
    qry = es.index('qpool') \
            .IS('log', '"reason":"Started"') \
            .IS('kubernetes.pod_name', 'eventrouter') \
            .notOneof('log', ['"namespace":"monitoring"', '"namespace":"mgmt"', '"verb":"UPDATED"']) \
            .range(_begin, _now).build()
    rst = es.execute(timeout=300, payload=qry)

    logger.info(json.dumps(qry))
    logs = extract_events(rst)
    return logs
    # kwargs['ti'].xcom_push(key='es.eventrouter.log', value=logs)


def get_nrn_time(node):
    cluster = get_cluster_by_naming(node)
    try:
        es = ES(url=cfg.es_endpoints[cluster], name=cfg.es_username[cluster],
                password=cfg.es_password[cluster])
    except Exception as e:
        logger.error(str(e))
        sys.exit(1)
    _now = datetime.now()
    # logger.info("period %d" % (period))
    _begin = _now - timedelta(hours=72)
    qry = es.index('qpool') \
        .IS('log', 'NodeNotReady') \
        .IS('log', node) \
        .IS('kubernetes.pod_name', 'eventrouter') \
        .range(_begin, _now).build()
    rst = es.execute(timeout=300, payload=qry)
    logs = extract_events(rst)
    if logs:
        try:
            datetime_object = datetime.strptime(logs[0]['event']['metadata']['creationTimestamp'],
                                                '%Y-%m-%dT%H:%M:%SZ')
        except Exception as e:
            logger.error(str(e))
            datetime_object = datetime.utcnow()
        logger.info('NRN timestamp for node %s: %s' % (node, datetime_object))
        return datetime_object
    else:
        logger.warning("No NotReady event for node %s in past 3 days. Set NRN timestamp to now." %
                       node)
        return datetime.utcnow()
