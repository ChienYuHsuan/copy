# if sys.version_info.major == 3 and sys.version_info.minor < 9
from __future__ import annotations

import json
import logging
import re
import sys
import time

import pexpect
import tenacity

from asv_pipeline.tasks.clusterscope import get_cpu
from asv_pipeline.util import expect_handler

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s - %(lineno)d')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def _get_xmlcli(cluster, node, idsid):
    """
    Xmlci CMD from node
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :return
    """
    eb = expect_handler.sut(cluster, node, idsid)
    eb.timeout = 300
    return eb


def _prerequisite(eb):
    eb.sendline("from pysvtools.xmlcli import XmlCli as cli")
    eb.sendline('cli.clb._setCliAccess("linux")')
    eb.sendline('cli.clb.AuthenticateXmlCliApis = True')
    time.sleep(2)

    eb.expect(".*>>>.*\r\n")
    return eb


def _cleanup_xmlcli(eb, reboot=False):
    eb.sendline("ctr snapshot remove xmlcli-auto")
    eb.sendline("ctr t delete -f xmlcli-auto")
    eb.sendline("ctr container delete xmlcli-auto")

    time.sleep(2)

    if reboot:
        eb.sendline("ipmitool power cycle")  # ipmitool power cycle -> cold reboot
        eb.expect([r'Chassis Power Control', r'Connection to'])

    time.sleep(10)
    eb.sendline("exit")
    eb.sendcontrol("D")

    return eb


def _execute_xmlcli(cluster, node, idsid, cmd="progknobs", knobs=None):
    cpu = get_cpu([node])[node]
    eb = _get_xmlcli(cluster, node, idsid)
    version = 'v4.0'
    if re.search(r"SPR", cpu):
        version = "v3.0"
    logger.info(f"knobs : {knobs} with command : {cmd}")
    eb.sendline(f"""
cat << EOF | bash
systemctl disable --now docker && systemctl mask docker && rm -f /run/docker.sock /run/dockershim.sock; systemctl restart kubelet containerd
                
sleep 6
                
ctr image pull prt-registry.sova.intel.com/sandstone:xmlcli-{version}

ctr snapshot remove xmlcli-auto
ctr t delete -f xmlcli-auto
ctr container delete xmlcli-auto

sleep 2

ctr run --privileged --rm  --env XC_KNOB="{knobs}" --env XC_OP={cmd} --env XC_BYPASS_HANG=true prt-registry.sova.intel.com/sandstone:xmlcli-{version} xmlcli-auto
EOF
    """)
    time.sleep(2)
    return eb


def _get_xmlcli_raw(cluster, node, idsid):
    cpu = get_cpu([node])[node]
    eb = _get_xmlcli(cluster, node, idsid)
    version = 'v4.0'
    if re.search(r"SPR", cpu):
        version = "v3.0"
    eb.sendline(f"""
cat << EOF | bash
systemctl daemon-reload && systemctl disable --now docker && systemctl mask docker && rm -f /run/docker.sock /run/dockershim.sock; systemctl restart kubelet containerd

sleep 6
                 
ctr image pull prt-registry.sova.intel.com/sandstone:xmlcli-{version}

ctr snapshot remove xmlcli-auto
ctr t delete -f xmlcli-auto
ctr container delete xmlcli-auto

sleep 2

ctr run -t --privileged --rm prt-registry.sova.intel.com/sandstone:xmlcli-{version} xmlcli-auto python3

EOF
    """)
    time.sleep(2)
    eb.expect(">>>")
    return eb


def _parse_bios_info(s) -> dict[str:dict[str, str]]:
    ret = {}
    for line in re.split(r'\r\n?', s):
        if not re.search(r"\s+{'", line):
            continue
        rst = re.search(r'(.*){(.*)}', line)
        child = {}
        for x in re.split(r',', rst.group(2)):
            inner_rst = re.search(r"'(.*)': '(.*)'", x)
            child[inner_rst.group(1).strip()] = inner_rst.group(2).strip()
        ret[rst.group(1).strip()] = child
        # print(rst.group(1).strip(), child)
    return ret


def _parse_knob_val(s) -> dict[str:str]:
    ret = {}
    for line in re.split(r'\r\n?', s):
        if not re.search(r"(.*)(?<!\})\s+=\s+(?<!\{)(.*)", line):
            continue
        rst = re.search(r'(.*)(?<!\})\s+=\s+(?<!\{)(.*)', line)
        ret[rst.group(1).strip()] = rst.group(2).strip()
    return ret


def restoreknobs(cluster, node, idsid, reboot=True):
    """
    restoreknob from defaultBios

    return: dict[str, list[str]] -> knob : [previous, cur] return the dict along with knob as the key and array as the value.
                                           The first item in list is previous value, and another is current value.
    """
    eb = _get_xmlcli_raw(cluster, node, idsid)
    eb.timeout = 300
    time.sleep(1)
    eb = _prerequisite(eb)
    eb.sendline("cli.CvLoadDefaults()")
    time.sleep(1)
    rst = eb.expect([
        r'CLI command executed successfully', r'CLI Response not yet ready',
        r'Error while triggering CLI Entry Point'
    ])
    if rst == 1:
        raise Exception("CLI Response not yet ready")
    start = False
    eb.expect(r">>>")
    logging.info(eb.before)
    rst = {}
    for line in re.split(r'\r\n', eb.before):
        if start and re.search(r'\|', line):
            segs = re.split(r'\|', line)
            if re.search(r'--', segs[1]):
                continue

            rst[segs[3].strip()] = [segs[5].strip(), segs[6].strip()]
        elif re.search(r'PreviousVal', line):
            start = True
        # print(line)
    # eb.interact()
    logging.debug(rst)
    eb.sendline(r'exit()')
    _cleanup_xmlcli(eb, reboot)
    return rst


load_default = restoreknobs


def get_current_knobs(cluster, node, idsid):
    """
    Get knobs' current values
    return: dict[str, str] -> knob : value in form of HEX
    """
    eb = _get_xmlcli_raw(cluster, node, idsid)
    eb = _prerequisite(eb)
    eb.sendline("import xml.etree.ElementTree as ET")
    eb.sendline("import time")
    eb.sendline("cli.savexml()")
    eb.expect(r">>>")
    time.sleep(1)

    eb.sendline("tree = ET.parse('/xmlcli/pysvtools/xmlcli/out/PlatformConfig.xml')")
    """
    Use a trick to avoid capturing so early
    """
    eb.sendline("""
for child in tree.getroot():
    print(child.tag, child.attrib)

print(f"{'#'*7}0")
    """)
    eb.expect("#######0")
    rst = eb.before
    eb.expect(r">>> (?!p)")
    # logging.debug(rst)
    ret = []
    ret.append(_parse_bios_info(rst))
    eb.sendline("""
for child in tree.getroot().findall('.//knob'):
    print(f"{child.attrib['name']} = {child.attrib['CurrentVal']}")

print(f"{'#'*7}0")
    """)
    eb.expect("#######0")
    rst = eb.before

    eb.expect(r">>> (?!p)")
    ret.append(_parse_knob_val(rst))
    # logging.debug(rst)
    # eb.interact()
    eb.sendline(r'exit()')
    _cleanup_xmlcli(eb)
    logging.debug(ret)
    return ret


def progknobs(cluster, node, idsid, knobs, reboot=True):
    """
    progknob to node in particular k8s cluster
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :param str knobs  : knobs keys+values
    :return
    """
    eb = _execute_xmlcli(cluster, node, idsid, "progknobs", knobs)
    rst = eb.expect(["Command ended successfully"])
    logger.info("rst :%s" % rst)
    if rst == 0:
        out = eb.before
        # eb.sendline("ctr t kill -a xmlcli-auto")
        eb = _cleanup_xmlcli(eb, reboot)
        logger.info(out)
        return out
    raise Exception("no success")


@tenacity.retry(stop=tenacity.stop_after_attempt(3),
                wait=tenacity.wait_exponential(min=10, max=40, multiplier=10), reraise=True)
def get_knobs_from_sut(cluster, node, idsid, tag=None):
    cpu = get_cpu([node])[node]
    eb = _get_xmlcli(cluster, node, idsid)
    eb.send(f"""
cat frameworks.automation.sirloin.hook/{cpu}/knobs;echo '>>>>>'
""")
    eb.expect('cat framework.*\r\n')
    time.sleep(7)
    sys.stdout.flush()
    eb.expect('>>>>>.*\r\n')
    knobs_raw = eb.before
    logging.info(f'knobs_raw:{knobs_raw}')
    target_knobs = {}
    for line in knobs_raw.split("\r\n"):
        if line.startswith('#'):
            continue
        if "=" in line:
            for el in line.strip().split(","):
                if "=" in el:
                    A = el.split("=")
                    target_knobs[A[0]] = A[1]
    logging.info(target_knobs)
    # tag has the highest priority
    if tag:
        eb.send(f"""
cat frameworks.automation.sirloin.hook/{cpu}/{tag}/knobs ;echo '>>>>>'
""")
        eb.expect('cat frameworks.*\r\n')
        time.sleep(5)
        rst = eb.expect(['No such file or directory', '>>>>>\r\n'])
        if rst == 1:
            knobs_raw = eb.before
            logging.info(f'knobs_raw in tag {tag}:{knobs_raw}')
            for line in knobs_raw.split("\r\n"):
                if line.startswith('#'):
                    continue
                if "=" in line:
                    for el in line.strip().split(","):
                        if "=" in el:
                            A = el.split("=")
                            target_knobs[A[0]] = A[1]

    A = [f"{k}={v}" for k, v in target_knobs.items()]
    knobs = ",".join(A)
    logger.info(f"Knobs: {knobs}")
    return knobs


@tenacity.retry(stop=tenacity.stop_after_attempt(3),
                wait=tenacity.wait_exponential(min=10, max=40, multiplier=10), reraise=True)
def progknobs_from_sut(cluster, node, idsid, reboot=True):
    knobs = get_knobs_from_sut(cluster, node, idsid)
    if not knobs:
        raise ("No knobs found")
    eb = _execute_xmlcli(cluster, node, idsid, cmd="progknobs", knobs=knobs)
    rst = eb.expect(["Command ended successfully"])
    logger.info("rst :%s" % rst)
    if rst == 0:
        out = eb.before
        # eb.sendline("ctr t kill -a xmlcli-auto")
        eb = _cleanup_xmlcli(eb, reboot)
        logger.info(out)
        return out
    raise Exception("no success")


def _parse_read_knobs(ctx, knobs):
    xmlcli_expected, xmlcli_readback = None, None
    ret = False
    for line in ctx.split("\r\n"):
        if "xmlcli_expected" in line:
            line = re.sub(r'xmlcli_expected: ', '', line)
            line = re.sub(r'\'', '"', line)
            xmlcli_expected = json.loads(line)
        elif "xmlcli_readback" in line:
            line = re.sub(r'xmlcli_readback: ', '', line)
            line = re.sub(r'\'', '"', line)
            xmlcli_readback = json.loads(line)
        elif "Verify Passed!" in line:
            ret = True

    if xmlcli_expected:
        logger.info("xmlcli_expected : " + json.dumps(xmlcli_expected))
    else:
        xmlcli_expected = {}
        for knob in knobs.split(","):
            if "=" in knob:
                A = knob.split("=")
                xmlcli_expected[A[0]] = A[1]
    if xmlcli_readback:
        # LoggingMixin().log.info("xmlcli_readback : " + json.dumps(xmlcli_readback))
        logger.info("xmlcli_readback : " + json.dumps(xmlcli_readback))
    if ret:
        return ret
    if not ret and xmlcli_readback:
        for k, v in xmlcli_readback.items():
            if xmlcli_expected[k] != v and re.sub(r'0x', '', str(xmlcli_expected[k])) != v:
                ret = False
                break
    return ret


@tenacity.retry(stop=tenacity.stop_after_attempt(3),
                wait=tenacity.wait_exponential(min=10, max=40, multiplier=10), reraise=True)
def readknobs_from_sut(cluster, node, idsid, reboot=True):
    knobs = get_knobs_from_sut(cluster, node, idsid)
    if not knobs:
        raise Exception("No knobs found")
    eb = _execute_xmlcli(cluster, node, idsid, cmd="readknobs", knobs=knobs)
    rst = eb.expect(["ok 1.*xmlcli.*\r\n", pexpect.TIMEOUT])
    logger.info("rst :%s" % rst)
    if rst == 0:
        out = eb.before
        eb = _cleanup_xmlcli(eb, False)
        logger.debug(out)
        return _parse_read_knobs(out, knobs)
        # return out
    raise Exception("no success")


def readknobs(cluster, node, idsid, knobs):
    """
    readknob to node in particular k8s cluster
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :param str knobs  : knobs keys+values
    """
    eb = _execute_xmlcli(cluster, node, idsid, "readknobs", knobs)
    # rst = eb.expect([">>>>>", "Command ended successfully", pexpect.TIMEOUT])
    rst = eb.expect(["(ok|not ok) 1.*xmlcli.*\r\n", pexpect.TIMEOUT])
    logger.info("rst value: %d" % rst)
    if rst == 0:
        out = eb.before
        logger.debug(out)
        eb = _cleanup_xmlcli(eb, False)
        return _parse_read_knobs(out, knobs)
    raise Exception("no success")


def _getbootorder(cluster, node, eb=None, redo=False):
    """
    getbootorder to node in particular k8s cluster
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :param str eb  : for retry mechanism, providing the expect_handler bastion instance
    :param bool redo : for avoding infinite recursion 
    :return tuple : order and boot map table
    """
    if not eb:
        eb = expect_handler.sut(cluster, node)

    eb.sendline("ctr i pull prt-registry.sova.intel.com/sandstone:xmlcli-v3.0")
    eb.sendline(
        "ctr run -t --privileged prt-registry.sova.intel.com/sandstone:xmlcli-v3.0 xmlcli-auto python3"
    )
    rst = eb.expect([r"\>\>\>", r'ctr: snapshot \".+\": already exists', r'task .+ already exists'])
    logger.debug("rst value: %d" % rst)
    ret = None
    if rst == 0:
        eb.sendline("from pysvtools.xmlcli import XmlCli as cli")
        eb.sendline('cli.clb._setCliAccess("linux")')
        eb.sendline('cli.GetBootOrder()')
        eb.expect("Requested operations completed successfully")
        eb.sendline('exit()')
        ret = eb.before
        # eb.sendline("ctr t kill -a xmlcli-auto")
        eb.sendline("ctr t delete -f xmlcli-auto;ctr c rm xmlcli-auto")
        eb.sendline("exit")
        eb.expect([pexpect.EOF, r'closed'])

        rst, mp = None, {}
        logger.debug(ret)
        for line in ret.split("\r\n"):
            if re.search(r'Boot Order:', line):
                rst = line.split(":")[1].strip().split("-")
            if re.search(r'\w+ \-', line):
                out = line.split("-")
                mp[str(out[0].strip())] = out[1].strip()
        logger.debug(rst)
        logger.debug(mp)
        return rst, mp
    else:
        if redo:
            return eb.before
        # eb.sendline("ctr t kill -a xmlcli-auto")
        eb.sendline("ctr t delete -f xmlcli-auto")
        eb.sendline("ctr c rm xmlcli-auto")
        return _getbootorder(cluster, node, eb, True)


def _setbootorder(cluster, node, order, eb=None, redo=False):
    """
    (deprecated)setBootOrder to node in particular k8s cluster
    Due to no workable of SetBootOrder func, deprecate this func.
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :param str order  : give the sequence of order, e.g. 23-13-03-01-00-02-04-05-06-07-08-09-0A-0B-0C-0D-0E-0F-10-11-12-14-15-16-17-18-19-1A-1B-1C-1D-1E-1F-20-21
    :param str eb  : for retry mechanism, providing the expect_handler bastion instance
    :param bool redo : for avoding infinite recursion 
    :return tuple : order and boot map table
    """
    if not eb:
        eb = expect_handler.sut(cluster, node)

    eb.sendline("ctr i pull prt-registry.sova.intel.com/sandstone:xmlcli-v3.0")
    eb.sendline(
        "ctr run -t --privileged prt-registry.sova.intel.com/sandstone:xmlcli-v3.0 xmlcli-auto python3"
    )
    rst = eb.expect([r"\>\>\>", r'ctr: snapshot \".+\": already exists', r'task .+ already exists'])
    logger.debug("rst value: %d" % rst)
    ret = None
    if rst == 0:
        eb.sendline("from pysvtools.xmlcli import XmlCli as cli")
        eb.sendline('cli.clb._setCliAccess("linux")')
        eb.sendline('cli.SetBootOrder(%(order)s)' % {'order': order})
        eb.expect("Requested operations completed successfully")
        eb.sendline('exit()')
        ret = eb.before
        # eb.sendline("ctr t kill -a xmlcli-auto")
        eb.sendline("ctr t delete -f xmlcli-auto")
        eb.sendline("ctr c rm xmlcli-auto")
        eb.sendline("ipmitool power reset")
        eb.sendline("exit")
        eb.expect([pexpect.EOF, r'closed'])

    else:
        if redo:
            return eb.before
        # eb.sendline("ctr t kill -a xmlcli-auto")
        eb.sendline("ctr t delete -f xmlcli-auto")
        eb.sendline("ctr c rm xmlcli-auto")
        return _setbootorder(cluster, node, order, eb, True)
    return ret
