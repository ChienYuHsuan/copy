import json
import logging
import re
from datetime import datetime, timedelta
from typing import List

import pytz

import asv_pipeline.config as cfg
from asv_pipeline.es import ES
from asv_pipeline.tasks import os, sysman
from asv_pipeline.tasks.os import load_bkc_version
from asv_pipeline.util import parse_time_for_es

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.DEBUG)


def check_bkc_version(cluster, node, idsid=None, cpu=None, bkc=None, mem=None, io=None, tag=None,
                      pass_if_no_such_file=True):
    sysman_out = sysman.status(cluster, node, idsid)
    sysman_out_lines = sysman_out.split('\r\n')
    sysman_dict = {}
    for line in sysman_out_lines:
        if 'OS reported by System is Linux' in line:
            sysman_dict['Linux'] = line.split('Linux ')[1]
        elif 'OS version is' in line:
            sysman_dict['OS version'] = line.split('OS version is ')[1]
        elif 'BMC version' in line:
            sysman_dict['BMC version'] = line.split('BMC version ')[1]
        elif 'BIOS version' in line:
            sysman_dict['BIOS version'] = line.split('BIOS version ')[1]
        elif 'cpuid version' in line:
            sysman_dict['cpuid version'] = line.split('cpuid version ')[1]
        elif 'microcode version' in line:
            sysman_dict['microcode'] = line.split('microcode version ')[1]
        elif 'CPLD main:' in line:
            sysman_dict['CPLD main'] = line.split('CPLD main:')[1]
        elif 'CPLD debug:' in line:
            sysman_dict['CPLD debug'] = line.split('CPLD debug:')[1]
        elif 'CPLD scm:' in line:
            sysman_dict['CPLD scm'] = line.split('CPLD scm:')[1]
        elif 'CPLD pfr:' in line:
            sysman_dict['CPLD pfr'] = line.split('CPLD pfr:')[1]

    _, mp = os.ethtool(cluster, node, idsid)
    logging.info(mp)

    for _, kv in mp.items():
        if kv['ipaddr']:
            sysman_dict[kv['driver']] = {
                "NIC version": kv['version'],
                "NIC firmware": kv['fw_version']
            }
    str_sysman = json.dumps(sysman_dict)
    logging.info(str_sysman)
    js_sysman = json.loads(str_sysman)
    withFile, js = load_bkc_version(cluster, node, idsid, cpu, bkc, mem, io, tag)
    if withFile:
        if js_sysman != js:
            logging.error("The JSON files are different")
            logging.error("sysman_dict: %s", json.dumps(sysman_dict, indent=4))
            logging.error("loaded_bkc_version: %s", json.dumps(js, indent=4))
        else:
            logging.info("The JSON files are the same")
        return js_sysman == js, str_sysman
    return pass_if_no_such_file, str_sysman


def check_version(cluster, node, expect={}, idsid=None):
    """
    "ingredient": {
        "ucode": "0xaa000080",
        "ifwi": "0082.D.12.WAVE2",
        "CPLD_main": "313.4_v1",
        "CPLD_debug": "",
        "CPLD_scm": "",
        "CPLD_pfr": "",
        "os": "5.15.0-spr.bkc.pc.7.7.4.x86_64",
        "BMC": "0.91-164",
        "nic-fortville-firmware": "8.10",
        "nic-columbiaville-firmware": "2.4",
        "nic-fortville-driver": "i40e-2.19.1_rc8"
    },
    return result of comparsion & ethtool mp
    """
    sysman_out = sysman.status(cluster, node, idsid)
    logging.info(sysman_out)

    os_pattern = r'(?<=OS reported by System is Linux ).+x86_64'
    bmc_pattern = r'(?<=BMC version ).+'
    microcode_pattern = r'(?<=microcode version ).+'
    bios_pattern = r'(?<=BIOS version ).+'
    cpld_main_pattern = r'(?<=CPLD main:).+'
    cpld_debug_pattern = r'(?<=CPLD debug:).+'
    cpld_scm_pattern = r'(?<=CPLD scm:).+'
    cpld_pfr_pattern = r'(?<=CPLD pfr:).+'

    os_version = re.search(os_pattern, sysman_out)[0]
    bmc_version = "-".join(re.search(bmc_pattern, sysman_out)[0].split("-")[0:2])
    ucode_version = re.search(microcode_pattern, sysman_out)[0]
    bios_version = re.search(bios_pattern, sysman_out)[0]
    cpld_main_hash = re.search(cpld_main_pattern, sysman_out)[0]
    cpld_debug_hash = re.search(cpld_debug_pattern, sysman_out)[0]
    cpld_scm_hash = re.search(cpld_scm_pattern, sysman_out)[0]
    cpld_pfr_hash = re.search(cpld_pfr_pattern, sysman_out)[0]

    rst = True
    if expect['os'] and expect['os'] not in os_version:
        logging.error("OS version is different:(sut)%s vs(input) %s" % (os_version, expect['os']))
        rst = False
    if expect['BMC'] and expect['BMC'] not in bmc_version:
        logging.error("BMC version is different:(sut)%s vs (input)%s" %
                      (bmc_version, expect["BMC"]))
        rst = False
    if expect["ucode"] and expect["ucode"] not in ucode_version:
        logging.error("ucode version is different:(sut)%s vs (input)%s" %
                      (ucode_version, expect["ucode"]))
        rst = False
    if expect["ifwi"] and expect["ifwi"] not in bios_version:
        logging.error("ifwi version is different:(sut)%s vs (input)%s" %
                      (bios_version, expect["ifwi"]))
        rst = False
    # if expect['CPLD-Hash'] and len(
    #         expect['CPLD-Hash']) >= 64 and expect['CPLD-Hash'][0:64] not in cpld_hash:
    #     logging.error("CPLD-Hash version is different:(sut)%s vs (input)%s" %
    #                   (cpld_hash, expect["CPLD-Hash"][0:64]))
    #     rst = False
    if expect['CPLD_main'] and expect['CPLD_main'] not in cpld_main_hash:
        logging.error("CPLD main version is different:(sut)%s vs (input)%s" %
                      (cpld_main_hash, expect["CPLD_main"]))
        rst = False
    if expect['CPLD_debug'] and expect['CPLD_debug'] not in cpld_debug_hash:
        logging.error("CPLD debug version is different:(sut)%s vs (input)%s" %
                      (cpld_debug_hash, expect["CPLD_debug"]))
        rst = False
    if expect['CPLD_scm'] and expect['CPLD_scm'] not in cpld_scm_hash:
        logging.error("CPLD scm version is different:(sut)%s vs (input)%s" %
                      (cpld_main_hash, expect["CPLD_scm"]))
        rst = False
    if expect['CPLD_pfr'] and expect['CPLD_pfr'] not in cpld_pfr_hash:
        logging.error("CPLD pfr version is different:(sut)%s vs (input)%s" %
                      (cpld_main_hash, expect["CPLD_pfr"]))
        rst = False
    ethtool_out, mp = os.ethtool(cluster, node, idsid)
    logging.info(ethtool_out)

    if expect["nic-fortville-firmware"]:
        for k, v in mp.items():
            if v['driver'] == 'i40e':
                if expect["nic-fortville-firmware"] not in v['fw_version']:
                    logging.error(
                        "nic-fortville-firmware version is different: (sut)%s vs (input)%s" %
                        (v['fw_version'], expect["nic-fortville-firmware"]))
                    rst = False

    if expect["nic-fortville-driver"]:
        for k, v in mp.items():
            if v['driver'] == 'i40e':
                if v['version'] not in expect["nic-fortville-driver"]:
                    logging.error(
                        "nic-fortville-driver version is different: (sut)%s vs (input)%s" %
                        (v['version'], expect["nic-fortville-driver"]))
                    rst = False

    if expect['nic-columbiaville-firmware']:
        for k, v in mp.items():
            if v['driver'] == 'ice':
                if expect['nic-columbiaville-firmware'] not in v['fw_version']:
                    logging.error(
                        "nic-columbiaville-firmware version is different: (sut)%s vs (input)%s" %
                        (v['fw_version'], expect["nic-columbiaville-firmware"]))
                    rst = False
    logging.info(expect)
    return rst, mp


def set_pxe_as_first_boot_device(cluster, sut, nics, halt=(60, 15), idsid=None):
    """
    return Tuple(str,str) : give you the original bootorder and current one
    """
    mac = None
    for k, v in nics.items():
        if v['ipaddr']:
            mac = v['mac']
            break
    MAC = "".join(mac.split(":")).upper()
    logging.info(MAC)

    old, mp = os.bootorder(cluster, sut, idsid)
    target = None
    for k, v in mp.items():
        if MAC in v and re.search(r'PXEv4', v):
            logging.debug("%s [%s] needs to be the first" % (k, v))
            target = k
            break
    new = [target] + [x for x in old if x != target]
    os.setorder(cluster, sut, ",".join(new), idsid, halt)
    return old, new


def set_pxe_back(cluster, sut, order: List, halt=(60, 15), idsid=None):
    os.setorder(cluster, sut, ",".join(order), idsid, halt)
    rst, _ = os.bootorder(cluster, sut, idsid)
    return rst


def check_sys_status(cluster, sut, idsid=None):
    return os.verify_sys_check_result(os.sys_check(cluster, sut, idsid))


# def _set_pxe_as_first_boot_device(cluster, sut, order, mp):
#     """
#     Set PXE boot option as the first option
#     input the current boot order and the related maptable
#     :param order List[str]: the current boot order
#     :param mp    Dict[str,str] the id : the related devices
#     :return BootOrderChanged Knobs
#     """
#     goal = None
#     for i, x in enumerate(order):
#         if "UEFI PXEv4" in mp[x]:
#             goal = {"oid": int(order[0], 16), "tidx": i, "tid": int(x, 16)}
#             break

#     logging.info("the goal of boot order :" + get_bios_order_knob(**goal))
#     logging.info(goal)
#     logging.info(progknobs(cluster, sut, get_bios_order_knob(**goal)))
#     sysman.ac_cycle(cluster, sut)
#     return goal

# def _set_pxe_back(cluster, sut, goal):
#     tmp = goal["tid"]
#     goal["tid"] = goal["oid"]
#     goal["oid"] = tmp

#     logging.info("the goal of boot order :" + get_bios_order_knob(**goal))
#     logging.info("the goal of boot order :" + str(goal))
#     rst = progknobs(cluster, sut, get_bios_order_knob(**goal))
#     logging.ac_cycle(cluster, sut)
#     logging.info(rst)
#     return rst


def check_pxe(cluster, sut, timezone=pytz.utc, begin=None):

    es = ES(cfg.es_endpoints.get(cluster), name=cfg.es_username.get(cluster),
            password=cfg.es_password.get(cluster))
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(hours=1)).astimezone(timezone) if not begin else begin
    logging.info("from:%s, to:%s", _begin, _now)
    qry = es.index('sol') \
            .oneOf('host', [sut]) \
            .oneOf('message', ['iPXE']) \
            .range(_begin, _now, timezone.zone).build()
    rst = es.execute(timeout=300, payload=qry)
    for x in rst:
        logging.info(
            "%(time)s-%(host)s : %(msg)s" % {
                "time": parse_time_for_es(x['_source']["@timestamp"], pytz.timezone("Asia/Taipei")),
                "msg": x['_source']["message"],
                "host": x['_source']["host"],
            })
        if "iPXE initialising devices...ok" in x['_source']["message"]:
            return True
    return False


def get_bkc_naming(cluster, node: str, idsid=None):
    import asv_pipeline.clusterscope.handler as cshandler
    from asv_pipeline.sharepoint.report_util import get_bkc_detail
    meta = cshandler.get_metadata_by_nodes([node])
    logging.debug(meta)

    out = get_bkc_detail(meta[0])

    if out:
        logging.debug(out)
        match = re.search(r'(BKC)#(\d+)', out.split("\n")[0])
        logging.info(match)
        if match:
            logging.info(match.group(1))
            logging.info(match.group(2))
            return f'{match.group(1)}_{match.group(2)}'
    raise Exception("no available BKC name")
