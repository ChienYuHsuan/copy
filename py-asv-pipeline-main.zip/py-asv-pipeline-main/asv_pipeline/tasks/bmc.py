import logging
import time

import pexpect
import tenacity

from asv_pipeline.util import DualLogger, ansi_escape, expect_handler, s2b


@tenacity.retry(stop=tenacity.stop_after_attempt(3),
                wait=tenacity.wait_exponential(min=1, max=30, multiplier=10), reraise=True)
def interact_sol_for_ip_loss(cluster, node, idsid=None):
    eb = expect_handler.ipmi(cluster, idsid)
    rst = None
    try:
        eb.send(f"""
ipmitool -I lanplus -C 17 -H {s2b(node, True)} -U debuguser -P 0penBmc1 sol set enabled true
ipmitool -I lanplus -C 17 -H {s2b(node, True)} -U debuguser -P 0penBmc1 sol deactivate
ipmitool -I lanplus -C 17 -H {s2b(node, True)} -U debuguser -P 0penBmc1 sol activate
""")
        eb.timeout = 25
        rst = eb.expect(
            ['SOL Session operational', 'SOL payload already active on another session'])
        if rst == 1:
            raise Exception("SOL payload already active on another session")
        time.sleep(3)
        # make sure SOL has been responded
        for i in range(3):
            eb.sendline("")
        time.sleep(2)
        try:
            eb.expect('login:', timeout=15)
            eb.sendline('root')
            time.sleep(2)
            eb.expect('[Pp]assword:')
            eb.sendline('c1oudc0w')
            time.sleep(2)
        except pexpect.TIMEOUT:
            ...
        logger = DualLogger()
        eb.logfile_read = logger
        # Use a logfile to capture all output
        eb.sendline('ip a;echo ">>>>>"')
        time.sleep(5)
        eb.expect("ip a.*\r\n")
        time.sleep(5)
        eb.expect(">>>>>")
        # Combine all captured output
        full_output = ''.join(logger.logs)
        logging.debug(full_output)
        # Extract the relevant portion
        result = full_output.split('ip a;echo ">>>>>"')[-1].split(">>>>>")[0].strip()
        rst = result
        logging.debug(rst)
    finally:
        eb.send('~.')
        eb.close()
        eb = expect_handler.ipmi(cluster, idsid)
        eb.send(
            f'ipmitool -I lanplus -C 17 -H {s2b(node, True)} -U debuguser -P 0penBmc1 sol deactivate'
        )
    return rst


def get_debug_cpld(cluster, node, idsid=None):
    """
    using ethtool to check the interface
    """
    eb = expect_handler.bastion(cluster, idsid)
    # eb.expect(r'\[root@.*')
    eb.send(f"""
curl -s -k -H "Authorization:Basic ZGVidWd1c2VyOjBwZW5CbWMx" https://{s2b(node)}.deacluster.intel.com/redfish/v1/UpdateService/FirmwareInventory/DEBUG_cpld | python3 -c 'import sys, json; print(json.load(sys.stdin).get("Version"))'
""")
    eb.expect(r'\.get\("Version"\)\)\'')
    eb.expect(f'{idsid}@')
    rst = ansi_escape(eb.before)
    logging.debug(rst)

    return rst


def get_cpu_cpld(cluster, node, idsid=None):
    """
    using ethtool to check the interface
    """
    eb = expect_handler.bastion(cluster, idsid)
    # eb.expect(r'\[root@.*')
    s2b(node)
    eb.send(f"""
curl -s -k -H "Authorization:Basic ZGVidWd1c2VyOjBwZW5CbWMx" https://{s2b(node)}.deacluster.intel.com/redfish/v1/UpdateService/FirmwareInventory/CPU_cpld | python3 -c 'import sys, json; print(json.load(sys.stdin).get("Version"))'
""")
    eb.expect(r'\.get\("Version"\)\)\'')
    eb.expect(f'{idsid}@')
    rst = ansi_escape(eb.before)
    logging.debug(rst)

    return rst


def get_scm_cpld(cluster, node, idsid=None):
    """
    using ethtool to check the interface
    """
    eb = expect_handler.bastion(cluster, idsid)
    # eb.expect(r'\[root@.*')
    s2b(node)
    eb.send(f"""
curl -s -k -H "Authorization:Basic ZGVidWd1c2VyOjBwZW5CbWMx" https://{s2b(node)}.deacluster.intel.com/redfish/v1/UpdateService/FirmwareInventory/SCM_cpld | python3 -c 'import sys, json; print(json.load(sys.stdin).get("Version"))'
""")
    eb.expect(r'\.get\("Version"\)\)\'')
    eb.expect(f'{idsid}@')
    rst = ansi_escape(eb.before)
    logging.debug(rst)

    return rst


def get_pfr_cpld(cluster, node, idsid=None):
    """
    using ethtool to check the interface
    """
    eb = expect_handler.bastion(cluster, idsid)
    # eb.expect(r'\[root@.*')
    s2b(node)
    eb.send(f"""
curl -s -k -H "Authorization:Basic ZGVidWd1c2VyOjBwZW5CbWMx" https://{s2b(node)}.deacluster.intel.com/redfish/v1/UpdateService/FirmwareInventory/cpld_active | python3 -c 'import sys, json; print(json.load(sys.stdin).get("Version"))'
""")
    eb.expect(r'\.get\("Version"\)\)\'')
    eb.expect(f'{idsid}@')
    rst = ansi_escape(eb.before)
    logging.debug(rst)

    return rst


def get_dimm0_dimm1(cluster, node, idsid=None):
    eb = expect_handler.bastion(cluster, idsid)
    s2b(node)
    eb.send(f"""
curl -s -k -H "Authorization:Basic ZGVidWd1c2VyOjBwZW5CbWMx" https://{s2b(node)}.deacluster.intel.com/redfish/v1/Systems/system/Memory/dimm0 | python3 -c 'import sys, json; print(json.load(sys.stdin))'
""")
    eb.expect(r"sys.stdin\)\)'")
    eb.expect(f'{idsid}@')
    dimm0 = ansi_escape(eb.before)

    eb.send(f"""
curl -s -k -H "Authorization:Basic ZGVidWd1c2VyOjBwZW5CbWMx" https://{s2b(node)}.deacluster.intel.com/redfish/v1/Systems/system/Memory/dimm1 | python3 -c 'import sys, json; print(json.load(sys.stdin))'
""")
    eb.expect(r"sys.stdin\)\)'")
    eb.expect(f'{idsid}@')
    dimm1 = ansi_escape(eb.before)

    eb.sendline('exit')
    eb.expect('logout')
    eb.sendcontrol('D')
    eb.expect([pexpect.EOF, r'closed'])

    logging.debug(dimm0)
    logging.debug(dimm1)

    return dimm0, dimm1


def transfer_i2c(cluster, node, idsid=None):
    b_node = s2b(node)
    ctx = f"Will login to {node}'s bmc endpoint{b_node}"
    logging.info(ctx)
    eb = expect_handler.bmc(cluster, b_node, idsid)
    eb.sendline("i2ctransfer -y 10 w2@0x51 0x40 0x1c r4 w2 0x00 0x08 r4;echo '>>>>>'")
    eb.expect("i2ctransfer -y 10.*\r\n")
    eb.expect(">>>>>")
    rst = eb.before
    logging.info(rst)
    return rst
