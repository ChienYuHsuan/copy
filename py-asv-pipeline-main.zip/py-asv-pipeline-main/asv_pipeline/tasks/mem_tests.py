import logging
import os
import sys
from datetime import datetime, timezone

import requests

import asv_pipeline.clusterscope.handler as handler
import asv_pipeline.config as cfg
from asv_pipeline.es import ES
from asv_pipeline.util import change_time_format, get_cluster_by_naming

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)


def query_amt(cluster, rst, idx):
    log.info("Start querying AMT results")
    res_amt = {}
    test_type = [
        'TestType 1 Latency', 'TestType 4 Latency', 'TestType 5 Latency', 'TestType 7 Latency',
        'TestType 11 Latency', 'TestType 12 Latency', 'TestType 13 Latency', 'TestType 14 Latency',
        'TestType 15 Latency', 'TestType 18 Latency', 'TestType 19 Latency', 'Failure detected'
    ]
    match_phase = {
        'TestType 1 Latency': 1,
        'TestType 4 Latency': 1,
        'TestType 5 Latency': 1,
        'TestType 7 Latency': 1,
        'TestType 11 Latency': 1,
        'TestType 12 Latency': 1,
        'TestType 13 Latency': 1,
        'TestType 14 Latency': 1,
        'TestType 15 Latency': 1,
        'TestType 18 Latency': 1,
        'TestType 19 Latency': 1
    }
    nodes = list(rst.keys())
    start, end = datetime.now(), datetime.now()
    try:
        start = datetime.strptime(change_time_format(os.environ['START']),
                                  '%a %d %b %Y %I:%M:%S %p %Z')
        end = datetime.strptime(change_time_format(os.environ['END']), '%a %d %b %Y %I:%M:%S %p %Z')
    except Exception as e:
        log.error(str(e))
    log.info("[AMT] start: %s, end: %s" % (start, end))

    try:
        es = ES(url=cfg.es_endpoints[cluster], name=cfg.es_username[cluster],
                password=cfg.es_password[cluster]).index(idx)
    except Exception as e:
        log.error(str(e))
        sys.exit(1)

    for node in nodes:
        match_phase = dict.fromkeys(match_phase, 1)
        body = es.oneOf('message', test_type).IS('host', node).range(start, end).build()
        inner_data = {'results': 'NA'}
        try:
            docs = es.execute(timeout=600, payload=body)
        except Exception as e:
            log.error(str(e))
            continue

        for doc in docs:
            s = doc['_source']['message']
            log.debug("Node: %s, messag: %s" % (node, s))
            if 'Failure detected' in s:
                log.info("Node: %s, messag: %s" % (node, s))
                inner_data['results'] = s
                break
            # Complete message is like 'TestType 19 Latency = 14 sec'. We'd like to get TestType 19 Latency'
            msg = " ".join(s.split(" ")[:3])
            if msg in test_type:
                match_phase[msg] = 0

        res_amt[node] = inner_data
        count = sum(match_phase.values())
        if node in res_amt and 'Failure detected' in res_amt[node]['results']:
            pass
        elif count == 0:  # Exact one count for each TestType
            res_amt[node]['results'] = 'Pass'
        elif count == 11:  # No data for any TestType
            res_amt[node]['results'] = 'No Data'
        else:  # Partial TestType appear
            missed_types = [k for k in match_phase.keys() if match_phase[k] == 1]
            res = []
            for t in missed_types:
                s = t.split()
                for c in s:
                    if c.isdigit():
                        res.append(c)
            res_amt[node]['results'] = 'Failed. Missing types: ' + ', '.join(res)

    log.info("res_amt: %s", res_amt)
    return res_amt


def query_rmt(cluster, rst):
    log.info("Start querying RMT results")
    res_rmt = {}
    nodes = list(rst.keys())
    rmt_version = 'NA'
    start, end = datetime.now(), datetime.now()
    try:
        start = datetime.strptime(change_time_format(os.environ['START']),
                                  '%a %d %b %Y %I:%M:%S %p %Z')
        end = datetime.strptime(change_time_format(os.environ['END']), '%a %d %b %Y %I:%M:%S %p %Z')
    except Exception as e:
        log.error(str(e))
    log.info("[RMT] start: %s, end: %s" % (start, end))

    cpu = ''
    if nodes:
        res = handler.get_cpu(nodes)
        cpu = res[nodes[0]]

    try:
        if cpu == 'SRF-AP' or cpu == 'SRF-SP':
            es = ES(url=cfg.es_endpoints['flex'], name=cfg.es_username['flex'],
                    password=cfg.es_password['flex']).index("qpool")
        else:
            es = ES(url=cfg.es_endpoints[cluster], name=cfg.es_username[cluster],
                    password=cfg.es_password[cluster]).index("qpool")
    except Exception as e:
        log.error(str(e))
        sys.exit(1)

    if nodes:
        try:
            body = es.IS('kubernetes.host',
                         nodes[0]).IS('kubernetes.container_name',
                                      'memory-offset-training-margin').oneOf(
                                          'log',
                                          ['test-start-indicator', 'test-end-indicator']).range(
                                              start, end, timestamp="@timestamp").build()
            docs = es.execute(timeout=600, payload=body)
        except Exception as e:
            log.error(str(e))
        if docs:
            rmt_version = docs[0]['_source']['kubernetes']['container_image']
            log.info("rmt_version %s" % rmt_version)

    try:
        if cpu == 'SRF-AP' or cpu == 'SRF-SP':
            es = ES(url=cfg.es_endpoints[cluster], name=cfg.es_username[cluster],
                    password=cfg.es_password[cluster]).index("margin-tags")
        else:
            es.index("margin-tags")
    except Exception as e:
        log.error(str(e))
        sys.exit(1)

    for node in nodes:
        body = es.IS('Hostname', node).range(start, end, timestamp="Timestamp").build()
        count = 0
        inner_data = {'status': '-', 'version': rmt_version}
        try:
            docs = es.execute(timeout=600, payload=body)
        except Exception as e:
            log.error(str(e))
            continue

        for doc in docs:
            s = doc['_source'].get('Status', 'Unknown')
            log.debug("Node: %s, status: %s" % (node, s))

            if s == 'Fail':
                inner_data['status'] = s
                break
            elif s == 'Warning' or s == 'Unknown':
                inner_data['status'] = s
            else:
                count += 1

        res_rmt[node] = inner_data

        if node in res_rmt and (res_rmt[node]['status'] == 'Fail' or res_rmt[node]['status']
                                == 'Warning' or res_rmt[node]['status'] == 'Unknown'):
            pass
        elif count >= 15:
            res_rmt[node]['status'] = 'Pass (%i)' % count
        elif count == 0:
            res_rmt[node]['status'] = 'No Data'
        else:
            res_rmt[node]['status'] = 'Incomplete (%i)' % count

    log.debug("res_rmt: %s" % res_rmt)
    return res_rmt


def query_os_margin(rst):
    log.info("Start querying OS margin results")
    res_os = {}
    nodes = list(rst.keys())
    start, end = datetime.now(), datetime.now()
    try:
        start = datetime.strptime(change_time_format(os.environ['START']),
                                  '%a %d %b %Y %I:%M:%S %p %Z')
        end = datetime.strptime(change_time_format(os.environ['END']), '%a %d %b %Y %I:%M:%S %p %Z')
    except Exception as e:
        log.error(str(e))
    log.info("[OMT] start: %s, end: %s" % (start, end))

    try:
        es = ES(url=cfg.es_endpoints['jf'], name=cfg.es_username['jf'],
                password=cfg.es_password['jf']).index("uram-")
    except Exception as e:
        log.error(str(e))
        sys.exit(1)

    for node in nodes:
        body = es.IS('host',
                     node).IS('metadata.test.name',
                              'jasper-mlc-margin').range(start, end,
                                                         timestamp="timestamp_start").build()
        count = 0
        min_avg = 1000
        sum_avg = 0
        inner_data = {
            'channels': 0,
            'cores': 0,
            'controllers': 0,
            'slots': 0,
            'sockets': 0,
            'runs': 0,
            'throughput': 'N/A',
            'results': []
        }

        cluster = ''
        try:
            cluster = get_cluster_by_naming(node)
        except Exception as e:
            log.error(str(e))

        try:
            docs = es.execute(timeout=600, payload=body)
        except Exception as e:
            log.error(str(e))
            res_os[node] = inner_data
            continue

        if not docs:
            log.warning('Node %s is not in uram index yet.' % node)
            inner_data['results'].append('N/A in uram index')
            res_os[node] = inner_data
            continue

        log.info("[OMT] %s jasper-mlc-margin counts: %d" % (node, len(docs)))
        for doc in docs:
            count += 1
            '''
            There is no 'populated_memory_channels' in BHS platform so we use 'ddr_populated_memory_controllers' and
            'ddr_populated_memory_slots' instead.
            '''
            if cluster == 'bhs' or cluster == 'srf':
                log.info("Collect DIMM info for BHS platform %s" % cluster)
                inner_data['controllers'] = doc['_source']['oob_metadata'].get(
                    'ddr_populated_memory_controllers', 0)
                inner_data['slots'] = doc['_source']['oob_metadata'].get(
                    'ddr_populated_memory_slots', 0)
                inner_data['sockets'] = doc['_source']['oob_metadata'].get(
                    'ddr_populated_sockets', 0)
                inner_data['cores'] = doc['_source']['oob_metadata'].get('cpu0_cores', 0)

                population = doc['_source']['oob_metadata'].get('ddr_population', '')

                if "GNR-AP" in doc['_source']['cpu_model'] or "SRF-AP" in doc['_source'][
                        'cpu_model']:
                    if (inner_data['sockets'] == 2 and inner_data['controllers'] != 24 and inner_data['slots'] != 24) or \
                            (inner_data['sockets'] == 1 and inner_data['controllers'] != 12 and inner_data['slots'] != 12):
                        log.warning('Node %s has unexpected memory slots %d' %
                                    (node, inner_data['slots']))
                        if all('slot #' not in s for s in inner_data['results']):
                            inner_data['results'].append('Fail (Unexpected slot # %s)' %
                                                         inner_data['slots'])
                elif "GNR-SP" in doc['_source']['cpu_model'] or "SRF-SP" in doc['_source'][
                        'cpu_model']:
                    if (inner_data['sockets'] == 2 and population == '2DPC' and inner_data['controllers'] != 16 and inner_data['slots'] != 32) or \
                            (inner_data['sockets'] == 2 and population == '1DPC' and inner_data['controllers'] != 16 and inner_data['slots'] != 16) or \
                            (inner_data['sockets'] == 1 and population == '2DPC' and inner_data['controllers'] != 8 and inner_data['slots'] != 16) or \
                            (inner_data['sockets'] == 1 and population == '1DPC' and inner_data['controllers'] != 8 and inner_data['slots'] != 8):
                        log.warning('Node %s has unexpected memory slots %d' %
                                    (node, inner_data['slots']))
                        if all('slot #' not in s for s in inner_data['results']):
                            inner_data['results'].append('Fail (Unexpected slot # %s)' %
                                                         inner_data['slots'])
                elif "Unknown" in doc['_source']['cpu_model']:
                    log.warning('Node %s has unknown CPU model' % node)
                    if all('Unknown CPU model' not in s for s in inner_data['results']):
                        inner_data['results'].append('Unknown CPU model')
            else:
                log.info("Collect DIMM info for non-BHS platform %s" % cluster)
                channels = doc['_source']['memory'].get('populated_memory_channels', 0)
                inner_data['controllers'] = doc['_source']['memory'].get(
                    'populated_memory_controllers', 0)
                inner_data['sockets'] = doc['_source']['memory'].get('populated_sockets', 0)
                inner_data['channels'] = channels
                inner_data['cores'] = doc['_source'].get('cpu_cores', 0)

                if channels != 8 and channels != 16:
                    log.warning('Node %s has unexpected memory channel %d' % (node, channels))
                    if all('channel #' not in s for s in inner_data['results']):
                        inner_data['results'].append('Fail (channel # %s)' % channels)

            sum_avg += doc['_source']['memory'].get('ddr_throughput_total_gbps_avg', 0)
            min_avg = min(min_avg, doc['_source']['memory'].get('ddr_throughput_total_gbps_avg',
                                                                1000))
            ddr_error = doc['_source']['memory'].get('ddr_errors', 0)
            if ddr_error > 0:
                log.warning('Node %s has DDR error' % node)
                if all('DDR error' not in s for s in inner_data['results']):
                    inner_data['results'].append('Fail (DDR error %d)' % ddr_error)

            transient_error = doc['_source']['memory'].get('ddr_transient_errors', 0)
            if transient_error > 0:
                log.warning('Node %s has DDR transient error' % node)
                if all('Transient error' not in s for s in inner_data['results']):
                    inner_data['results'].append('Fail (Transient error %d)' % transient_error)

        inner_data['runs'] = count
        if count != 0:
            inner_data['throughput'] = 'Avg: %.3f, Min: %.3f' % (sum_avg / count, min_avg)
            if sum_avg / count == 0:
                inner_data['results'].append('Fail (Bandwidth avg is 0)')
        if count != 9:
            inner_data['results'].append('Incomplete (%d)' % count)
        if not inner_data['results']:
            inner_data['results'].append('Pass')
        res_os[node] = inner_data

    log.debug("res_os: %s" % res_os)
    return res_os


def get_rmt_test_period(node, jk_link, start, end):
    log.info("Start querying RMT test period for node %s" % node)

    try:
        es = ES(url=cfg.es_endpoints['zp31'], name=cfg.es_username['zp31'],
                password=cfg.es_password['zp31']).index("burnin_status_k8s")
    except Exception as e:
        log.error(str(e))
        sys.exit(0)

    body = es.IS('host', node).oneOf('test', ['RMT', 'Memory-margin']).notIS('test', 'knobs').IS(
        'JenkinsLink', jk_link).range(start, end, timestamp="starttime").build()

    try:
        docs = es.execute(timeout=600, payload=body)
    except Exception as e:
        log.error(str(e))
        sys.exit(0)

    if not docs:
        log.warning("No RMT results found for node %s in period %s - %s" % (node, start, end))

    rmt_start, rmt_end = '1970-01-01T00:00:00.000000', '1970-01-01T00:00:00.000000'
    for doc in docs:
        _start, _end = doc['_source'].get('starttime',
                                          'Unknown'), doc['_source'].get('endtime', 'Unknown')

        # Update the earliest rmt_start and latest rmt_end variables if applicable
        if _start != 'Unknown' and (rmt_start == '1970-01-01T00:00:00.000000' or
                                    _start < rmt_start):
            rmt_start = _start

        if _end != 'Unknown' and (rmt_end == '1970-01-01T00:00:00.000000' or _end > rmt_end):
            rmt_end = _end

    log.info("RMT test time - Start: %s, End: %s" % (rmt_start, rmt_end))
    try:
        rmt_start = datetime.strptime(rmt_start, '%Y-%m-%dT%H:%M:%S.%f')
        rmt_end = datetime.strptime(rmt_end, '%Y-%m-%dT%H:%M:%S.%f')
        rmt_start = int(rmt_start.replace(tzinfo=timezone.utc).timestamp() * 1000)
        rmt_end = int(rmt_end.replace(tzinfo=timezone.utc).timestamp() * 1000)
    except Exception as e:
        log.error(str(e))

    return rmt_start, rmt_end


def query_dimm_info(rst):
    dimm_info = {}
    nodes = list(rst.keys())

    default_inner_data = {
        'manufacturer': '-',
        'manufacture_date': '-',
        'dpc': '-',
        'speed': 0,
        'capacity': 0,
        'density': 'N/A',
        'type': 'N/A',
        'raw_card': 'N/A'
    }

    headers = {'Content-Type': 'application/json', 'X-Api-Key': cfg.at_api_key}

    for node in nodes:
        inner_data = default_inner_data.copy()

        try:
            response = requests.get(cfg.dimm_info_url % node, headers=headers, verify=False)
            response.raise_for_status()
            log.info('Get DIMM info successfully')
            response_json = response.json()
            log.info(response_json)

            # Update inner_data with response data
            for key in inner_data.keys():
                if key in response_json:
                    inner_data[key] = response_json[key]
        except requests.exceptions.RequestException as e:
            log.error('Request failed: %s', e)

        dimm_info[node] = inner_data

    return dimm_info
