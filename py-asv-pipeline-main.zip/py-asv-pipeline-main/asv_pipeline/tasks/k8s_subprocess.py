import asv_pipeline.config as cfg
from asv_pipeline.k8s import Kubernetes, Node, Pod
from asv_pipeline.util import str2labels


def extract_k8s_nodes(**kwargs):
    """
    Extract the k8s nodes in particular cluster with labels
            
    :param str cluster: option [opus,flex,icx-1..]
    :return: dict [nodename, node __dict__]
    :raises Exception: if the cluster doesn't exist
    """
    cluster = kwargs.get('params').get('cluster', None)
    if not cluster:
        raise Exception("failing task becuase there's no designate cluster")

    c = Kubernetes()
    GET_NODES_WITH_NOREADY = "kubectl --kubeconfig=%(kube)s --insecure-skip-tls-verify get nodes --show-labels"
    rst = c.cmd(GET_NODES_WITH_NOREADY % {'kube': cfg.kubeconfigs[cluster]})

    mp = {}
    for li in rst[1:]:
        A = li.split()
        node = Node(A[0], A[1], A[3], str2labels(A[5]))
        mp[node.name] = node.__dict__
    return mp
    # kwargs['ti'].xcom_push(key='k8s.nodes', value=mp)


def extract_k8s_pods(**kwargs):
    """
    Extract the k8s pods in particular cluster with labels
    The pods running on the infra namespaces are omitting, such as mgmt and monitor

    :param str cluster: option [opus,flex,icx-1..]
    :return: dict [nodename,pod.__dict__]
    :raises Exception: if the cluster doesn't exist
    """
    cluster = kwargs.get('params').get('cluster', None)
    if not cluster:
        raise Exception("failing task becuase there's no designate cluster")

    c = Kubernetes()
    GET_PODS = "kubectl --kubeconfig=%(kube)s --insecure-skip-tls-verify get pod -A -owide"
    rst = c.cmd(GET_PODS % {'kube': cfg.kubeconfigs[cluster]})

    mp = {}
    for x in rst[1:]:
        A = x.split()
        pod = Pod(A[1], A[0], A[5], A[3], A[6], A[7])
        if pod.ns in ["monitoring", "mgmt"]:
            continue
        """
        check if pod.name contains killer_pod, we need to consider the life span.
        otherwise, we take the node into account immediately.
        """
        if pod.ns not in mp:
            mp[pod.ns] = []
        mp[pod.ns] += [pod.__dict__]
    return mp
    # kwargs['ti'].xcom_push(key='k8s.pods', value=mp)
