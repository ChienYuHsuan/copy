import logging
import time
from datetime import datetime

import pandas as pd
import pexpect

import asv_pipeline.clusterscope.handler as cs_handler
from asv_pipeline.jr import JiraFactory as jiraFactory
from asv_pipeline.sharepoint.check_dpmo import check_dpmo, filter_node_by_poolname, update_poolname
from asv_pipeline.tasks.clusterscope import get_cpu
from asv_pipeline.tasks.os import get_cvl_cards, isDIMMSamsung5600
from asv_pipeline.tasks.xmlcli import progknobs, readknobs
from asv_pipeline.util import expect_handler, get_ww_tpe


def cycle_launcher(cluster, node, idsid=None, params=None):
    cpu = cs_handler.get_cpu([node])[node]
    sysman = expect_handler.sysman(cluster, idsid, cpu)
    sysman.timeout = 300
    sysman.expect(r'\w+@\w+(:~)?')

    bkc_name = params['bkc_name']
    validation_type = params['validation_type']
    cycle_type = params['cycle_type']
    iteration = params['iteration']
    ignore_devices = params['ignore_devices']

    if ignore_devices:
        sysman.sendline(
            f'bkc_name={bkc_name} ignore_devices="y" bash /var/local/cluster-execution/cycle-tests/cycle_launcher.sh {cycle_type} {validation_type} {iteration} -M "{node}"'
        )
    else:
        sysman.sendline(
            f'bkc_name={bkc_name} bash /var/local/cluster-execution/cycle-tests/cycle_launcher.sh {cycle_type} {validation_type} {iteration} -M "{node}"'
        )
    time.sleep(15)
    # sysman.expect(r"debug0{1,}1:")
    sysman.expect(r'\w+@\w+(:~)?')

    rst = sysman.before
    logging.info(rst)
    sysman.sendcontrol('D')
    sysman.sendline("exit")
    sysman.expect([pexpect.EOF, r'closed', r'logout', r'\w+@\w+(:~)?'])
    return rst


def check_knob_bifurcation(cluster, sut, idsid=None, timeout=(180, 2)):
    try:
        qsfp_result, qsfp_width_result, slotDetails = get_cvl_cards(cluster, sut, idsid, timeout)
        if slotDetails:
            knobs = ','.join(slotDetails.values())
            return readknobs(cluster, sut, idsid, knobs)
        else:
            logging.info("sut do not need set bifurcation, Passed")
            return True
    except Exception as e:
        logging.error(str(e))
        return False


def check_knob_dimm_samsung5600(cluster, sut, idsid=None, timeout=(180, 2)):
    try:
        if isDIMMSamsung5600(cluster, sut, idsid, timeout):
            knobs = "HostDdrFreqLimit=8"
            return readknobs(cluster, sut, idsid, knobs)
        else:
            logging.info("sut do not need set dimmSamsung5600, Passed")
            return True
    except Exception as e:
        logging.error(str(e))
        return False


def update_knob_bifurcation(cluster, sut, idsid=None, timeout=(180, 2), dry_run=False) -> object:
    try:
        qsfp_result, qsfp_width_result, slotDetails = get_cvl_cards(cluster, sut, idsid, timeout)
        if slotDetails:
            knobs = ','.join(slotDetails.values())
            if dry_run:
                return knobs
            progknobs(cluster, sut, idsid, knobs, False)
        return True
    except Exception as e:
        logging.error(str(e))
        return False


def update_knob_dimm_samsung5600(cluster, sut, idsid, dry_run=False) -> object:
    knobs = "HostDdrFreqLimit=8"
    if dry_run:
        return knobs
    try:
        progknobs(cluster, sut, idsid, knobs, False)
        return True
    except Exception as e:
        logging.error(str(e))
        return False


def get_dpmo_list(cpu, hour, min):
    logging.info("Start checking DPMO results for %s" % cpu.upper())
    res_dpmo = check_dpmo(hour, min)

    _nodes = res_dpmo.keys()
    if res_dpmo and _nodes:
        res, _ = cs_handler.get_pool_by_nodes(_nodes)
        filter_node_by_poolname(res_dpmo, res)
        update_poolname(res_dpmo, res, cpu)

    # Convert the dictionary to a pandas DataFrame
    df = pd.DataFrame.from_dict(res_dpmo, orient='index')

    if cpu == 'srf':
        cpu = 'srf-sp'

    # Group the data by the 'cpu' field
    res_by_group = {}
    try:
        grouped = df.groupby('cpu', group_keys=True)
        group = grouped.get_group(cpu.upper())
        res_by_group = group.to_dict(orient='index')

        logging.info("CPU: %s" % cpu)
        logging.info("res_by_group %s" % res_by_group)

    except Exception as e:
        logging.warning("Issue happens during group data: %s" % str(e))

    return res_by_group


def create_dpmo_jira_summary(cpu, cycle_type, hosts, bkc_name):
    weekday = datetime.utcnow().isoweekday()
    ww = get_ww_tpe() + '.' + str(weekday)
    cycle_type_simple = cycle_type.split("_")[0]
    summary = f'[Cluster][{cpu}][DPMO][{bkc_name}] {cycle_type_simple} Cycles Reset [{ww}] - {len(hosts)} node'
    return summary


def create_dpmo_jira_description(cycle_type, iterations, hosts, bkc_name, ignore_devices=False,
                                 set_tdx_knobs=False, check_tdx=False, bios_check_once=False,
                                 unlock=False, bios_knobs=None):
    des = ''

    # Add sections to the description
    des += '*EXECUTION_TYPE\ncycle_test\n'
    des += f'*CYCLE_TYPE\n{cycle_type}\n'
    des += '*VALIDATION_TYPE\nOS_validation\n'
    des += f'*ITERATIONS\n{iterations}\n'
    des += '*HOSTNAMES\n'
    for host in hosts:
        des += f'{host}\n'
    des += f'*BKC_NAME\n{bkc_name}\n'

    if bios_knobs is not None:
        des += '*BIOS_KNOBS\n'
        des += bios_knobs + '\n'

    if bios_check_once:
        des += '*BIOS_CHECK_ONCE\n'
        des += 'y\n'

    if check_tdx:
        des += '*HALT_NO_TDX\n'
        des += 'y\n'

    if ignore_devices:
        des += '*IGNORE_DEVICES\n'
        des += 'y\n'

    if set_tdx_knobs:
        des += '*INSTALL_TDX\n'
        des += 'y\n'

    if unlock:
        des += '*UNLOCK\n'

    return des


def create_dpmo_jira(hosts, cycle_type, iterations, bkc_name, ignore_devices=False,
                     set_tdx_knobs=False, check_tdx=False, bios_check_once=False, unlock=False,
                     bios_knobs=None):
    try:
        cpu = get_cpu([hosts[0]])[hosts[0]]
    except Exception as e:
        logging.error(e)
        raise Exception(f'[Nonexecution]Node {hosts[0]} fails to get CPU type in ClusterScope')

    jira_summary = create_dpmo_jira_summary(cpu, cycle_type, hosts, bkc_name)
    jira_description = create_dpmo_jira_description(cycle_type, iterations, hosts, bkc_name,
                                                    ignore_devices=ignore_devices,
                                                    set_tdx_knobs=set_tdx_knobs,
                                                    check_tdx=check_tdx,
                                                    bios_check_once=bios_check_once, unlock=unlock,
                                                    bios_knobs=bios_knobs)

    logging.info("jira_summary: %s" % jira_summary)
    logging.info("jira_description: %s" % jira_description)

    project_key = "ICED"
    jira = jiraFactory()
    new_issue = jira.create_issue(project_key=project_key, summary=jira_summary,
                                  description=jira_description)

    logging.info(f"Issue {new_issue.key} created successfully.")

    return new_issue
