import logging
from datetime import datetime

from asv_pipeline.util import expect_handler


def create_xmlcli_log(cluster, idsid, cpu):
    eb = expect_handler.sysman(cluster, idsid, cpu)
    formatted_date = datetime.now().strftime("%Y-%d-%m")
    logging.info(formatted_date)
    eb.sendline(f'touch /tmp/XmlCliOut/log/XmlCli_{formatted_date}_linux_py3.8.log')
    eb.expect(r'\w+@\w+[:~]')
    eb.sendline(f'chmod 666 /tmp/XmlCliOut/log/XmlCli_{formatted_date}_linux_py3.8.log')
    eb.expect(r'\w+@\w+[:~]')
