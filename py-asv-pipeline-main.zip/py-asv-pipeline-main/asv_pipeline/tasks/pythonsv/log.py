import logging

import pexpect

from asv_pipeline.util import expect_handler


def rotate(cluster, idsid, cpu=None, retention=3):
    eh = expect_handler.sysman(cluster, idsid, cpu)
    eh.sendline('cd ~/')
    eh.send(f"""
find ASD_connections -mtime +{retention} -print0 | xargs -0 rm -rf; \
find .OpenIPC -mtime +{retention} -print0 | xargs -0 rm -rf; \
find .cache/ -mtime +{retention} -print0 | xargs -0 rm -rf; \
find .LanternRock/ -mtime +{retention} -print0 | xargs -0 rm -rf; \
find pythonsv/log -mtime +{retention} -print0 | xargs -0 rm -rf; echo ">>>>>"
""")
    eh.expect(' pythonsv/log .*\r\n')
    eh.expect(['>>>>>', 'No such file or directory', pexpect.EOF])
    logging.debug(eh.before)
    eh.sendcontrol('D')
    eh.expect([pexpect.EOF, r'closed'])
    return True
