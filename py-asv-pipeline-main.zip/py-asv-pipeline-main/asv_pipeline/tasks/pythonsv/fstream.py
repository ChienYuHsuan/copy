import datetime
import logging
import os

import tenacity

import asv_pipeline.config as cfg
from asv_pipeline.sharepoint import SharePointFactory
from asv_pipeline.util import get_ww_tpe

if "ScaleInternalCluster" in cfg.sp_site:
    FOLDER = "Shared Documents/PythonSV Auto Collection"
else:
    FOLDER = "Shared Documents/PythonSV"


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def stream_upload(node: str, ctx: str):

    logging.info("start to upload the file to sharepoint")
    dt = datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
    file = None
    try:
        ww = get_ww_tpe()
        # using txt extension helps us open file in SharePoint directly
        filename = f'{node}_{dt}.txt'

        cwd = os.getcwd()
        file = os.path.join(cwd, filename)

        with open(file, 'w') as f:
            f.write(ctx)
            logging.info(f'{filename} is created in {ww}')

        if not os.path.isfile(file):
            raise Exception("file is not ready")
        sp = SharePointFactory.build()
        sp.mkdir(f'{FOLDER}/{ww}')
        sp.upload(file, f'{FOLDER}/{ww}')
        target = f"/{'/'.join(cfg.sp_site.split('/')[-2:])}/{FOLDER}/{ww}/{filename}"

        shared_link = sp.get_shared_link(target)
        logging.debug(f"We get the shared_link for {filename} in SharePoint : {shared_link}")
        return shared_link, target

    except Exception as e:
        logging.error(e)

    finally:
        os.remove(file)
