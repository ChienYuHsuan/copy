import logging
import re

import pexpect

import asv_pipeline.rf.handler as rh
from asv_pipeline.clusterscope.handler import get_state, get_stepping
from asv_pipeline.tasks.bmc import interact_sol_for_ip_loss, transfer_i2c
from asv_pipeline.tasks.clusterscope import get_cpu
from asv_pipeline.tasks.elasticsearch import es_eventlog, es_sol
from asv_pipeline.tasks.os import pingable
from asv_pipeline.tasks.pythonsv import (cwf_mca_error, gnr_mca_error, spr_hbm_mca_error,
                                         spr_xcc_mca_error, srf_ap_mca_error, srf_mca_error, unlock)
from asv_pipeline.tasks.pythonsv.fstream import stream_upload


def _append_i2c(outstream, cluster, node, idsid):
    rst = f'''{">" * 36}
$  i2ctransfer -y 10 w2@0x51 0x40 0x1c r4 w2 0x00 0x08 r4
'''
    try:
        rst += f'{transfer_i2c(cluster, node, idsid=idsid)}\n'
        rst += f'{">" * 36}\n'
    except Exception as e:
        logging.error(e)
        return outstream
    return rst if not outstream else outstream + rst


def collect_mca_error(cluster, node, idsid=None, range=(12, 0)):
    outstream = None
    cache = None
    psv = None
    try:
        try:
            cpu = get_cpu([node], cache)[node]
        except Exception as e:
            logging.error(e)
            logging.error(cache)
            raise Exception(f'[Nonexecution]Node {node} fails to get CPU type in ClusterScope')
        target = node
        # if re.search(r'EMR', cpu):
        #     target += '.EMR'
        # elif re.search(r'CWF', cpu):
        #     target += ".CWF"
        # elif re.search(r'GNR', cpu):
        #     target += '.GNR'
        # elif re.search(r'SRF', cpu):
        #     target += '.SRF'
        # elif re.search(r'SPR', cpu):
        #     target += '.SPR'

        if pingable(cluster, node, idsid):
            raise Exception(f'[Nonexecution]Node {node} is pingable')

        is_power_on = rh.is_power_state(node)
        has_critical_event = es_eventlog.check_critical_event(cluster, node, range=range)
        is_ip_loss = False
        try:
            output_ip_loss = interact_sol_for_ip_loss(cluster, node, idsid=idsid)
            logging.info(f'{node} is ip loss')
            logging.info(output_ip_loss)
            is_ip_loss = True
        except pexpect.exceptions.TIMEOUT:
            logging.error(f'{node} is inactive')

        if not has_critical_event and (is_ip_loss or not is_power_on):
            raise Exception(
                f'[Nonexecution]Node {node} has no critical events, and is {"alive" if is_power_on else "power-off"}'
            )
        # 25.5.7 @nelson, substitue with new mechanism to make sure system alive.
        # if not has_critical_event and (
        #     (es_sol.check_heartbeat(cluster, node) or es_qpool.check_heart_beat(cluster, node)) or
        #         not is_power_on):
        #     raise Exception(
        #         f'[Nonexecution]Node {node} has no critical events, and is {"alive" if is_power_on else "power-off"}'
        #     )

        # 25.3.13 finish
        # 7.10 @nelson
        # Because we cannot tell whether it is running AMT, if there's no critical, we won't go
        # if re.search(r'GNR', cpu) and not has_critical_event:
        #     raise Exception(f'[Nonexecution]Node {node} has no critical event')

        # 25.3.13 @nelson
        # Since we cannot tell if the system is healthy when it runs AMT, we hand over the decision to the user
        try:
            if es_sol.is_amt_test(cluster, node,
                                  range=(12, 0)) and not has_critical_event and is_power_on:
                raise Exception(f'[Nonexecution]Node {node} is running AMT test')
        except Exception as e:
            if "is running AMT" in str(e):
                logging.error(str(e))
                raise

        # 25.5.7 @nelson, substitue with new mechanism to make sure system alive
        # 7.24 @nelson, changing order makes more reasonable
        # if not has_critical_event and is_power_on and not es_sol.validate_sol_index(cluster, node):
        #     raise Exception(
        #         f"[Nonexecution]{node}: no critical event; SOL heartbeat unclear, no ElasticSearch data then."
        #     )

        try:
            state = get_state([node], cache)[node]
        except Exception as e:
            logging.error(str(e))
            raise Exception(
                f'[Nonexecution]Node {node} fails to get PoolName State in ClusterScope')

        if state != 'NTR':
            raise Exception(f'[Nonexecution]Node {node} is not NTR state')

        try:
            stepping = get_stepping([node], cache)[node]
        except Exception as e:
            logging.error(str(e))
            raise Exception(
                f'[Nonexecution]Node {node} fails to get PoolName Stepping in ClusterScope')

        outstream = _append_i2c('', cluster, node, idsid)
        try:
            if re.search(r'SRF-SP', cpu):
                psv = unlock(cluster, target, idsid=idsid, close_required=False)
                psv.eb.timeout = 600  # for overall timeout, we define particular CMD in srf_mca_error for 3600*6, and giving 300 seconds to close the sessions
                outstream += srf_mca_error(cluster, target, idsid=idsid, pythonsv=psv)
            elif re.search(r'SRF-AP', cpu):
                outstream += srf_ap_mca_error(cluster, target, idsid=idsid)
            elif re.search(r'SPR', cpu) and re.search(r'HBM', stepping):
                outstream += spr_hbm_mca_error(cluster, target, idsid=idsid)
            elif re.search(r'SPR', cpu):
                outstream += spr_xcc_mca_error(cluster, target, idsid=idsid)
            elif re.search(r'CWF', cpu):
                outstream += cwf_mca_error(cluster, target, idsid=idsid)
            else:
                psv = unlock(cluster, target, idsid=idsid, close_required=False)
                psv.eb.timeout = 600  # for overall timeout, we define particular CMD in srf_mca_error for 3600*6, and giving 300 seconds to close the sessions
                outstream += gnr_mca_error(cluster, target, idsid=idsid, pythonsv=psv)
            outstream = _append_i2c(outstream, cluster, node, idsid)
            rst, relative = stream_upload(node, outstream)
        except pexpect.TIMEOUT:
            if psv:
                psv.eb.timeout = 600
                outstream += psv.terminate()
            outstream = _append_i2c(outstream, cluster, node, idsid)
            rst, relative = stream_upload(node, outstream)
            return (node, f'[timeout]{rst}', relative)
        logging.debug(rst)
        logging.debug(relative)
        return (node, rst, relative)
    except Exception as e:
        if "terminate the IPC but fail" in str(e):
            if outstream:
                rst, relative = stream_upload(node, outstream)
                return (node, f'[fail to terminate]{rst}', relative)
            else:
                logging.info("nothing left")
        logging.error(e)
        if "pexpect.exceptions.TIMEOUT" in str(e):
            raise Exception(f'[timeout]{node} fails to initiate PythonSV')
        if "End Of File (EOF)" in str(e):
            raise Exception(f'[EOF]{node} fails to initiate PythonSV')
        raise


collect_srf_mca_error = collect_mca_error
