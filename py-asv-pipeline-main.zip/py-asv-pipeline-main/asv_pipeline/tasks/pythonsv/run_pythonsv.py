import argparse
import logging

import pexpect

from asv_pipeline.pythonsv import PythonSV
from asv_pipeline.tasks.clusterscope import get_cpu
from asv_pipeline.tasks.pythonsv import pythonsv_cmds
from asv_pipeline.tasks.pythonsv.fstream import stream_upload
from asv_pipeline.tasks.pythonsv.not_ready import _append_i2c

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)


def get_psv_cmd(filename):
    with open(filename, "r") as file:
        lines = [line.strip() for line in file]

    return lines


def run_pythonsv_cmds(cluster, node, cmds, idsid=None):
    outstream = None
    cache = None
    psv = None
    try:
        try:
            cpu = get_cpu([node], cache)[node]
            logging.info(cpu)
        except Exception as e:
            logging.error(e)
            logging.error(cache)
            raise Exception(f'[Nonexecution]Node {node} fails to get CPU type in ClusterScope')
        target = node
        # if re.search(r'EMR', cpu):
        #     target += '.EMR'
        # elif re.search(r'GNR', cpu):
        #     target += '.GNR'
        # elif re.search(r'SRF', cpu):
        #     target += '.SRF'
        # elif re.search(r'SPR', cpu):
        #     target += '.SPR'

        outstream = _append_i2c('', cluster, node, idsid)
        try:
            # psv = unlock(cluster, target, idsid=idsid, close_required=False)
            psv = PythonSV(cluster, idsid=idsid, cpu=cpu).target(node, timeout=3600)
            psv.eb.timeout = 600
            outstream += pythonsv_cmds(cluster, target, idsid=idsid, pythonsv=psv, cmds=cmds)
            outstream = _append_i2c(outstream, cluster, node, idsid)
            # rst, relative = stream_upload(node, outstream)
            logging.info(f"Output of PythonSV commands: {outstream}")
        except pexpect.TIMEOUT:
            if psv:
                psv.eb.timeout = 600
                outstream += psv.terminate()
            outstream = _append_i2c(outstream, cluster, node, idsid)
            rst, relative = stream_upload(node, outstream)
    except Exception as e:
        logging.error(e)
        if "pexpect.exceptions.TIMEOUT" in str(e):
            raise Exception(f'[timeout]{node} fails to initiate PythonSV')
        raise


if __name__ == "__main__":

    log.info("Start running PythonSV commands")
    parser = argparse.ArgumentParser("Start running PythonSV commands")
    # cmds = "itp.unlock()\nsv.sockets.uncore.ms2idi0.snc_config"
    # run_pythonsv_cmds('zp31', 'zp3110a001s1119', args.cmd, idsid='sys_asvauto')
    parser.add_argument("-c", "--cluster", required=True, help="Cluster name")
    parser.add_argument("-n", "--node", required=True, help="Node name")
    parser.add_argument("-p", "--psv", required=True, help="PythonSV commands")
    args = parser.parse_args()

    if args.psv:
        psv_cmds = get_psv_cmd(args.psv)
        log.info("PythonSV commands:")
        log.info(psv_cmds)

    run_pythonsv_cmds(args.cluster, args.node, "\n".join(psv_cmds), idsid='sys_asvauto')
