import logging
import re

import pexpect

from asv_pipeline.clusterscope.handler import get_stepping
from asv_pipeline.tasks.clusterscope import get_cpu
from asv_pipeline.tasks.pythonsv import (gnr_mca_error, gnr_mem_error, spr_hbm_mca_error,
                                         spr_xcc_mca_error, srf_ap_mca_error, srf_mca_error, unlock,
                                         unlock_test)
from asv_pipeline.tasks.pythonsv.fstream import stream_upload
from asv_pipeline.tasks.pythonsv.not_ready import _append_i2c
from asv_pipeline.tasks.pythonsv.util import create_xmlcli_log


def collect_error(cluster, node, idsid=None):
    outstream = None
    cache = None
    psv = None
    try:
        try:
            cpu = get_cpu([node], cache)[node]
        except Exception as e:
            logging.error(e)
            logging.error(cache)
            raise Exception(f'[Nonexecution]Node {node} fails to get CPU type in ClusterScope')
        target = node
        # if re.search(r'EMR', cpu):
        #     target += '.EMR'
        # elif re.search(r'GNR', cpu):
        #     target += '.GNR'
        # elif re.search(r'SRF', cpu):
        #     target += '.SRF'
        # elif re.search(r'SPR', cpu):
        #     target += '.SPR'

        try:
            stepping = get_stepping([node], cache)[node]
        except Exception as e:
            logging.error(str(e))
            raise Exception(
                f'[Nonexecution]Node {node} fails to get PoolName Stepping in ClusterScope')

        outstream = _append_i2c('', cluster, node, idsid)
        try:
            if re.search(r'SRF-SP', cpu):
                psv = unlock(cluster, target, idsid=idsid, close_required=False)
                psv.eb.timeout = 600  # for overall timeout, we define particular CMD in srf_mca_error for 3600*6, and giving 300 seconds to close the sessions
                outstream += srf_mca_error(cluster, target, idsid=idsid, pythonsv=psv)
            elif re.search(r'SRF-AP', cpu):
                outstream += srf_ap_mca_error(cluster, target, idsid=idsid)
            elif re.search(r'SPR', cpu) and re.search(r'HBM', stepping):
                outstream += spr_hbm_mca_error(cluster, target, idsid=idsid)
            elif re.search(r'SPR', cpu):
                outstream += spr_xcc_mca_error(cluster, target, idsid=idsid)
            else:
                psv = unlock(cluster, target, idsid=idsid, close_required=False)
                psv.eb.timeout = 600  # for overall timeout, we define particular CMD in srf_mca_error for 3600*6, and giving 300 seconds to close the sessions
                outstream += gnr_mca_error(cluster, target, idsid=idsid, pythonsv=psv)
            outstream = _append_i2c(outstream, cluster, node, idsid)
            rst, relative = stream_upload(node, outstream)
        except pexpect.TIMEOUT:
            if psv:
                psv.eb.timeout = 600
                outstream += psv.terminate()
            outstream = _append_i2c(outstream, cluster, node, idsid)
            rst, relative = stream_upload(node, outstream)
            return (node, f'[timeout]{rst}', relative)
        logging.debug(rst)
        logging.debug(relative)
        return (node, rst, relative)
    except Exception as e:
        if "terminate the IPC but fail" in str(e):
            if outstream:
                rst, relative = stream_upload(node, outstream)
                return (node, f'[fail to terminate]{rst}', relative)
            else:
                logging.info("nothing left")
        logging.error(e)
        if "pexpect.exceptions.TIMEOUT" in str(e):
            raise Exception(f'[timeout]{node} fails to initiate PythonSV')
        raise


def collect_mem_error(cluster, node, idsid=None, enable_status_scope=True):
    outstream = None
    cache = None
    psv = None
    try:
        try:
            cpu = get_cpu([node], cache)[node]
        except Exception as e:
            logging.error(e)
            logging.error(cache)
            raise Exception(f'[Nonexecution]Node {node} fails to get CPU type in ClusterScope')
        target = node
        # if re.search(r'EMR', cpu):
        #     target += '.EMR'
        # elif re.search(r'GNR', cpu):
        #     target += '.GNR'
        # elif re.search(r'SRF', cpu):
        #     target += '.SRF'
        # elif re.search(r'SPR', cpu):
        #     target += '.SPR'
        '''
        Workaround for error when running PythonSV commands:
        PermissionError: [Errno 13] Permission denied: '/tmp/XmlCliOut/log/XmlCli_2025-19-02_linux_py3.8.log'
        '''
        create_xmlcli_log(cluster, idsid, cpu)

        outstream = _append_i2c('', cluster, node, idsid)
        try:
            if re.search(r'GNR', cpu):
                psv = unlock_test(cluster, target, idsid=idsid, close_required=False)
                psv.eb.timeout = 600
                outstream += gnr_mem_error(cluster, target, idsid=idsid, pythonsv=psv,
                                           enable_status_scope=enable_status_scope)
            outstream = _append_i2c(outstream, cluster, node, idsid)
            rst, relative = stream_upload(node, outstream)
        except pexpect.TIMEOUT:
            if psv:
                psv.eb.timeout = 600
                outstream += psv.terminate()
            outstream = _append_i2c(outstream, cluster, node, idsid)
            rst, relative = stream_upload(node, outstream)
            return (node, f'[timeout]{rst}', relative)
        logging.debug(rst)
        logging.debug(relative)
        return (node, rst, relative)
    except Exception as e:
        if "terminate the IPC but fail" in str(e):
            if outstream:
                rst, relative = stream_upload(node, outstream)
                return (node, f'[fail to terminate]{rst}', relative)
            else:
                logging.info("nothing left")
        logging.error(e)
        if "pexpect.exceptions.TIMEOUT" in str(e):
            raise Exception(f'[timeout]{node} fails to initiate PythonSV')
        raise
