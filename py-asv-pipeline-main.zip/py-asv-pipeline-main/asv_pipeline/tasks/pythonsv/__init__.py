import logging
import os
import re
import sys
import warnings
from datetime import datetime

import pexpect

from asv_pipeline.pythonsv import PythonSV

sys.path.insert(1, os.path.abspath('.'))
warnings.filterwarnings("ignore", category=DeprecationWarning)


def unlock(cluster, node, idsid=None, close_required=True, pythonsv=None, timeout=3600):
    """
    unlock command to the node in particular k8s cluster through PythonSV
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :return
    """
    logging.info(f"start to do unlock on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target(node, timeout=timeout)
    pythonsv.series([
        ["unlock()", ['>>>.*\r\n'], [r"'unlock' is not defined", pexpect.TIMEOUT]],
        ["sv.refresh()", ['>>>.*\r\n'], [r"name 'sv' is not defined", pexpect.TIMEOUT]],
    ])
    if close_required:
        return pythonsv.close()
    else:
        return pythonsv


def unlock_test(cluster, node, idsid=None, close_required=True, pythonsv=None, timeout=3600):
    """
    unlock command to the node in particular k8s cluster through PythonSV
    launch_remote_ipc_test -M <node>
    :param str cluster: option [opus,flex,icx-1..]
    :param str node   : the node name; the node need to be labelled.
    :return
    """
    logging.info(f"start to do unlock on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target_test(node, timeout=timeout)
    pythonsv.series([
        ["unlock()", ['>>>.*\r\n'], [r"'unlock' is not defined", pexpect.TIMEOUT]],
        ["sv.refresh()", ['>>>.*\r\n'], [r"name 'sv' is not defined", pexpect.TIMEOUT]],
    ])
    if close_required:
        return pythonsv.close()
    else:
        return pythonsv


def any_instructions(cluster, node, instructions, idsid=None, close_required=True, pythonsv=None,
                     timeout=3600 * 12):
    """
    Execute arbitrary instructions on a node in a particular k8s cluster through PythonSV
    :param str cluster: option [opus,flex,icx-1..]
    :param str node: the node name; the node needs to be labelled
    :param str idsid: user identifier (optional)
    :param bool close_required: whether to close the connection after execution (default: True)
    :param pythonsv: existing PythonSV instance (optional)
    :param int timeout: timeout for the operation in seconds (default: 3600 * 12)
    :return: result of pythonsv.close() if close_required is True, otherwise the pythonsv instance
    """
    logging.info(f"start to do instructions on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target_test(node, timeout=timeout)
    # pythonsv.series([
    #     [f"{instructions}", ['>>>'], ["'.*' is not defined", pexpect.TIMEOUT]],
    # ])
    pythonsv.series([
        [f"{instructions}", ['>>>'], [pexpect.EOF, pexpect.TIMEOUT]],
    ])
    if close_required:
        return pythonsv.close()
    else:
        return pythonsv


def check_stepping_qdf(cluster, node, idsid=None, pythonsv=None):
    logging.info(f"start to check stepping and QDF on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target(node)
    out = pythonsv.series(
        [["""
import toolext.bootscript.toolbox.fuse_utility as fu
fu.print_fuse_rev()
"""]]).close()
    logging.debug(out)
    rst = {}
    for line in re.split(r'\r?\n', out):
        if re.search(r'(?:compute|TILE)\d+\s+', line):
            sections = line.split(',')
            CPU = re.search(r'(?:compute|TILE)(\d+)\s+(\w+\s*\w+)', sections[0]).groups()
            QDF = re.search(r'QDF: (\w+)', sections[1]).group(1)
            logging.debug((CPU, QDF))
            rst[CPU[0]] = [CPU[1], QDF]
    logging.info(rst)
    return rst


def cwf_mca_error(cluster, node, idsid=None, close_required=True, pythonsv=None, timeout=3600 * 5):
    logging.info(f"start to collect cwf-ap mca error on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target(node)
    pythonsv.series([[
        """
itp.forcereconfig()
itp.unlock()
sv.refresh()

##QDF
import toolext.bootscript.toolbox.fuse_utility as fu
fu.print_fuse_rev

## MCA Dump:

import clearwaterforest.ras.ras_master.mca_master as m
m.mca.errordump()

## Ubox dump:
import pysvtools.server_ip_debug as sid
sid.ubox.watch_windows.mca_error_source.show(source="reg")

## Axon logs:
from clearwaterforest.toolext import status_scope
status_scope.run(collectors=['namednodes'],analyzers=['auto'])
                      
        """, [">>>"],
        [
            'System is not out of reset. Cdie is not available',
            'Failed to found any CLTAP in OpenIPC'
        ]
    ]])

    logging.info("cwf mca error complete collection")
    if close_required:
        pythonsv.eb.timeout = timeout
        return pythonsv.close()
    else:
        return pythonsv


def deprecate_cwf_mca_error(cluster, node, idsid=None, close_required=True, pythonsv=None,
                            timeout=3600 * 5):
    logging.info(f"start to collect cwf mca error on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target(node)
    pythonsv.series([[
        """
#unlock cpu
unlock()
sv.refresh()

##Ucode version:
itp.threads[0].crb(894)
sv.socket0.io0.uncore.s3m.showsearch('manifest')

##PPIN Number
sv.sockets.io0.fuses.go_online()
ppin_s0 =hex(sv.sockets.io0.fuses.dfxagg.uniqueid_fuse.get_value()[0])
ppin_s1 =hex(sv.sockets.io0.fuses.dfxagg.uniqueid_fuse.get_value()[1])
ppin_s0
ppin_s1

##QDF
import toolext.bootscript.toolbox.fuse_utility as fu
fu.print_fuse_rev


#Python postcode
sv.socket0.io0.uncore.ubox.ncdecs.biosnonstickyscratchpad7_cfg
sv.socket0.io0.uncore.ubox.ncdecs.biosnonstickyscratchpad8_cfg
 
#MCAs
sv.sockets.computes.cpu.cores.ml2_cr_mc3_status
 
#ubox & MCAs
from pysvtools.server_ip_debug.ubox import ubox
ubox.Ubox().show_ww('MCA', source='reg')
ubox.Ubox().show_mca_status(source='reg')
import pm.pmdebug as pmdebug
from pysvtools import server_ip_debug
server_ip_debug.punit.errors.show_mca_status()
import core.debug as cd
cd.mca_dump_gnr()
 
#CHA errors
from pysvtools import server_ip_debug
server_ip_debug.cha.errors.show_mca_status()
 
#Dispatcher
import pysvtools.server_ip_debug as sip
sip.punit.errors.show_mca_status()
sip.punit.watch_windows.punit_dispatcher.show(source='reg')
 
#UPI errors 
from pysvtools.server_ip_debug.upi import upi 
upi.Upi().show_mca_status(source='reg') 
upi.Upi().show_ww('Port Status', source='reg') 
import upi.upiStatus as us 
us.main("--all")
 
 
#memory Errors
import clearwaterforest.mc.gnrAddressTranslator as at
at.show_dimm_config()
import clearwaterforest.mc.gnrMcUtils as mu 
mu.show_memory_errors()

#PCIe Errors
sls()
import clearwaterforest.ras.ras_master.ieh_master as im
im.ieh.errordump()

#PMSB
sv.sockets.ios.taps.iow_glbw_is3m_ibl_top110.showsearch("fw_status");
sv.sockets.ios.taps.iow_glbw_is3m_ibl_top110.showsearch("err")

die=sv.socket0.compute0
for i in die.taps.search("fsa_np_counter_ovf_undf",'f'):
    if die.taps.get_by_path(i).read() != 0:
      print (f'{i}: {die.taps.get_by_path(i).read()}')


die=sv.socket0.compute1
for i in die.taps.search("fsa_np_counter_ovf_undf",'f'):
    if die.taps.get_by_path(i).read() != 0:
      print (f'{i}: {die.taps.get_by_path(i).read()}')

      

die=sv.socket0.compute2
for i in die.taps.search("fsa_np_counter_ovf_undf",'f'):
    if die.taps.get_by_path(i).read() != 0:
      print (f'{i}: {die.taps.get_by_path(i).read()}')

      

die=sv.socket1.compute0
for i in die.taps.search("fsa_np_counter_ovf_undf",'f'):
    if die.taps.get_by_path(i).read() != 0:
      print (f'{i}: {die.taps.get_by_path(i).read()}')

      

die=sv.socket1.compute1
for i in die.taps.search("fsa_np_counter_ovf_undf",'f'):
    if die.taps.get_by_path(i).read() != 0:
      print (f'{i}: {die.taps.get_by_path(i).read()}')

      

die=sv.socket1.compute2
for i in die.taps.search("fsa_np_counter_ovf_undf",'f'):
    if die.taps.get_by_path(i).read() != 0:
      print (f'{i}: {die.taps.get_by_path(i).read()}')

      

# Status_Scope
from clearwaterforest.toolext import status_scope 
status_scope.run(collectors=['namednodes'], analyzers=["auto"])

        """, [">>>"], ['System is not out of reset. Cdie is not available']
    ]], timeout=timeout)
    logging.info("cwf mca error complete collection")
    if close_required:
        pythonsv.eb.timeout = timeout
        return pythonsv.close()
    else:
        return pythonsv


def gnr_mca_error(cluster, node, idsid=None, close_required=True, pythonsv=None, timeout=3600 * 5):
    logging.info(f"start to collect gnr mca error on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target(node)
    pythonsv.series(
        [[
            #         """
            # #unlock cpu
            # # unlock()
            # # sv.refresh()
            # import time
            # start_time = time.time()

            # #Postcode
            # # you have to connect to the BMC
            # i2ctransfer -y 10 w2@0x51 0x40 0x1c r4 w2 0x00 0x08 r4
            # print("--- i2ctransfer %s seconds ---" % (time.time() - start_time))

            # #Python postcode
            # start_time = time.time()
            # sv.socket0.io0.uncore.ubox.ncdecs.biosnonstickyscratchpad7_cfg
            # print("--- biosnonstickyscratchpad7_cfg %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()
            # sv.socket0.io0.uncore.ubox.ncdecs.biosnonstickyscratchpad8_cfg
            # print("--- biosnonstickyscratchpad8_cfg %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()
            # #MCAs
            # sv.sockets.computes.cpu.cores.ml2_cr_mc3_status
            # print("--- ml2_cr_mc3_status %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()
            # #ubox & MCAs
            # from pysvtools.server_ip_debug.ubox import ubox
            # ubox.Ubox().show_ww('MCA', source='reg')
            # print("--- Ubox().show_ww('MCA', source='reg') %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()

            # ubox.Ubox().show_mca_status(source='reg')
            # print("--- Ubox().show_mca_status %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()

            # import pm.pmdebug as pmdebug
            # from pysvtools import server_ip_debug
            # server_ip_debug.punit.errors.show_mca_status()
            # print("--- punit.errors.show_mca_status %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()
            # import core.debug as cd
            # cd.mca_dump_gnr()
            # print("--- mca_dump_gnr %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()
            # #CHA errors
            # from pysvtools import server_ip_debug
            # server_ip_debug.cha.errors.show_mca_status()
            # print("--- cha.errors.show_mca_status() %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()

            # #Dispatcher
            # import pysvtools.server_ip_debug as sip
            # sip.punit.errors.show_mca_status()
            # print("--- punit.errors.show_mca_status() %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()
            # sip.punit.watch_windows.punit_dispatcher.show(source='reg')
            # print("--- punit_dispatcher.show(source='reg') %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()
            # #UPI errors
            # from pysvtools.server_ip_debug.upi import upi
            # upi.Upi().show_mca_status(source='reg')
            # print("--- Upi().show_mca_status %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()
            # upi.Upi().show_ww('Port Status', source='reg')
            # print("--- .Upi().show_ww %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()
            # import upi.upiStatus as us
            # us.main("--all")
            # print("--- us.main('--all') %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()

            # #memory Errors
            # import graniterapids.mc.gnrMcUtils as mu
            # mu.show_memory_errors()
            # print("--- mu.show_memory_errors() %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()
            # sls()
            # print("--- sls () %s seconds ---" % (time.time() - start_time))
            # start_time = time.time()
            # print('done')"""
            """
#unlock cpu
# unlock()
# sv.refresh()

##Ucode version:
itp.threads[0].crb(894)
sv.socket0.io0.uncore.s3m.showsearch('manifest')

##PPIN Number
sv.sockets.io0.fuses.go_online()
ppin_s0 =hex(sv.sockets.io0.fuses.dfxagg.uniqueid_fuse.get_value()[0])
ppin_s1 =hex(sv.sockets.io0.fuses.dfxagg.uniqueid_fuse.get_value()[1])
ppin_s0
ppin_s1

##QDF
import toolext.bootscript.toolbox.fuse_utility as fu
fu.print_fuse_rev


#Python postcode
sv.socket0.io0.uncore.ubox.ncdecs.biosnonstickyscratchpad7_cfg
sv.socket0.io0.uncore.ubox.ncdecs.biosnonstickyscratchpad8_cfg
 
import graniterapids.mc.gnrMcUtils as mu 
mu.show_errors()
#MCAs
sv.sockets.computes.cpu.cores.ml2_cr_mc3_status
 
#ubox & MCAs
from pysvtools.server_ip_debug.ubox import ubox
ubox.Ubox().show_ww('MCA', source='reg')
ubox.Ubox().show_mca_status(source='reg')
import pm.pmdebug as pmdebug
from pysvtools import server_ip_debug
server_ip_debug.punit.errors.show_mca_status()
import core.debug as cd
cd.mca_dump_gnr()
 
#CHA errors
from pysvtools import server_ip_debug
server_ip_debug.cha.errors.show_mca_status()
 
#Dispatcher
import pysvtools.server_ip_debug as sip
sip.punit.errors.show_mca_status()
sip.punit.watch_windows.punit_dispatcher.show(source='reg')
 
#UPI errors 
from pysvtools.server_ip_debug.upi import upi 
upi.Upi().show_mca_status(source='reg') 
upi.Upi().show_ww('Port Status', source='reg') 
import upi.upiStatus as us 
us.main("--all")
 
 
#memory Errors
import graniterapids.mc.gnrAddressTranslator as at
at.show_dimm_config()
import graniterapids.mc.gnrMcUtils as mu 
mu.show_memory_errors()

#PCIe Errors
sls()
import graniterapids.ras.ras_master.ieh_master as im
im.ieh.errordump()

#PMSB
sv.sockets.ios.taps.iow_glbw_is3m_ibl_top110.showsearch("fw_status");
sv.sockets.ios.taps.iow_glbw_is3m_ibl_top110.showsearch("err")

die=sv.socket0.compute0
for i in die.taps.search("fsa_np_counter_ovf_undf",'f'):
    if die.taps.get_by_path(i).read() != 0:
      print (f'{i}: {die.taps.get_by_path(i).read()}')

      

die=sv.socket0.compute1
for i in die.taps.search("fsa_np_counter_ovf_undf",'f'):
    if die.taps.get_by_path(i).read() != 0:
      print (f'{i}: {die.taps.get_by_path(i).read()}')

      

die=sv.socket0.compute2
for i in die.taps.search("fsa_np_counter_ovf_undf",'f'):
    if die.taps.get_by_path(i).read() != 0:
      print (f'{i}: {die.taps.get_by_path(i).read()}')

      

die=sv.socket1.compute0
for i in die.taps.search("fsa_np_counter_ovf_undf",'f'):
    if die.taps.get_by_path(i).read() != 0:
      print (f'{i}: {die.taps.get_by_path(i).read()}')

      

die=sv.socket1.compute1
for i in die.taps.search("fsa_np_counter_ovf_undf",'f'):
    if die.taps.get_by_path(i).read() != 0:
      print (f'{i}: {die.taps.get_by_path(i).read()}')

      

die=sv.socket1.compute2
for i in die.taps.search("fsa_np_counter_ovf_undf",'f'):
    if die.taps.get_by_path(i).read() != 0:
      print (f'{i}: {die.taps.get_by_path(i).read()}')

      

# Status_Scope
from graniterapids.toolext import status_scope 
status_scope.run(collectors=['namednodes','m2iosf'], skip_login=True)
# status_scope.run(collectors=['namednodes'], analyzers=["auto"])
""",
            [">>>"],
            [
                'System is not out of reset. Cdie is not available',
                'Failed to found any CLTAP in OpenIPC'
            ]
        ]],
        timeout=timeout)
    logging.info("gnr mca error complete collection")
    if close_required:
        pythonsv.eb.timeout = timeout
        return pythonsv.close()
    else:
        return pythonsv


def srf_mca_error(cluster, node, idsid=None, close_required=True, pythonsv=None, timeout=3600 * 6):
    logging.info(f"start to collect srf mca error on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target(node)
    pythonsv.series([[
        """
from pysvtools.server_ip_debug.ubox import ubox
from pysvtools import server_ip_debug
from pysvtools.server_ip_debug.cha import cha
import upi.upiStatus as us
from pysvtools.server_ip_debug.soc import mca_decode

## Core strike Counter ####
sv.sockets.computes.cpu.modules.bbl_cr_mci_status
 
### S3M error ###
sv.sockets.computes.uncore.s3m.uarch.ibl_apb_treg.s3m_err_sts.show()
sv.sockets.ios.uncore.s3m.uarch.ibl_apb_treg.s3m_err_sts.show()
sv.sockets.ios.uncore.isclk.nsscpll_pllcore.ro_bwm_lf.pllunlock_flag_cri

#### MCEs, IERRs, pcode errors ####
sv.sockets.io0.uncore.ubox.ncevents.mcerrloggingreg.show()
sv.sockets.io0.uncore.ubox.ncevents.ierrloggingreg.show()
sv.socket0.ios.uncore.punit.ptpcfsms.ptpcfsms.mc_status.show()
sv.socket1.ios.uncore.punit.ptpcfsms.ptpcfsms.mc_status.show()
sv.socket0.computes.uncore.punit.ptpcfsms.ptpcfsms.mc_status.show()
sv.socket1.computes.uncore.punit.ptpcfsms.ptpcfsms.mc_status.show()
from pysvtools.server_ip_debug.soc import mca_decode
mca_decode.show_all()
##### ubox #####
from pysvtools.server_ip_debug.ubox import ubox
ubox.Ubox().show_ww('MCA', source='reg')
ubox.Ubox().show_mca_status(source='reg')
ubox.Ubox().show_ww('MCA Error',source='reg')

#### CHA issues ####
from pysvtools import server_ip_debug
server_ip_debug.cha.errors.show_mca_status()

##### MDF ####
server_ip_debug.mdf.errors.show_mca_status()
sv.sockets.io0.uncore.hwrs.gpsb.poc_straps.show()
sv.sockets.io0.uncore.ubox.ncevents.mcerrloggingreg.show()
sv.sockets.io0.uncore.ubox.ncevents.ierrloggingreg.show()

from pysvtools import server_ip_debug
server_ip_debug.punit.errors.show_mca_status()

sls()

import sierraforest
import upi.upiStatus as us
us.printMisc()
us.printErrors()

##### Atom Core ####
import sierraforest.security
from atomcore.crestmont import atomdebug
atomdebug.load_scripts()
atomdebug.machine_check.mcdump()

#### Uncore MCA #####
from pysvtools.server_ip_debug.cha import cha
cha.Cha().show_ww('TOR')
import graniterapids.ras.ras_master.mca_master as mm
mm.mca.errordump()
from toolext.server_ip_debug.ubox import ubox as ubox
ubox.Ubox().show_ww('MCA', source='reg')

## All MCA ##
import graniterapids.ras.ras_master.mca_master as mm
mm.mca.mca_table()

sv.socket0.io0.uncore.ubox.ncdecs.biosnonstickyscratchpad7_cfg
sv.socket0.io0.uncore.ubox.ncdecs.biosnonstickyscratchpad8_cfg

## POST Code Checking##
#import graniterapids.core.debug as cd
#cd.get_post_code()

import graniterapids.mc.gnrMcUtils as mu
mu.show_memory_errors()

dimminfo()

import toolext.bootscript.toolbox.fuse_utility as fu
fu.print_fuse_rev

from sierraforest.toolext import status_scope
status_scope.run(collectors=['namednodes'], analyzers=["auto"])
""", [">>>"],
        [
            'System is not out of reset. Cdie is not available',
            'Failed to found any CLTAP in OpenIPC'
        ]
    ]], timeout=timeout)
    if close_required:
        pythonsv.eb.timeout = timeout
        return pythonsv.close()
    else:
        return pythonsv


def srf_ap_mca_error(cluster, node, idsid=None, close_required=True, pythonsv=None,
                     timeout=3600 * 6):
    logging.info(f"start to collect srf mca error on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target(node)
    pythonsv.series([[
        """
ipc.forcereconfig()
unlock()
sv.refresh
 
#Python postcode
sv.socket0.io0.uncore.ubox.ncdecs.biosnonstickyscratchpad7_cfg
sv.socket0.io0.uncore.ubox.ncdecs.biosnonstickyscratchpad8_cfg
 
#ULT
import toolext.bootscript.toolbox.fuse_utility as fu
fu.print_fuse_rev
 
#PPIN
sv.sockets.io0.fuses.go_online()
ppin_s0 =hex(sv.sockets.io0.fuses.dfxagg.uniqueid_fuse.get_value()[0])
ppin_s1 =hex(sv.sockets.io0.fuses.dfxagg.uniqueid_fuse.get_value()[1])
 
ppin_s0
ppin_s1
 
sv.sockets.io0.uncore.ubox.ncevents.ierrloggingreg.show()
sv.socket0.ios.uncore.punit.ptpcfsms.ptpcfsms.mc_status.show()
sv.socket1.ios.uncore.punit.ptpcfsms.ptpcfsms.mc_status.show()
sv.socket0.computes.uncore.punit.ptpcfsms.ptpcfsms.mc_status.show()
sv.socket1.computes.uncore.punit.ptpcfsms.ptpcfsms.mc_status.show()

 
##### ubox #####
 
from pysvtools.server_ip_debug.ubox import ubox
ubox.Ubox().show_ww('MCA', source='reg')
ubox.Ubox().show_mca_status(source='reg')
import pm.pmdebug as pmdebug
from pysvtools import server_ip_debug
server_ip_debug.punit.errors.show_mca_status()
 
 
####  Uncore MCA #####
 
from pysvtools.server_ip_debug.cha import cha
cha.Cha().show_ww('TOR')
import graniterapids.ras.ras_master.mca_master as mm
mm.mca.errordump()

 
#### MCEs, IERRs, pcode errors ####
sv.sockets.io0.uncore.ubox.ncevents.mcerrloggingreg.show()
 
#### CHA issues ####
from pysvtools import server_ip_debug
server_ip_debug.cha.errors.show_mca_status()
 
 
### Memory error dump ###
import graniterapids.mc.gnrMcUtils as mu
mu.show_memory_errors()
 
 
##### MDF ####
server_ip_debug.mdf.errors.show_mca_status()
 
sv.sockets.io0.uncore.hwrs.gpsb.poc_straps.show()
sv.sockets.io0.uncore.ubox.ncevents.mcerrloggingreg.show()
sv.sockets.io0.uncore.ubox.ncevents.ierrloggingreg.show()
 
 
from pysvtools import server_ip_debug
server_ip_debug.punit.errors.show_mca_status()
 
 
##### Atom Core ####
 
import sierraforest.security
from atomcore.crestmont import atomdebug
atomdebug.load_scripts()
atomdebug.machine_check.mcdump()
 
 
## Core strike Counter ####
sv.sockets.computes.cpu.modules.bbl_cr_mci_status
 
### S3M error ###
sv.sockets.computes.uncore.s3m.uarch.ibl_apb_treg.s3m_err_sts.show()
sv.sockets.ios.uncore.s3m.uarch.ibl_apb_treg.s3m_err_sts.show()
 
## IEH dump ##
 
import graniterapids.ras.ras_master.ieh_master as im
im.ieh.errordump()
 
 
#UPI errors 
from pysvtools.server_ip_debug.upi import upi 
upi.Upi().show_mca_status(source='reg') 
upi.Upi().show_ww('Port Status', source='reg') 
 
#UPI links
import upi.upiStatus as us 
us.main("--all")
 
sls()
# status scope #
import sierraforest.toolext.status_scope as ss
ss.run(collectors=['namednodes'],analyzers=[ 'ras', 'ubox','cha','cms','pcie','pm','sys_cfg','s3m','mcchnl','mem','upi','hiop','cxl'])

""", [">>>"],
        [
            'System is not out of reset. Cdie is not available',
            'Failed to found any CLTAP in OpenIPC'
        ]
    ]], timeout=timeout)
    if close_required:
        pythonsv.eb.timeout = timeout
        return pythonsv.close()
    else:
        return pythonsv


def spr_hbm_mca_error(cluster, node, idsid=None, close_required=True, pythonsv=None,
                      timeout=3600 * 6):
    logging.info(f"start to collect srf mca error on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target(node)
    pythonsv.series([[
        """
#unlock system
sv.refresh()
itp.unlock()
itp.forcereconfig()

#PCH
QDF = ''
for i in range(0,4):
    QDF = QDF + chr((sv.spch0.taps.dfx_secagg0.qdf.get_value() >> 24-i*8) & 0xFF)
    print("%s"%QDF)

    
#system hang is preamble 
sv.socket0.uncore.pcodeio_map.io_global_reset.show 
sv.socket0.taps.punit_ebc_d00.ebc_state_status.show() 
sv.socket0.pcudata.dfx_last_reset_item.show() 
sv.spch0.pmc.cmt.pps.show  

#Bootflow  
import emmitsburg.scripts.vt.pmc.pmc as pmc  
pmc.Sx_check()  
pmc.check_boot_flow()  

#Check if reset was performed 
sv.pch.spch0.pmc.mmr.gblrst_cause0.show()  
sv.pch.spch0.pmc.mmr.gblrst_cause1.show()  
sv.pch.spch0.pmc.mmr.hpr_cause0.show()  

#postcode 
sv.socket0.uncore.ubox.ncdecs.biosnonstickyscratchpad7_cfg 
sv.socket0.uncore.ubox.ncdecs.biosnonstickyscratchpad8_cfg 

#pcode error, if you see error here run tge punit commands. 
sv.socket0.uncore.pcodeio_map.io_firmware_mca_command.show 
sv.socket1.uncore.pcodeio_map.io_firmware_mca_command.show 

#MCEs, IERRs, pcode and Ubox general Errors 
from pysvtools.server_ip_debug.ubox import ubox 
ubox.Ubox().show_ww('MCA', source='reg') 
ubox.Ubox().show_mca_status(source='reg') 
sv.sockets.uncore.ubox.ncevents.mcerrloggingreg.show() 
sv.sockets.uncore.ubox.ncevents.ierrloggingreg.show() 
sv.socket0.uncore.punit.mc_status.show() 
sv.socket1.uncore.punit.mc_status.show() 

#CHA Erros
from pysvtools.server_ip_debug.cha import cha 
cha.Cha().show_mca_status(source='reg') 

#MDF parity Errors 
from pysvtools.server_ip_debug.mdf import mdf 
mdf.Mdf().show_mca_status(source='reg') 

#m2iosf Erros 
from pysvtools.server_ip_debug.m2iosf import m2iosf 
m2iosf.M2IOSF().show_mca_status(source='reg') 

#PM erros 
from pysvtools.server_ip_debug.pm import pm 
pm.PM().show_mca_status(source='reg') 

#core erros 
import sapphirerapids_hbm.core.debug as cd 
cd.mca_dump_spr()
cd.mca_decode_core_only()
cd.acode.acode_mca_analyze()

#memory Errors 
import sapphirerapids.mc.sprMcUtils as mu 
mu.show_memory_errors() 
mu.show_errors()

#UPI errors 
from pysvtools.server_ip_debug.upi import upi 
upi.Upi().show_mca_status(source='reg') 
upi.Upi().show_ww('Port Status', source='reg') 

#IEH, PCH, UBOX errors 
from pysvtools.fv_ras_debug.ieh_utils import ieh_tools as _ieh_tools 
_ieh_tools.dump_status() 

#UPI commands 
import upi.upiStatus as us 
us.main("--all") 

#DMI errors 
ltssm.checkForErrors(0,'dmi',clear=0) 
sv.socket0.uncore.pi5.pxp0.pcieg4.dmi.expptmbar.ltssmerrsts0.show 
sv.spch0.dmi.lsts.show() 
sv.spch0.dmi.ces.show() 

import pysvtools.pciedebug.ltssm as ltssm
ltssm.sls()
from sapphirerapids.mc.sprDimmInfo import dimminfo
dimminfo()

#STATUS SCOPE HBM
unlock()
sv.refresh()
from sapphirerapids_hbm.toolext import status_scope
status_scope.run(collectors=['namednodes'], analyzers=['cha', 'ubox', 'sys_cfg', 'upi'])

""", [">>>"], ['System is not out of reset. Cdie is not available']
    ]], timeout=timeout)
    if close_required:
        pythonsv.eb.timeout = timeout
        return pythonsv.close()
    else:
        return pythonsv


def spr_xcc_mca_error(cluster, node, idsid=None, close_required=True, pythonsv=None,
                      timeout=3600 * 6):
    logging.info(f"start to collect srf mca error on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target(node)
    pythonsv.series([[
        """
#unlock system
sv.refresh()
itp.unlock()
itp.forcereconfig()

#PCH
QDF = ''
for i in range(0,4):
    QDF = QDF + chr((sv.spch0.taps.dfx_secagg0.qdf.get_value() >> 24-i*8) & 0xFF)
    print("%s"%QDF)

    
#system hang is preamble 
sv.socket0.uncore.pcodeio_map.io_global_reset.show 
sv.socket0.taps.punit_ebc_d00.ebc_state_status.show() 
sv.socket0.pcudata.dfx_last_reset_item.show() 
sv.spch0.pmc.cmt.pps.show  

#Bootflow  
import emmitsburg.scripts.vt.pmc.pmc as pmc  
pmc.Sx_check()  
pmc.check_boot_flow()  

#Check if reset was performed 
sv.pch.spch0.pmc.mmr.gblrst_cause0.show()  
sv.pch.spch0.pmc.mmr.gblrst_cause1.show()  
sv.pch.spch0.pmc.mmr.hpr_cause0.show()  

#postcode 
sv.socket0.uncore.ubox.ncdecs.biosnonstickyscratchpad7_cfg 
sv.socket0.uncore.ubox.ncdecs.biosnonstickyscratchpad8_cfg 

#pcode error, if you see error here run tge punit commands. 
sv.socket0.uncore.pcodeio_map.io_firmware_mca_command.show 
sv.socket1.uncore.pcodeio_map.io_firmware_mca_command.show 

#MCEs, IERRs, pcode and Ubox general Errors 
from pysvtools.server_ip_debug.ubox import ubox 
ubox.Ubox().show_ww('MCA', source='reg') 
ubox.Ubox().show_mca_status(source='reg') 
sv.sockets.uncore.ubox.ncevents.mcerrloggingreg.show() 
sv.sockets.uncore.ubox.ncevents.ierrloggingreg.show() 
sv.socket0.uncore.punit.mc_status.show() 
sv.socket1.uncore.punit.mc_status.show() 

#CHA Erros
from pysvtools.server_ip_debug.cha import cha 
cha.Cha().show_mca_status(source='reg') 

#MDF parity Errors 
from pysvtools.server_ip_debug.mdf import mdf 
mdf.Mdf().show_mca_status(source='reg') 

#m2iosf Erros 
from pysvtools.server_ip_debug.m2iosf import m2iosf 
m2iosf.M2IOSF().show_mca_status(source='reg') 

#PM erros 
from pysvtools.server_ip_debug.pm import pm 
pm.PM().show_mca_status(source='reg') 

#core erros 
import sapphirerapids.core.debug as cd 
cd.mca_dump_spr() 
cd.mca_decode_core_only() #make sure pysv bigcore folder is fully updated 
cd.acode.acode_mca_analyze() 

#memory Errors 
import sapphirerapids.mc.sprMcUtils as mu 
mu.show_memory_errors() 
mu.show_errors()

#UPI errors 
from pysvtools.server_ip_debug.upi import upi 
upi.Upi().show_mca_status(source='reg') 
upi.Upi().show_ww('Port Status', source='reg') 

#IEH, PCH, UBOX errors 
from pysvtools.fv_ras_debug.ieh_utils import ieh_tools as _ieh_tools 
_ieh_tools.dump_status() 

#UPI commands 
import upi.upiStatus as us 
us.main("--all") 

#DMI errors 
ltssm.checkForErrors(0,'dmi',clear=0) 
sv.socket0.uncore.pi5.pxp0.pcieg4.dmi.expptmbar.ltssmerrsts0.show 
sv.spch0.dmi.lsts.show() 
sv.spch0.dmi.ces.show() 
ltssm.checkForErrors(0, 'dmi', clear=0) 
sls()
dimminfo()

#StatusScope
unlock()
sv.refresh()
from sapphirerapids.toolext import status_scope
status_scope.run(collectors=['namednodes'], analyzers=['cha', 'ubox', 'sys_cfg', 'upi'])
""", [">>>"], ['System is not out of reset. Cdie is not available']
    ]], timeout=timeout)
    if close_required:
        pythonsv.eb.timeout = timeout
        return pythonsv.close()
    else:
        return pythonsv


def pure_mca_error(cluster, node, idsid=None, close_required=True, pythonsv=None, timeout=3600 * 4):
    logging.info(f"start to collect  generic mca on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target(node)
    pythonsv.series([[
        """
from pysvtools.server_ip_debug.ubox import ubox
from pysvtools import server_ip_debug
from pysvtools.server_ip_debug.cha import cha
import upi.upiStatus as us
         
halt()
ubox.Ubox().show_mca_status(source='reg')
ubox.Ubox().show_ww('MCA Error',source='reg')
ubox.Ubox().show_ww('MCA', source='reg')
cha.Cha().show_ww('TOR')
                  
server_ip_debug.cha.errors.show_mca_status()
server_ip_debug.mdf.errors.show_mca_status()

sv.sockets.io0.uncore.hwrs.gpsb.poc_straps.show()
sv.sockets.io0.uncore.ubox.ncevents.mcerrloggingreg.show()
sv.sockets.io0.uncore.ubox.ncevents.ierrloggingreg.show()
server_ip_debug.punit.errors.show_mca_status()

sls()
us.printMisc()
us.printErrors()

dimminfo()
go()
""", [">>> halt", ">>>"], ['System is not out of reset. Cdie is not available']
    ]], timeout=timeout)
    if close_required:
        pythonsv.eb.timeout = timeout
        return pythonsv.close()
    else:
        return pythonsv


def clear_cmos(cluster, node, idsid=None, close_required=True, pythonsv=None):
    """
    clear CMOS command to the node in particular k8s cluster through PythonSV
    :param str cluster: option [opus,flex,icx-1..]
    :param str node: the node name; the node need to be labelled.
    :return
    """
    logging.info(f"start to do clear CMOS on {node}")
    if not pythonsv:
        pythonsv = unlock(cluster, node, idsid, close_required=False)
    pythonsv.series([["""
halt()
import pysvtools.xmlcli.XmlCliLib as clb
clb.clearcmos()
go()
"""]])
    if close_required:
        return pythonsv.close()
    else:
        return pythonsv


def check_txt_strap(cluster, node, idsid=None, pythonsv=None):
    logging.info(f"start to check txt strap on {node}")
    if not pythonsv:
        pythonsv = unlock(cluster, node, idsid, close_required=False)
    out = pythonsv.series([["""
sv.sockets.io0.uncore.hwrs.gpsb.poc_straps.show()
"""]]).close()

    rst = {}
    socket_rst = {}
    for line in re.split(r'\r?\n', out):
        if re.search(r'(?:txt_agent|txt_plten)', line):
            logging.debug(line)
            sections = line.split(':')
            if sections[1].split('(')[0].strip() not in socket_rst.keys():
                socket_rst[sections[1].split('(')[0].strip()] = sections[0].strip()
            else:
                # 2S
                rst[0] = socket_rst
                socket_rst = {}
                socket_rst[sections[1].split('(')[0].strip()] = sections[0].strip()

    # 1S
    if len(rst) == 0:
        rst[0] = socket_rst
    # 2S
    elif len(socket_rst) > 0:
        rst[1] = socket_rst

    logging.info(rst)
    return rst


def get_dimm_freq(cluster, node, idsid=None, pythonsv=None):
    logging.info(f"start to get dimm frequency on {node}")
    if not pythonsv:
        pythonsv = unlock(cluster, node, idsid, close_required=False)
    out = pythonsv.series([["""
dimminfo()
"""]]).close()

    rst = {}
    for line in re.split(r'\r?\n', out):
        if re.search(r'(?:DDR\sFrequency)', line):
            logging.debug(line)
            sections = line.split('|')
            rst[sections[0].strip()] = sections[1].strip()

    logging.info(rst)
    return rst


def srf_status_scope(cluster, node, idsid=None, close_required=True, pythonsv=None, timeout=3600):
    logging.info(f"start to collect srf status_scope on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target(node, timeout=timeout)
    pythonsv.series([[
        """
unlock()
sv.refresh()
from sierraforest.toolext import status_scope
status_scope.run(collectors=['namednodes'], analyzers=["auto"])
"""
    ]], timeout=3600 * 12)
    if close_required:
        pythonsv.eb.timeout = 3600 * 12
        return pythonsv.close()
    else:
        return pythonsv


def gnr_status_scope(cluster, node, idsid=None, close_required=True, pythonsv=None, timeout=3600):
    logging.info(f"start to collect srf status_scope on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target(node, timeout=timeout)
    pythonsv.series([[
        """
#Status Scope - new signature
unlock()
sv.refresh()
from graniterapids.toolext import status_scope 
status_scope.run(collectors=['namednodes','m2iosf'], skip_login=True)
"""
    ]], timeout=3600 * 12)
    if close_required:
        pythonsv.eb.timeout = 3600 * 12
        return pythonsv.close()
    else:
        return pythonsv


def gnr_mem_error(cluster, node, idsid='sys_asvauto', close_required=True, pythonsv=None,
                  enable_status_scope=True, timeout=3600 * 6):
    logging.info(f"start to collect GNR memory error on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target_test(node)

    platform = 'graniterapids'
    if cluster == 'srf':
        platform = 'sierraforest'

    optional_status_scope = f"""
from {platform}.toolext import status_scope
status_scope.run(collectors=['namednodes'], analyzers=["auto"])
""" if enable_status_scope else ""

    current_date = datetime.now()
    formatted_date = current_date.strftime("%Y-%m-%d")
    logging.info(formatted_date)
    logging.info(idsid)
    logging.info(enable_status_scope)
    logging.info(optional_status_scope)
    pythonsv.series([[
        f"""
import subprocess
itp.log('/home/{idsid}/{node}_pythonsv_{formatted_date}_showerrors.log')
subprocess.run(['cat', '/home/{idsid}/{node}_pythonsv_{formatted_date}_showerrors.log'])

import graniterapids.mc.gnrMcUtils as mu
mu.show_errors()
nolog()

sv.sockets.soc.ddrphy.logregisters('/home/{idsid}/{node}_pythonsv_{formatted_date}_ddrphy.log')
subprocess.run(['cat', '/home/{idsid}/{node}_pythonsv_{formatted_date}_ddrphy.log'])
sv.sockets.soc.memss.logregisters('/home/{idsid}/{node}_pythonsv_{formatted_date}_ddrmemss.log')
subprocess.run(['cat', '/home/{idsid}/{node}_pythonsv_{formatted_date}_ddrmemss.log'])

{optional_status_scope}

halt()
""", [">>>"], ['System is not out of reset. Cdie is not available']
    ]], timeout=timeout)
    if close_required:
        pythonsv.eb.timeout = timeout
        return pythonsv.close()
    else:
        return pythonsv


def pythonsv_cmds(cluster, node, idsid='sys_asvauto', close_required=True, pythonsv=None,
                  timeout=3600 * 6, cmds=None):
    logging.info(f"start to collect GNR memory error on {node}")
    if not pythonsv:
        pythonsv = PythonSV(cluster).target_test(node)

    current_date = datetime.now()
    formatted_date = current_date.strftime("%Y-%m-%d")
    logging.info(formatted_date)
    logging.info(idsid)
    pythonsv.series(
        [[f"""
{cmds}
""", [">>>"], ['System is not out of reset. Cdie is not available']]], timeout=timeout)
    if close_required:
        pythonsv.eb.timeout = timeout
        return pythonsv.close()
    else:
        return pythonsv
