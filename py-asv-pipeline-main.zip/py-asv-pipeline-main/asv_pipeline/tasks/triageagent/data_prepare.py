import logging
import re
from datetime import datetime, timedelta

import pexpect

from asv_pipeline.clusterscope.handler import get_metadata_by_nodes
from asv_pipeline.clusterscope.poolname import parse
from asv_pipeline.jk.jobs_handler import JK_JOB_Handler
from asv_pipeline.rf.handler import is_bmc_reachable, is_power_state
from asv_pipeline.tasks.bmc import interact_sol_for_ip_loss
from asv_pipeline.tasks.elasticsearch import es_qpool, es_sol, es_tests
from asv_pipeline.tasks.os import is_reachable, pingable
from asv_pipeline.util import get_cluster_by_naming

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

jk_job_handler = JK_JOB_Handler()


def get_logs_link(node, time_period="24h0m"):
    """
    Get the logs link for the specified cluster and node over the specified time period.
    
    Parameters:
    - node (str): The node identifier.
    - time_period (str): The time period in the format "13h30m" (e.g., 13 hours and 30 minutes ago).
    """

    # Determine the cluster name based on the node prefix
    # cluster name, e.g., "FlexBhs", "Gdc", "cwf".

    if node.startswith("fl"):
        cluster = "FlexBhs"
    elif node.startswith("zp31"):
        cluster = "Gdc"
    elif node.startswith("cs"):
        cluster = "cwf"
    else:
        raise ValueError(f"Unknown node prefix for node: {node}")

    # Parse the time_period string
    hours, minutes = 0, 0
    if 'h' in time_period:
        hours = int(time_period.split('h')[0])
        time_period = time_period.split('h')[1]
    if 'm' in time_period:
        minutes = int(time_period.split('m')[0])

    # Calculate tstart based on the parsed time period and tsend as the current time
    current_time = datetime.now()
    time_ago = timedelta(hours=hours, minutes=minutes)
    tstart = int((current_time - time_ago).timestamp() * 1000)  # Convert to milliseconds
    tend = int(current_time.timestamp() * 1000)  # Convert to milliseconds

    # Construct the URL
    url = f"https://log-extractor.flex.sova.intel.com/all_logs?cluster={cluster}&node={node}&tstart={tstart}&tend={tend}"
    logger.info(url)

    return url


def get_node_status(cluster, node, idsid):
    """
    Returns the status of the node as one of the following strings:
    "hang", "soft hang", "alive", "ip lost" or "power off".
    """
    # Placeholder logic for determining node status
    # Replace this with actual logic to determine the node's status
    # For now, it returns "alive" as a default value
    if not is_power_state(node):
        logger.debug(f'{node} is power off')
        return "power off"
    elif pingable(cluster, node, idsid) and is_reachable(cluster, node, idsid, timeout=(15, 2)):
        logger.debug(f'{node} is pingable and sshable')
        return "alive"
    else:
        try:
            output_ip_loss = interact_sol_for_ip_loss(cluster, node)
            logger.debug(output_ip_loss)
            if output_ip_loss:
                logger.debug(f'{node} is ip loss')
                return "ip lost"
        except pexpect.exceptions.TIMEOUT:
            logger.error(f'{node} is inactive')

        if (es_sol.check_heartbeat(cluster, node) or es_qpool.check_heart_beat(cluster, node)):
            logger.debug(f'{node} is alive')
            return "soft hang"
        else:
            return "hang"


def get_bmc_status(node):
    if is_bmc_reachable(node):
        logger.debug(f'{node} BMC is reachable')
        return "alive"
    else:
        logger.debug(f'{node} BMC is unreachable')
        return "unreachable"


def extract_test_prefix(last_test_content):
    if isinstance(last_test_content, str):
        if last_test_content in ["AC_Cycle_Sysman_AF", "Warm_Reset_OS", "Cold_Reset_Redfish"]:
            return last_test_content
        if "killer-pod" in last_test_content:
            match = re.search(r"\(after (.+?)\)", last_test_content)
            if match:
                return match.group(1)
            else:
                return "killer-pod"
        else:
            last_test_content = last_test_content.split(' (')[0]
            match = re.match(r"(.+)-[a-z0-9]{5}$", last_test_content)
            if match:
                return match.group(1)
    else:
        raise ValueError("Input must be a string")


def get_q2(node, testname):
    """
    How many nodes impacted out of planned nodes?
    --
    Ratio of (FAILED or UNKNOWN)/
    (Number of nodes running same test with bios id)  
    by matching with ifwi (bios id), metadata.test.name, 
    metadata.cscope.pProd and metadata.cscope.pSubProd (stepping)
    """

    try:
        metadata = get_metadata_by_nodes([node])[0]
        bios_version = metadata.get('biosVersion', '')
        pool = metadata.get('pool', '')
        cpu_prod = parse(pool).cpu
        cpu_stepping = parse(pool).stepping

        if not bios_version:
            logger.error(f"Cannot find biosVersion for node {node} to perform query")
            return "N/A"

        is_fields = [
            ("metadata.test.name", testname),
            ("metadata.cscope.biosVersion", bios_version),
        ]
        if cpu_prod:
            is_fields.append(("metadata.cscope.pProd", cpu_prod))
        if cpu_stepping:
            is_fields.append(("metadata.cscope.pSubProd", cpu_stepping))

        logger.info(f"Querying for node {node} with fields: {is_fields}")

        query_rst = [
            x for x in es_tests.get_test_summary(cluster="flex", day=60, is_fields=is_fields)
            if x['_source']['metadata.test.name'] == testname
        ]
        logger.debug(f"logsize match testname count: {len(query_rst)}")
        count_failed_unknown = sum(1 for x in query_rst
                                   if x['_source']["result"] in ["FAILED", "UNKNOWN"])
        return count_failed_unknown, len(query_rst)

    except Exception as e:
        logger.error(f"Error processing node {node}: {e}")
        return -1, -1


def get_q3_q4(node, testname):
    """
    Did the same test run previously on this node?
    --
    check for Kibana(metadata.test.name) with Kibana(kubernetes.host) 
    if it has test-* record > 2 matching within 60 days.
    """

    q3_answer = False
    q4_answer = None

    try:
        is_fields = [
            ("metadata.test.name", testname),
            ("kubernetes.host", node),
        ]

        logger.info(f"Querying for node {node} with fields: {is_fields}")

        query_rst = [
            x for x in es_tests.get_test_summary(cluster="flex", day=60, is_fields=is_fields)
            if x['_source']['metadata.test.name'] == testname
        ]
        logger.debug(f"logsize match testname count: {len(query_rst)}")
        q3_answer = True if len(query_rst) > 1 else False

        # Find the lasttime that was "PASSED"
        # remove latest one, and find first "PASSED"
        query_trimmed = query_rst[1:]
        first_passed_after_0 = next(
            (x for x in query_trimmed if x['_source']['result'] == 'PASSED'), None)

        if first_passed_after_0:
            bios_version = first_passed_after_0['_source']['metadata.cscope.biosVersion']
            timestamp = first_passed_after_0['_source']['@timestamp']
            pipeline_label = first_passed_after_0['_source']['metadata.test.pipeline']
            q4_answer = f"BIOS Version: {bios_version}, Timestamp: {timestamp}, Pipeline: {pipeline_label}"
        else:
            q4_answer = None

        logger.debug(q3_answer)
        logger.debug(q4_answer)

        return q3_answer, q4_answer

    except Exception as e:
        logger.error(f"Error processing node {node}: {e}")
        return q3_answer, q4_answer


def get_q5(test):
    """
    When was the issue reportedf?"
    """
    if "killer-pod" in test:
        return "during boot"
    elif test in ["Cold_Reset_Redfish", "Warm_Reset_OS", "AC_Cycle_Sysman_AF"]:
        return "during boot"
    else:
        return "workload"


def get_jenkins_url(cluster, node, workload):
    logger.debug(
        f"Start getting Jenkins URL for node {node} with test {workload} in cluster {cluster}")
    if workload in ["Cold_Reset_Redfish", "Warm_Reset_OS", "AC_Cycle_Sysman_AF"]:
        return "N/A"

    end = datetime.utcnow()
    start = end - timedelta(days=5)
    jenkins_link = "N/A"

    es = es_qpool._get_es_endpoint(cluster)
    body = (es.index("qpool-").IS('log',
                                  'test-start-indicator').IS('kubernetes.host',
                                                             node).IS('metadata.test.name',
                                                                      workload).range(start,
                                                                                      end).build())

    try:
        docs = es.execute(timeout=300, payload=body)
    except Exception as e:
        logger.error(str(e))
        return jenkins_link

    try:
        if docs:
            logger.info("Node %s: Found %d documents for test-start-indicator" % (node, len(docs)))
            buildtag = docs[0]['_source']['metadata']['test'].get('buildtag', None)
            if not buildtag:
                logger.warning(f"Node {node}: Build tag not found in the document.")
                return jenkins_link

            logger.info("Node %s: buildtag %s" % (node, buildtag))
            jenkins_link = jk_job_handler.get_jenkins_url(buildtag)
        else:
            logger.info("Node %s: No results when querying the last test-start-indicator" % node)
    except Exception as e:
        logger.error(f"Error processing Jenkins URL for node {node}: {e}")

    return jenkins_link


def get_metadata_info(node, test, idsid, time_period="24h0m"):
    cluster = get_cluster_by_naming(node)

    try:
        logs_link = get_logs_link(node, time_period)
    except Exception as e:
        logger.error(f"Error generating logs link for node {node}: {e}")
        logs_link = "N/A"

    try:
        node_status = get_node_status(cluster, node, idsid)
    except Exception as e:
        logger.error(f"Error determining node status for node {node}: {e}")
        node_status = "N/A"

    try:
        bmc_status = get_bmc_status(node)
    except Exception as e:
        logger.error(f"Error determining BMC status for node {node}: {e}")
        bmc_status = "N/A"

    try:
        jenkins_link = get_jenkins_url(cluster, node, extract_test_prefix(test))
    except Exception as e:
        logger.error(f"Error getting Jenkins Link for node {node}: {e}")
        jenkins_link = "N/A"

    failed_nodes, planned_nodes = get_q2(node, extract_test_prefix(test))
    q3_ans, q4_ans = get_q3_q4(node, extract_test_prefix(test))
    q5_ans = get_q5(test)

    metadata_info = {
        "logs_link": logs_link,
        "jenkins_link": jenkins_link,
        "node_status": node_status,
        "bmc_status": bmc_status,
        "total_planned_nodes": planned_nodes,
        "failed_planned_nodes": failed_nodes,
        "did_the_same_test_run_on_this_node_before": q3_ans,
        "last_pass_of_the_test_on_this_node_at": q4_ans,
        "failed_at_stage": q5_ans
    }

    return metadata_info
