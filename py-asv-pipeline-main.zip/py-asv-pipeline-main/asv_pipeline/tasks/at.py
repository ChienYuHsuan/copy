"""
auto trigger
"""
import logging
import re
from datetime import datetime, timedelta

import pandas as pd
import pytz
import tenacity

from asv_pipeline.clusterscope.handler import estimate_tags_in_test_desc, get_pool_name
from asv_pipeline.sharepoint.at import (compare_desc_with_pattern, load_pipelines,
                                        load_raw_pipelines, load_tasks, load_testname_in_pipelines,
                                        match_desc_with_pattern, meet_test_criteria)
from asv_pipeline.tasks.elasticsearch.es_burning_tracker import check_burnin_tracker
from asv_pipeline.tasks.elasticsearch.es_tests import get_test_summary


@tenacity.retry(wait=tenacity.wait_fixed(60), stop=tenacity.stop_after_attempt(3))
def load_and_prepare_data():
    cache = load_raw_pipelines()
    rst, ordered_lists = load_pipelines(cache)
    step_taskname, taskname_step = load_testname_in_pipelines(cache)
    tasks = load_tasks()
    return cache, rst, ordered_lists, step_taskname, taskname_step, tasks


def log_pipeline_info(rst, tasks):
    for cpu, tag_ctx in rst.items():
        logging.info(f"CPU {cpu}")
        for tag, ctx in tag_ctx.items():
            for k, _ in ctx.items():
                if not compare_desc_with_pattern(cpu, f"{k}--", tasks):
                    logging.error(f"{cpu}'s pipeline owns undefined task {k}--")
                    raise Exception("lack of job defintion associated with pipeline definition")


def get_test_data(suts, start=None, end=None):
    oneof = [("kubernetes.host", suts)]
    rst = get_test_summary(cluster="bhs", is_fields=None, oneof_fields=oneof, day=0, start=start,
                           end=end)
    return rst


def process_test_data(rst, suts, begin, days=14):
    if rst:
        result = [el['_source'] for el in rst]
        df = pd.json_normalize(result)
        burnin_result = check_burnin_tracker(suts, days=days, begin=begin)
        task_mp = {}
        for sut in suts:
            for el in df[df["kubernetes.host"] == sut].to_dict(orient='records'):
                if el["kubernetes.labels.name"] not in task_mp.get(el["kubernetes.host"], {}).get(
                        el["kubernetes.namespace_name"], {}):
                    task_mp.setdefault(el["kubernetes.host"], {}).setdefault(
                        el["kubernetes.namespace_name"],
                        {})[el["kubernetes.labels.name"]] = [el["result"], el["duration"]]
        return _update_task_mp_with_burnin_checker(task_mp, burnin_result)
    return None


def _update_task_mp_with_burnin_checker(task_mp, burnin_result):
    for n in task_mp:
        for el in burnin_result:
            if el['host'] != n or 'Namespace' not in el:
                continue
            for ns in task_mp[n]:
                if ns == el['Namespace']:
                    task_mp[n][ns]["RMT"] = "Pass" if re.search(r'Pass',
                                                                el['RMT result']) else "Fail"
                    task_mp[n][ns]["AMT"] = "Pass" if re.search(r'Pass',
                                                                el["AdvMemTest result"]) else "Fail"
                    task_mp[n][ns]["OMT"] = "Pass" if re.search(
                        r'Pass',
                        el["OS margin result"][0] if el["OS margin result"] else "") else "Fail"
    return task_mp


def get_pool_info(sut):
    poolname = get_pool_name([sut])[sut]
    return poolname


def determine_rerun_tasks(task_mp, sut, taskname_step, cpu, job, tag, cache):
    rerun = set()
    if sut not in task_mp:
        return rerun

    ns = next(iter(task_mp[sut]), None)
    if not ns:
        return rerun
    """
    taskname_step
    {'SRF-AP': {'default': {'BURNIN': {'ive-povray-rf-cold': ['RUN_COLD_POVRAY'],
                     'sandstone-rf-cold': ['RUN_COLD_CYCLE'], 'sandstone-rf-warm': ['RUN_WARM_CYCLE'] }}}}
    """
    logging.info(taskname_step)
    logging.info(tag)
    if cpu not in taskname_step:
        return rerun
    original_tag = tag
    tag = tag if tag in taskname_step.get(cpu, {}) else 'default'

    matched_job = job if job in taskname_step[cpu][tag] else None
    if not matched_job and tag != 'default':
        tag = 'default'
        matched_job = job if job in taskname_step[cpu][tag] else None

    if not matched_job:
        return rerun

    # rollback for critiera section
    for testname, steps in taskname_step[cpu][tag][matched_job].items():
        criteria_tag = original_tag
        if criteria_tag not in cache[cpu]['criteria'] or testname not in cache[cpu]['criteria'][
                criteria_tag][matched_job]:
            criteria_tag = 'default'
        if not meet_test_criteria(cpu=cpu, pipeline=matched_job, testname=testname,
                                  datasource=task_mp[sut][ns], tag=criteria_tag, doc=cache):
            rerun.update(steps)
    return rerun


def find_next_task(ordered_lists, cpu, cur_mission, tag='default'):
    if tag not in ordered_lists[cpu]:
        tag = 'default'
    try:
        nxt_index = ordered_lists[cpu][tag].index(cur_mission) + 1
        if nxt_index < len(ordered_lists[cpu][tag]):
            return ordered_lists[cpu][tag][nxt_index], True
    except ValueError:
        pass
    return None, False


def get_current_task_iteration(pipeline, cpu, cur_mission, tag='default'):
    if cpu not in pipeline:
        raise Exception(f"CPU {cpu} not found in pipeline")
    if tag not in pipeline[cpu]:
        tag = 'default'
    if cur_mission not in pipeline[cpu][tag]:
        raise Exception(f"Mission {cur_mission} not found in pipeline")
    return pipeline[cpu][tag][cur_mission]['iterations']


def get_at_next_step(suts: list[str], days=14):
    """
    Determines the next step for a list of systems under test (SUTs) based on their recent test data.
    Args:
        suts (list[str]): A list of system under test identifiers.
        days (int, optional): The number of days to look back for test data. Defaults to 14.
    Returns:
        dict: A dictionary where each key is a SUT identifier and the value is a tuple. The first element of the tuple
              is a set of tasks to rerun (or None if no rerun is needed), and the second element is the next task to 
              execute (or None if no next task is found). 
             e.g. {'fl31ca302as1009': ({'RUN_WORKLOADS_TSL', 'RUN_WARM_CYCLEL', 'RUN_HFSWEEP', 'RUN_WORKLOADS_VSS', 
                    'RUN_WORKLOADS_SANDSTONE', 'RUN_WORKLOADS', 'RUN_AMT', 'RUN_OMT', 'RUN_WORKLOADS_SHC', 
                    'RUN_COLD_CYCLE', 'RUN_RMT', 'RUN_COLD_POVRAY'}, None), 'fl31ca302bs0807': (None, None), 
                    'fl31ca302as1007': (None, None), 'fl31ca303as0604': ({'RUN_WORKLOADS_TSL', 'RUN_WARM_CYCLEL', 
                    'RUN_HFSWEEP', 'RUN_WORKLOADS_VSS', 'RUN_WORKLOADS_SANDSTONE', 'RUN_WORKLOADS', 'RUN_AMT', 
                    'RUN_OMT', 'RUN_WORKLOADS_SHC', 'RUN_COLD_CYCLE', 'RUN_RMT', 'RUN_COLD_POVRAY'}, None)}
    """
    cache, pl_jobs, ordered_lists, step_taskname, taskname_step, tasks = load_and_prepare_data()
    # logging.info(step_taskname)
    logging.info(pl_jobs)
    logging.info(tasks)
    # confirm that our data meet as we expected
    log_pipeline_info(pl_jobs, tasks)

    timezone = pytz.utc
    _now = datetime.now().astimezone(timezone)
    _begin = (_now - timedelta(days=days)).astimezone(timezone)

    rst = get_test_data(suts, start=_begin, end=_now)
    logging.debug(rst)
    task_mp = process_test_data(rst, suts, _begin, days=days)
    poolname_mp = get_pool_name(suts)

    logging.info(task_mp)

    if not task_mp:
        return {sut: (None, None) for sut in suts}

    ret = {}
    for sut in suts:
        pool_info = poolname_mp[sut]
        cur_mission = match_desc_with_pattern(pool_info.test_description, tasks)
        cpu = pool_info.cpu
        if not cur_mission:
            logging.error(f"{sut} {pool_info.test_description} doesn't match any pattern")
            continue
        # the sut doesn't execute any test content
        if sut not in task_mp:
            ret[sut] = (None, None)
            continue
        logging.info(f'current mission :{cur_mission}')
        _, _, _, tag = estimate_tags_in_test_desc(pool_info.test_description, True)
        rerun = determine_rerun_tasks(task_mp, sut, taskname_step, cpu, cur_mission, tag, cache)
        rerun_tmp = set()
        logging.info(f"rerun tasks: {rerun}")
        if tag in pl_jobs[cpu] and cur_mission in pl_jobs[cpu][tag]:
            logging.info(f"match tag's tasks : {pl_jobs[cpu][tag][cur_mission]['tasks']}")
        for el in rerun:
            if tag in pl_jobs[cpu] and cur_mission in pl_jobs[cpu][tag]:
                if el in pl_jobs[cpu][tag][cur_mission]["tasks"]:
                    rerun_tmp.add(el)
            else:
                rerun_tmp.add(el)
        rerun = rerun_tmp
        logging.info(f"processed rerun tasks: {rerun}")
        nxt = None
        if not rerun:
            nxt, has_nxt = find_next_task(ordered_lists, cpu, cur_mission, tag)
            logging.info(f"go next cycle : {nxt}....{has_nxt}")
        # if the rerun is set(), which means all the test cases are passed.
        # expression would be isinstance(rerun, set) and not rerun
        ret[sut] = (rerun, nxt)
    logging.info(ret)
    return ret
