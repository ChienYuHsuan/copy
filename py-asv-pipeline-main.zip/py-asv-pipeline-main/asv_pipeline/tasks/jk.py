from asv_pipeline.jk import JenkinsFactory


def burn_in(cluster):
    jf = JenkinsFactory()
    """
    TODO ClusterScope : READY->EXEC
    """
    if cluster == 'icx-1':
        jf.build_job("Pipelines/BKC-Burn-in-Pipeline-ICX-1")
    elif cluster == 'opus-spr':
        jf.build_job("Pipelines/BKC-Burn-in-Pipeline-Opusa")
