import hashlib
import json
import logging
import os
import re
import sys
from datetime import datetime

import html_to_json
import pytz
import requests
from dateutil.parser import parse

import asv_pipeline.config as cfg
from asv_pipeline.k8s import Kubernetes


class DualLogger:
    """A logger that writes to both a list and sys.stdout."""

    def __init__(self):
        self.logs = []

    def write(self, data):
        self.logs.append(data)
        # sys.stdout.write(data)  # Also write to sys.stdout

    def flush(self):
        sys.stdout.flush()  # Ensure compatibility with sys.stdout


def return_last_value(retry_state):
    """
    for tenacity
    """
    """return the result of the last call attempt"""
    return retry_state.outcome.result()


def are_both_empty_dicts(results):
    """
    for tenacity
    """
    # Check if the input is a tuple with two elements
    if isinstance(results, tuple) and len(results) == 2:
        # Unpack the results
        ret_a, ret_b = results
        # Check if both elements are empty dictionaries
        return isinstance(ret_a, dict) and not ret_a and isinstance(ret_b, dict) and not ret_b
    return False


def parse_life(day):
    pattern = r"([-+]?\d+\.\d+)|([-+]?\d+)"
    rst = re.split(pattern, day.strip())
    return [r.strip() for r in rst if r is not None and r.strip() != '']


def is_older(src, cond):
    # cond = re.split(r"([-+]?\d+\.\d+)|([-+]?\d+)", cond)
    src = parse_life(src)
    rst = parse_life(cond)
    # print(src , rst)
    units = {}
    for i, o in enumerate("ymwdhms"):
        units[o] = i
    if rst and len(rst) == 2:
        # including operator, and operand and unit

        # different unit and longer than expectation
        if units[src[1]] < units[rst[1]]:
            return True
        # same unit, need to check value
        elif units[src[1]] == units[rst[1]]:
            # same
            if int(src[0]) == int(rst[0]):
                if len(src) > 2:
                    return True
            elif int(src[0]) > int(rst[0]):
                return True
    return False


def display_not_ready_by_ns(kv):
    for k, arr in kv.items():
        print(k, ":")
        arr.sort()
        for v in arr:
            print(" " * 8 + "%s" % (v))
        print("-" * 23)


def display_not_ready_by_cluster(kv):

    nodes = set()
    for k, v in kv.items():
        if "flex" in k:
            print("\n\nTotal (%d) in flex" % len(v))
            print(",".join(v))
        else:
            nodes = nodes.union(v)
    print("\n\nTotal (%d) in opus/icx-1 " % len(nodes))
    print(",".join(nodes))


def str2labels(s):
    return s.split(",")


def label_4_pipeline(d: dict) -> dict:
    rst = {}
    for k, v in d.items():
        for x in v:
            arr = x.split("=")
            if arr[1] == 'true':
                if k not in rst:
                    rst[k] = []
                rst[k] += [arr[0]]
    return rst


def hash_node(s):
    return hashlib.sha256(s.encode('utf-8')).hexdigest()


def parse_time_for_es(t, timezone=pytz.utc):

    rst = datetime.strptime(t + "+00:00", "%Y-%m-%dT%H:%M:%S.%fZ%z")
    if timezone != pytz.utc:
        rst = rst.astimezone(timezone)
    return rst


def parse_time_for_reset_test_in_es(t, timezone=pytz.utc):
    rst = datetime.strptime(t, "%Y-%m-%dT%H:%M:%S")
    if timezone != pytz.utc:
        rst = rst.astimezone(timezone)
    return rst


def get_cluster_by_naming(x):
    # If environment variable KUBECONFIG is set, return it.
    from asv_pipeline.clusterscope import handler as cs_handler
    kubeconfig = os.environ.get('KUBECONFIG')
    if kubeconfig:
        return kubeconfig.split(".")[-1]

    # Otherwise, query node in all clusters to see which cluster this node is in.
    GET_NODES_WITHIN_CLUSTER = "kubectl --kubeconfig=%(kube)s --insecure-skip-tls-verify get node %(node)s"
    for kubeconfig in cfg.kubeconfigs.values():
        k8s = Kubernetes()
        out = k8s.cmd(GET_NODES_WITHIN_CLUSTER % {"kube": kubeconfig, "node": x})
        if out and len(out) > 1 and out[1].startswith(x):
            return kubeconfig.split(".")[-1]

    # If none of above has return value, check node naming convention.
    if re.search(r'\w*zp31\w+', x):
        return "zp31"
    elif re.search(r'\w+\.zp\w+', x):
        return "icx-1"
    elif re.search(r'\w*fl\w+es\w+', x) or re.search(r'\w*fl\w+hs\w+', x) or re.search(
            r'\w*fl\w+fs\w+', x) or re.search(r'\w*fl\w+gs\w+', x) or re.search(
                r'\w*fl\w+ds\w+', x) or re.search(r'\w*fl\w+as\w+', x) or re.search(
                    r'\w*fl\w+bs\w+', x) or re.search(r'\w*fl\w+cs\w+', x):
        cpu = cs_handler.get_cpu([x], None, 'bhs')[x]
        return 'srf' if re.search(r'SRF', cpu.upper()) else 'bhs'
    elif re.search(r'\w*fl\w+', x):
        return "flex"
    elif re.search(r'\w+\.op\w+', x):
        return "opus-spr"
    elif re.search(r'\w*ks\w+', x) or re.search(r'\w*cs\w+ms\w+', x) or re.search(
            r'\w*cs\w+ns\w+', x) or re.search(r'\w*cs\w+ls\w+', x):
        return "bhs" if re.search(r'fl31*', x) else "cwf"
    raise Exception("no matched clusters for node %s" % x)


"""
For bios order knob
Giving ori_id, target_idx and target_id
"""


def get_bios_order_knob(tidx, oid, tid):
    return "BootOrder_0=%(tid)s,BootOrder_%(tidx)s=%(oid)s" % locals()


"""
Example output: WW34
"""


def get_ww():
    currentYear = datetime.now().year
    try:
        resp = requests.get(
            "http://phonebook.intel.com/cgi-bin/phonecal?mon=Jul&year=%s&mode=year&who=TAIWAN" %
            currentYear)
        output_json = html_to_json.convert(resp.text)
        return output_json['html'][0]['body'][0]['form'][0]['b'][0]['a'][1]['_value']
    except Exception as e:
        logging.error(e)
        print(str(e))
        return 'TEMP'


def get_ww_tpe():
    tpe_time = datetime.now(pytz.timezone('Asia/Taipei'))
    current_date_tpe = tpe_time.date()
    iso_year, iso_week, iso_weekday = current_date_tpe.isocalendar()
    logging.info(f"Week number UTC+8 (starting Monday): {iso_week:02d}")

    return f"WW{iso_week:02d}"


def pod_json_to_dict(input):
    '''
    Sample output is like:
    {
        "sut-gnr-rp001": {
            "pod": "burnin-sandstone-rf-cold-97vbc",
            "status": "Running"
        },
        "sut-gnr-rp002": {
            "pod": "burnin-sandstone-rf-cold-q4f99",
            "status": "Running"
        }
    }
    '''
    output = {}
    if not os.path.isfile(input):
        print("File %s doesn't exist in local path" % input)
        return {}
    try:
        with open(input, "r") as f:
            data = json.load(f)
    except Exception as e:
        print(str(e))
        return {}

    try:
        for item in data['items']:
            output[item['spec']['nodeName']] = {}
            output[item['spec']['nodeName']]['pod'] = item['metadata']['name']
            output[item['spec']['nodeName']]['status'] = list(
                item['status']['containerStatuses'][0]['state'].keys())[0]
    except Exception as e:
        print(str(e))
    finally:
        print("Deleting %s" % input)
        os.remove(input)
    return output


def map_cluster_name_for_uram(node):
    mapping = {'zp31': 'zp31k1', 'flex': 'Flex', 'bhs': 'FlexBhs', 'srf': 'FlexBhs', 'cwf': 'cwf'}

    return mapping[get_cluster_by_naming(node)]


def ansi_escape(line):
    ansi_escape = re.compile(r"(\x9B|\x1B\[|\x1b])[0-?]*[ -/]*[;-~]")
    line = ansi_escape.sub("", line)

    line = line.replace("\n", "")
    line = line.replace("\t", "")
    line = line.replace("\r", "")
    line = line.strip()
    return line


def fully_ansi_escape(ctx):
    ansi_escape_8bit = re.compile(
        r'''
        (?: # either 7-bit C1, two bytes, ESC Fe (omitting CSI)
            \x1B
            [@-Z\\-_]
        |   # or a single 8-bit byte Fe (omitting CSI)
            [\x80-\x9A\x9C-\x9F]
        |   # or CSI + control codes
            (?: # 7-bit CSI, ESC [ 
                \x1B\[
            |   # 8-bit CSI, 9B
                \x9B
            )
            [0-?]*  # Parameter bytes
            [ -/]*  # Intermediate bytes
            [@-~]   # Final byte
        )
    ''', re.VERBOSE)
    special_move = re.compile(r'(?:(\[0m)+(\[\d+;\d+m)*|(\[\d+;\d+m)+|(\[0;\d+;\d+m)+)')
    result = ansi_escape_8bit.sub('', ctx)
    result = special_move.sub('', result)
    return result


def rem_nonprintable_ctrl_chars(txt):
    """Remove non_printable ascii control characters """
    # Removes the ascii escape chars
    try:
        txt = re.sub(r'[^\x20-\x7E|\x09-\x0A]', '', txt)
        # remove non-ascii characters
        txt = repr(txt).decode('unicode_escape').encode('ascii', 'ignore')[1:-1]
    except Exception as exception:
        if "'str' object has no attribute 'decode'" not in str(exception):
            logging.error(f'->{txt}<-')
            logging.error(str(exception))
    return txt


def s2b(sut, FQDN=False):
    if re.search(r'(s)(\d+)($|\.)(.*)', sut):
        rst = re.sub(r'(s)(\d+)($|\.)(.*)', r'b\2\3\4', sut)

        return rst if not FQDN else rst + ".deacluster.intel.com"
    raise Exception("SUT name doesn't match our naming convention")


def parse_time_for_clusterscope(t, timezone=pytz.utc):
    rst = datetime.strptime(t, "%a, %d %b %Y %H:%M:%S %Z")
    rst = rst.replace(tzinfo=pytz.utc)
    if timezone != pytz.utc:
        rst = rst.astimezone(timezone)
    return rst.strftime('%m/%d/%Y, %H:%M:%S %p')


def change_time_format(time, format='%a %d %b %Y %I:%M:%S %p %Z'):
    datetime_obj = parse(time)
    return datetime_obj.strftime(format)


def trigger_dag(dag, data):
    """
    To trigger specific DAG in Airflow
    :param str dag : DAG name in Airflow
    :param str data: The parameters in json format to pass to DAG
    Example of curl command to trigger DAG:
    curl --location 'http://localhost:8080/api/v1/dags/event_pythonsv_handler/dagRuns' --header 'Content-Type: application/json' --header 'Authorization: Basic <auth>' --data '{
    "conf": {
        "idsid": "sys_asvauto@intel.com",
        "suts": ["sut1", "sut2"]
    }}'
    """
    url = cfg.airflow_url % dag
    headers = {'Content-Type': 'application/json', 'Authorization': 'Basic %s' % cfg.af_base_auth}

    response = requests.post(url, headers=headers, json=data, verify=False)
    if response.status_code == 200:
        logging.info('Request to trigger DAG %s succeeded.' % dag)
        # data = response.json()
    else:
        logging.error('Request failed: %s' % response.status_code)

    # Print the response text (optional)
    logging.info(response.text)


def ordinal(n: int):
    if 11 <= (n % 100) <= 13:
        suffix = 'th'
    else:
        suffix = ['th', 'st', 'nd', 'rd', 'th'][min(n % 10, 4)]
    return str(n) + suffix
