import logging
import re
import time

import pexpect
import tenacity

import asv_pipeline.config as cfg
from asv_pipeline.goto import (_AS_JEKKINS, _DEA, _DEO_RAW, _FLEX_ADM_CWF, _FLEX_ADM_GNR,
                               _FLEX_ADMIN, _FLEX_BMC, _OPUS, _OPUS_ADMIN, _ZP31, ExpectBuilder)

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.DEBUG)
_IPMI_BASTION = "ssh -o StrictHostKeyChecking=no -o IdentitiesOnly=yes -i ~/.ssh/sys_asvauto.pem  user@bastion.vaas.intel.com"


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def ipmi(cluster, _idsid=None):
    """
    ipmi
    """
    eb = None
    eb = ExpectBuilder().spawn(_IPMI_BASTION)
    eb.expect("@.*$")
    eb.sendline('export LC_ALL=C; unset LANGUAGE; clear')
    return eb


@tenacity.retry(stop=tenacity.stop_after_attempt(3), wait=tenacity.wait_exponential(), reraise=True)
def bastion(cluster, _idsid=None):
    """
    pythonsv+csript+bastion
    """
    eb = None
    idsid = _idsid if _idsid else cfg.i_idsid
    logging.info("idsid : %s" % idsid)
    if cluster == 'flex' or cluster == 'bhs' or cluster == 'srf':
        eb = ExpectBuilder().spawn(_FLEX_BMC % locals())
        rst = eb.expect(
            [r'Are you sure you want to continue connecting', r's password:', r"a001admin001:"])
        if rst == 0:
            eb.sendline('yes')
            nested_rst = eb.expect([r's password:', r"a001admin001:"])
            if nested_rst == 0:
                eb.sendline(cfg.i_password)
                eb.expect(r"a001admin001:")
        elif rst == 1:
            eb.sendline(cfg.i_password)
            eb.expect(r"a001admin001:")
        eb.expect(r"\$")
    elif cluster == 'opus-spr':
        eb = ExpectBuilder().spawn(_DEA % locals())
        rst = eb.expect([r'Are you sure you want to continue connecting', r"@login01 ~\]"])
        if rst == 0:
            eb.sendline('yes')
            eb.expect(r"@login01 ~\]")
        eb.sendline(_OPUS)
        eb.expect(r"~\]\$")
    elif cluster == 'icx-1':
        eb = ExpectBuilder().spawn(_DEA % locals())
        rst = eb.expect([r'Are you sure you want to continue connecting', r"@login01 ~\]"])
        if rst == 0:
            eb.sendline('yes')
            eb.expect(r"@login01 ~\]")
        eb.expect(r"~\]\$")
    elif cluster == 'zp31':
        eb = ExpectBuilder().spawn(_ZP31 % locals())
        rst = eb.expect([r'Are you sure you want to continue connecting', r"@login01 ~\]"])
        if rst == 0:
            eb.sendline('yes')
            eb.expect(r"@login01 ~\]")
        eb.expect(r"~\]\$")
    elif cluster == 'cwf':
        return sysman(cluster, _idsid)
    eb.sendline('export LC_ALL=C; unset LANGUAGE; clear')
    return eb


def k8s(cluster, idsid=None):
    """
    kubernetes operation
    """
    eb = ExpectBuilder().spawn(_DEO_RAW)
    bastion = "_DEO_RAW"
    rst = eb.expect([
        r"Are you sure you want to continue connecting", r"piv@10.219.26.27's password",
        pexpect.TIMEOUT
    ], 10)
    if rst == 2:
        logging.info("change to next k8s bastion %s" % _AS_JEKKINS)
        eb = ExpectBuilder().spawn(_AS_JEKKINS)
        bastion = "_AS_JEKKINS"
        rst = eb.expect([
            r"Are you sure you want to continue connecting", r"sys_dpv@10.11.185.15's password",
            pexpect.TIMEOUT
        ], 10)
        if rst == 0:
            eb.sendline("yes")
            eb.expect(r"sys_dpv@10.11.185.15's password")
        elif rst == 2:
            logging.error(eb.before)
            raise pexpect.ExceptionPexpect(pexpect.TIMEOUT)
        eb.sendline(cfg.AS_JENKINS_PASSWORD)
        time.sleep(1)
        eb.sendline('sudo su')
        eb.expect(r'sudo] password for sys_dpv')
        eb.sendline(cfg.AS_JENKINS_PASSWORD)
        eb.sendline('exit')
        eb.expect(r"@.*[\$|#]")
        # eb.expect(r"@atscale-jenkins")
    elif rst <= 1:
        if rst == 0:
            eb.sendline("yes")
            eb.expect(r"piv@10.219.26.27's password")
        eb.sendline(cfg.DEO_INFRA_PASSWORD)
        eb.expect(r"@.*[\$|#]")
    cmd_as_jenkins = "alias kc='sudo kubectl --kubeconfig=/srv/kube/config.%(env)s --insecure-skip-tls-verify=true'"
    cmd_deo_raw = "alias kc='kubectl --kubeconfig=/srv/kube/config.%(env)s --insecure-skip-tls-verify=true'"
    if cluster == "opus-spr":
        # eb.sendline(_KUBECONFIG % {"env": "opus-spr"})
        eb.sendline(
            (cmd_deo_raw if bastion == '_DEO_RAW' else cmd_as_jenkins) % {"env": "opus-spr"})
    elif cluster == "flex":
        # eb.sendline(_KUBECONFIG % {"env": "flex"})
        eb.sendline((cmd_deo_raw if bastion == '_DEO_RAW' else cmd_as_jenkins) % {"env": "flex"})
    elif cluster == "icx-1":
        # eb.sendline(_KUBECONFIG % {"env": "icx-1"})
        eb.sendline((cmd_deo_raw if bastion == '_DEO_RAW' else cmd_as_jenkins) % {"env": "icx-1"})
    elif cluster == 'zp31':
        eb.sendline((cmd_deo_raw if bastion == '_DEO_RAW' else cmd_as_jenkins) % {"env": "zp31"})
    elif cluster == 'bhs':
        eb.sendline((cmd_deo_raw if bastion == '_DEO_RAW' else cmd_as_jenkins) % {"env": "bhs"})
    # eb.sendline("alias kc='kubectl --insecure-skip-tls-verify=true'")
    elif cluster == 'srf':
        eb.sendline((cmd_deo_raw if bastion == '_DEO_RAW' else cmd_as_jenkins) % {"env": "srf"})
    elif cluster == 'cwf':
        eb.sendline((cmd_deo_raw if bastion == '_DEO_RAW' else cmd_as_jenkins) % {"env": "cwf"})
    eb.sendline(f'export KUBECONFIG=/srv/kube/config.{cluster}')
    # eb.sendcontrol('C')
    eb.expect(r"@.*[\$|#]")
    eb.sendline('export LC_ALL=C; unset LANGUAGE; clear')
    return eb


@tenacity.retry(stop=tenacity.stop_after_attempt(4),
                wait=tenacity.wait_exponential(min=60, max=600, multiplier=60), reraise=True)
def sysman(cluster, _idsid=None, _cpu: str = None):
    eb = None
    idsid = _idsid if _idsid else cfg.i_idsid
    logging.info("idsid : %s" % idsid)

    def _handle_ssh_connection(eb, connection_patterns, password=None, error_msg=None):
        """Helper function to handle common SSH connection patterns"""
        try:
            rst = eb.expect(connection_patterns)

            if rst == 0:  # Are you sure you want to continue connecting
                eb.sendline('yes')
                nested_rst = eb.expect([connection_patterns[1], connection_patterns[2]])

                if nested_rst == 0:  # Password prompt
                    if not password:
                        # Check for password before connection
                        raise Exception("No keypair be injected! Contact infra team for help")
                    eb.sendline(password)
                    eb.expect(connection_patterns[2])
            elif rst == 1:  # Direct password prompt
                if not password:
                    # Check for password before connection
                    raise Exception("No keypair be injected! Contact infra team for help")
                eb.sendline(password)
                eb.expect(connection_patterns[2])
            elif rst > 2:  # TIMEOUT or EOF
                raise Exception(
                    f"{'TIMEOUT' if rst == 3 else 'EOF'} when trying to connect: {error_msg}")

            return eb
        except Exception as e:
            logging.error(f"Connection error: {str(e)}")
            raise  # Re-raise the exception to trigger retry

    if cluster == "flex":
        # Handle GNR-specific connection for flex cluster
        if _cpu and re.search(r'GNR', _cpu):
            eb = ExpectBuilder().spawn(_FLEX_ADM_GNR % locals())
        else:
            eb = ExpectBuilder().spawn(_FLEX_ADMIN % locals())

        connection_patterns = [
            r"Are you sure you want to continue connecting", r's password:', r'\w+@\w+[:~]',
            pexpect.TIMEOUT, pexpect.EOF
        ]
        eb = _handle_ssh_connection(eb, connection_patterns, cfg.i_password,
                                    f"bastion {cluster} with idsid {idsid}")

    elif cluster in ["bhs", "srf"]:
        eb = ExpectBuilder().spawn(_FLEX_ADM_GNR % locals())
        connection_patterns = [
            r"Are you sure you want to continue connecting", r's password:', r'\w+@\w+[:~]',
            pexpect.TIMEOUT, pexpect.EOF
        ]
        eb = _handle_ssh_connection(eb, connection_patterns, cfg.i_password,
                                    f"bastion {cluster} with idsid {idsid}")

    elif cluster == "cwf":
        eb = ExpectBuilder().spawn(_FLEX_ADM_CWF % locals())
        connection_patterns = [
            r"Are you sure you want to continue connecting", r's password:', r'\w+@\w+[:~]',
            pexpect.TIMEOUT, pexpect.EOF
        ]
        eb = _handle_ssh_connection(eb, connection_patterns, cfg.i_password,
                                    f"bastion {cluster} with idsid {idsid}")

    elif cluster in ["icx-1", "zp31"]:
        # Use the appropriate spawn command based on cluster
        spawn_cmd = _ZP31 if cluster == "zp31" else _DEA
        eb = ExpectBuilder().spawn(spawn_cmd % locals())

        connection_patterns = [
            r"Are you sure you want to continue connecting", r"'s password:", r"@login01 ~\]",
            pexpect.TIMEOUT, pexpect.EOF
        ]
        eb = _handle_ssh_connection(eb, connection_patterns, cfg.i_password,
                                    f"bastion {cluster} with idsid {idsid}")

    elif cluster == "opus-spr":
        eb = ExpectBuilder().spawn(_DEA % locals())
        connection_patterns = [
            r"Are you sure you want to continue connecting", r"'s password:", r"@login01 ~\]",
            pexpect.TIMEOUT, pexpect.EOF
        ]
        eb = _handle_ssh_connection(eb, connection_patterns, cfg.i_password,
                                    f"bastion {cluster} with idsid {idsid}")

        # Additional steps specific to opus-spr
        eb.sendline(_OPUS)
        eb.expect(r"a01s01 ~\]\$")
        eb.sendline(_OPUS_ADMIN)
        eb.expect(r"a01s19 ~\]\$")

    eb.sendline('export LC_ALL=C; unset LANGUAGE; clear')
    return eb


def sut(cluster, node, idsid=None, timeout=(60, 15)):
    eb = bastion(cluster, idsid)
    halt, cycle = int(timeout[0]), int(timeout[1])
    logging.info("%d and %d" % (halt, cycle))
    eb.timeout = halt
    pattern = [
        pexpect.TIMEOUT, r'Connection timed out', r'No route to host',
        "root@" + node.split(".")[0] + r'\.*\w*\s+~\][#|\$]', r'root@.+\s? password:',
        r'System is booting up. Unprivileged users are not permitted to log in yet',
        r'Are you sure you want to continue connecting'
    ]
    eb.sendline(
        f"ssh root@{node} -o ConnectTimeout=20 -o StrictHostKeyChecking=no -o GlobalKnownHostsFile=/dev/null -o UserKnownHostsFile=/dev/null"
    )
    rst = eb.expect(pattern, halt)
    for i in range(cycle):
        if rst > 1:
            break
        eb.sendcontrol('c')
        logging.info("%d time, try to access %s" % (i, node))
        time.sleep(halt)
        eb.sendline(
            f"ssh root@{node} -o ConnectTimeout=20 -o StrictHostKeyChecking=no -o GlobalKnownHostsFile=/dev/null -o UserKnownHostsFile=/dev/null"
        )
        eb.timeout = halt
        rst = eb.expect(pattern, halt)
    if rst <= 2:
        raise Exception('no available tty')

    # sz = len(pattern)  # would get 7 at the moment
    _cycle = cycle
    while (rst != 3 and _cycle):
        if rst == 6:
            eb.sendline('yes')
        elif rst == 4:
            eb.sendline(cfg.SUT_ROOT_PASSWORD)
        elif rst == 5:
            eb.sendcontrol('c')
            logging.info("%d time, wait for %s system booting up" % (cycle - _cycle + 1, node))
            time.sleep(halt)
            eb.sendline(
                f"ssh root@{node} -o ConnectTimeout=20 -o StrictHostKeyChecking=no -o GlobalKnownHostsFile=/dev/null -o UserKnownHostsFile=/dev/null"
            )
            eb.timeout = halt
        _cycle -= 1
        rst = eb.expect(pattern, halt)
        logging.info(f"current {cycle - _cycle}, rst : {rst}")

    if rst != 3:
        raise Exception('no available tty')
    else:
        eb.sendline('export LC_ALL=C; unset LANGUAGE; clear')
        eb.sendline('')
        return eb


def bmc(cluster, node, idsid=None, timeout=(60, 15)):
    if "bmc_username" not in dir(cfg) or "bmc_password" not in dir(
            cfg) or not cfg.bmc_password or not cfg.bmc_username:
        raise Exception("Please go config your bmc_username and bmc_password in config.py")

    eb = bastion(cluster, idsid)
    halt, cycle = int(timeout[0]), int(timeout[1])
    logging.info("%d and %d" % (halt, cycle))
    eb.timeout = halt
    pattern = [
        pexpect.TIMEOUT, r'Connection timed out', r'No route to host', "root@bmc",
        r'root@.+\s? password:',
        r'System is booting up. Unprivileged users are not permitted to log in yet',
        r'Are you sure you want to continue connecting'
    ]
    eb.sendline(
        f"ssh root@{node} -o ConnectTimeout=20 -o StrictHostKeyChecking=no -o GlobalKnownHostsFile=/dev/null -o UserKnownHostsFile=/dev/null"
    )
    rst = eb.expect(pattern, halt)
    for i in range(cycle):
        if rst > 1:
            break
        eb.sendcontrol('c')
        logging.info("%d time, try to access %s" % (i, node))
        time.sleep(halt)
        eb.sendline(
            f"ssh root@{node} -o ConnectTimeout=20 -o StrictHostKeyChecking=no -o GlobalKnownHostsFile=/dev/null -o UserKnownHostsFile=/dev/null"
        )
        eb.timeout = halt
        rst = eb.expect(pattern, halt)
    if rst <= 2:
        raise Exception('no available tty')

    # sz = len(pattern)  # would get 7 at the moment
    _cycle = cycle
    while (rst != 3 and _cycle):
        if rst == 6:
            eb.sendline('yes')
        elif rst == 4:
            eb.sendline(cfg.bmc_password)
        elif rst == 5:
            eb.sendcontrol('c')
            logging.info("%d time, wait for %s system booting up" % (cycle - _cycle + 1, node))
            time.sleep(halt)
            eb.sendline(
                f"ssh root@{node} -o ConnectTimeout=20 -o StrictHostKeyChecking=no -o GlobalKnownHostsFile=/dev/null -o UserKnownHostsFile=/dev/null"
            )
            eb.timeout = halt
        _cycle -= 1
        rst = eb.expect(pattern, halt)
        logging.info(f"current {cycle - _cycle}, rst : {rst}")

    if rst != 3:
        raise Exception('no available tty')
    else:
        eb.sendline('export LC_ALL=C; unset LANGUAGE; clear')
        eb.sendline('')
        return eb
