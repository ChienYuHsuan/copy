"""The main application package."""
import os
from subprocess import check_output

__version__ = '0.0.1'
GIT = '/usr/bin/git'
ROOT = os.path.dirname(os.path.dirname(__file__))
try:
    __version__ = check_output(
        [GIT, '--git-dir', os.path.join(ROOT, '.git'), 'describe', '--tags'],
    ).decode().strip()[1:]
    import re
    __version__ = re.sub(r'(?!\d)\-(?=\d)', '.', __version__)
# except (CalledProcessError, Exception):  # pragma: no cover
#     __version__ = 'unknown'
except Exception:
    __version__ = 'unknown'
