import logging

from jira import JIRA

import asv_pipeline.config as cfg

assert cfg.jira_url is not None
assert cfg.jira_access_token is not None

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')


class JiraFactory:

    def __init__(self):
        self.options = {
            'server': cfg.jira_url,
            'headers': {
                'Authorization': f'Bearer {cfg.jira_access_token}',
            },
            'verify': False
        }

        # Initialize connection to JIRA with Bearer Token
        self.jira = JIRA(options=self.options)

    def create_issue(self, project_key, summary, description, issue_type='Task', labels=None,
                     custom_fields=None):
        logging.info("Starting create jira ticket with summary %s" % summary)
        '''
        Create a new issue in JIRA with optional fields.
        
        :param project_key: key of a project
        :param summary: Summary of the issue
        :param description: Description of the issue
        :param issue_type: Type of the issue (e.g., Task, Bug)
        :param labels: (Optional) List of labels to be applied to the issue
        :param custom_fields: (Optional) Dictionary of custom field names and values
        :return: Created issue instance
        '''

        # Create the issue dictionary
        issue_dict = {
            'project': project_key,
            'summary': summary,
            'description': description,
            'issuetype': {
                'name': issue_type
            },
        }

        # Add optional fields if provided
        if labels:
            issue_dict['labels'] = labels

        if custom_fields:
            issue_dict.update(custom_fields)

        logging.debug("jira ticket content %s" % issue_dict)

        # Create the issue in JIRA
        new_issue = self.jira.create_issue(fields=issue_dict)
        return new_issue
