import argparse
import json
import logging
import os
import shutil
import sys
from datetime import date, datetime, timezone

import asv_pipeline.clusterscope.handler as handler
import asv_pipeline.config as cfg
from asv_pipeline.clusterscope import ClusterScope
from asv_pipeline.es import ES
from asv_pipeline.jk import JenkinsFactory
from asv_pipeline.k8s import Kubernetes, k8s_handler
from asv_pipeline.tasks.mem_tests import (get_rmt_test_period, query_amt, query_dimm_info,
                                          query_os_margin, query_rmt)
from asv_pipeline.util import (change_time_format, get_cluster_by_naming, map_cluster_name_for_uram,
                               pod_json_to_dict)

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

FOLDER = cfg.burnin_folder
FILE = cfg.burnin_file
LOG_LINK = "https://log-extractor.flex.sova.intel.com/specific_log?cluster=%(cluster)s&node=%(node)s&tstart=%(start)d&tend=%(end)d&log=bmc-serial-console"
"""
Modify Excel file with column names and sheets respectively: "EGS_SPR_WAVE2_nodes_enablement_tracker.xlsx".
"""


def modify_poolname_to_com():
    log.info("Start modifying pool names")
    _nodes = get_node_by_ns()
    nodes = list(_nodes.keys())
    res, noassigned = handler.get_pool_by_nodes(nodes)
    locations = handler.get_location_by_nodes(nodes)
    log.info("Nodes: %s" % nodes)
    if not nodes or not locations:
        log.info("No available node to modify pool name. Return.")
        return
    _cluster = get_cluster_by_naming(nodes[0])
    cs = ClusterScope(cfg.clusterscopes[_cluster])
    for n in nodes:
        if n not in res:
            log.debug("Node %s doesn't have correct pool name" % n)
            continue

        if _nodes[n] != 'Ready':
            log.debug("Node %s pool name is not changed in this stage due to NotReady (%s)" %
                      (n, res[n]))
            continue

        if res[n].state == 'DBG' or res[n].state == 'NTR':
            log.debug("Node %s pool name is not changed in this stage due to its state (%s)" %
                      (n, res[n].state))
            continue

        target = "%s_%s_%s_%s_%s_%s_%s" % (res[n].cpu, res[n].stepping, res[n].asignto, 'COM',
                                           res[n].subclustername, res[n].test_description,
                                           res[n].idsid)
        log.debug("Target pool name for node %s: %s" % (n, target))
        try:
            res[n].update_node(n, locations[n]).update_pool(target)
            handler.update_pool_by_names(cs, res[n])
        except Exception as e:
            log.error("%s, %s" % (n, str(e)))
            continue


def get_job_type(job):
    # Normalize the job string by replacing known separators with a standard one
    normalized_job = job.replace(' ', '-').replace('_', '-')

    # Split the job string by '-'
    parts = normalized_job.split('-')

    if "BKC" in parts:
        if "Stage1" in parts:
            return "BKCStage1"
        elif "Stage2" in parts:
            return "BKCStage2"

    if "Main" in parts:
        if "1" in parts:
            return "Main1"
        elif "2" in parts:
            return "Main2"

    # Iterate over the parts to find a match with possible types
    for i in range(len(parts)):
        # Check if the current part is in the possible types
        if parts[i] in cfg.pipeline_types:
            return parts[i]
        # Check if the current part and the next part combined are in the possible types
        if i < len(parts) - 1:
            combined_part = parts[i] + parts[i + 1]
            if combined_part in cfg.pipeline_types:
                return combined_part

    # If no type is found, return None or an appropriate message
    return None


def get_report(nodes, cpu):
    log.info("Trigger task to get test summary report: %s" % cfg.summary_report_job)
    _nodes = '\n'.join(nodes)

    log.info("Nodes: %s" % _nodes)
    log.info("CPU: %s" % cpu.upper())
    log.info("NS: %s" % os.environ["NS"])
    log.info("RECIPIENT: %s" % os.environ["RECIPIENT"])
    log.info("TRIGGER_JOB: %s" % os.environ["BUILD_TAG"])
    log.info("TRIGGER_JOB_LINK: %s" % os.environ["BUILD_URL"])
    log.info("START: %s, END: %s" % (os.environ["START"], os.environ["END"]))
    job_type = get_job_type(os.environ["BUILD_TAG"])
    log.info("Job type: %s" % job_type)
    queue_id = JenkinsFactory().build_job(
        cfg.summary_report_job, {
            "SUT_LIST": _nodes,
            "CPU": cpu.upper(),
            "TEST_TYPE": job_type,
            "NS": os.environ["NS"],
            "DAYS": 0,
            "RECIPIENT": os.environ["RECIPIENT"],
            "TRIGGER_JOB": os.environ["BUILD_TAG"],
            "TRIGGER_JOB_LINK": os.environ["BUILD_URL"],
            "START": os.environ["START"],
            "END": os.environ["END"]
        })
    build_id = JenkinsFactory().get_build_id_by_queueid('fake_name', queue_id)
    log.info("Trigger %s with Build id: %s" % (cfg.summary_report_job, build_id))
    build_url = JenkinsFactory().get_build_url_by_buildid(cfg.summary_report_job, build_id)
    log.info("Summary Report Job URL: %s" % build_url)


def get_node_list(id):
    log.info("Get node list")
    id = "".join(id.split())
    file_to_open = id + ".json"
    with open(file_to_open, 'r') as json_file:
        rst = json.load(json_file)
    _nodes = list(rst.keys())

    log.info("Nodes List: %s" % _nodes)
    log.info("Remove json file %s" % file_to_open)
    os.remove(file_to_open)

    return _nodes


def get_node_by_ns():
    cmd = "kubectl %(kubeconfig)s --insecure-skip-tls-verify get node -l %(label)s --no-headers" % {
        "kubeconfig": os.environ['KUBECTL_ARGS'],
        "label": os.environ['JENKINS_NODE_LABEL']
    }
    k8s = Kubernetes()
    out = k8s.cmd(cmd)

    if "No resources found" in out:
        log.warning("No resources found. Exit")
        return {}
    rst = {}
    for node in out:
        A = node.split()
        rst[A[0]] = A[1]

    return rst


def update(rst, amt, amt_raw, rmt, os_margin, dimm_info):
    # We assume that all nodes in the same pipeline have the same CS pool name. So we only use the first node to retrieve its stepping.
    nodes = list(rst.keys())

    try:
        res, noassigned = handler.get_pool_by_nodes(set(nodes))
    except Exception as e:
        log.error("There is issue when getting pool name from ClusterScope. %s" % str(e))
        sys.exit(0)

    log.debug("res: %s" % res)

    log.debug("nodes %s" % nodes)
    try:
        stepping = res[nodes[0]].stepping
    except Exception as e:
        log.warning(
            "There is issue when getting information from poolname. Make sure you have correct poolname. %s: %s"
            % (type(e).__name__, str(e)))
        sys.exit(0)

    body = []
    for node, status in rst.items():
        d = {}
        log.debug("node: %s" % node)
        if node not in res:
            log.warning("Node %s is not in the poolname list. Skip" % node)
            continue
        log.debug("Stepping: %s" % res[node].stepping)
        cpu = res[node].cpu
        stepping = res[node].stepping

        result = 'FAILED' if status == 'NotReady' else 'YES'

        if all(node in lst for lst in [amt, amt_raw, rmt, os_margin, dimm_info]):
            res_metadata = {}
            try:
                res_metadata = handler.get_metadata_by_nodes([node])
            except Exception as e:
                log.error(str(e))
            if not res_metadata:
                metadata = {}
            else:
                metadata = res_metadata[0]

            start, end = datetime.now(), datetime.now()
            start_epoch, end_epoch = 0, 0
            try:
                start = datetime.strptime(change_time_format(os.environ['START']),
                                          '%a %d %b %Y %I:%M:%S %p %Z')
                end = datetime.strptime(change_time_format(os.environ['END']),
                                        '%a %d %b %Y %I:%M:%S %p %Z')
                start_epoch = int(start.replace(tzinfo=timezone.utc).timestamp() * 1000)
                end_epoch = int(end.replace(tzinfo=timezone.utc).timestamp() * 1000)
            except Exception as e:
                log.error(str(e))
            cluster = map_cluster_name_for_uram(node)

            jk_link = os.environ.get('BUILD_URL', 'NA')
            rmt_start, rmt_end = get_rmt_test_period(node, jk_link, start, end)

            if metadata and metadata['bmcLastRT'] == 'unknown':
                _ = [
                    metadata.pop(key, None) for key in ('bmcLastRT', 'errorLogCompleted', 'lastRT')
                ]

            if True:
                d.update({
                    'host': node,
                    'BurnIn cycle completed': result,
                    '@start': start,
                    '@end': end,
                    'cpu': cpu,
                    'Poolname_stepping': stepping,
                    'Job name': os.environ['JOB_NAME'],
                    'Build number': os.environ['BUILD_NUMBER'],
                    'RMT result': rmt.get(node, "")['status'],
                    'DimmMfg': dimm_info.get(node, "")['manufacturer'],
                    'DimmMfgDate': dimm_info.get(node, "")['manufacture_date'],
                    'DPC': dimm_info.get(node, "")['dpc'],
                    'DDR_Speed': dimm_info.get(node, "")['speed'],
                    'RMT Version': rmt.get(node, "")['version'],
                    'AdvMemTest result': amt.get(node, "")['results'],
                    'AdvMemTest result (raw)': amt_raw.get(node, "")['results'],
                    'OS margining throughput': os_margin.get(node, "")['throughput'],
                    'Memory channels': os_margin.get(node, "")['channels'],
                    'Memory controllers': os_margin.get(node, "")['controllers'],
                    'Memory slots': os_margin.get(node, "")['slots'],
                    'CPU cores': os_margin.get(node, "")['cores'],
                    'Sockets': os_margin.get(node, "")['sockets'],
                    'Jasper-mlc-margin runs': os_margin.get(node, "")['runs'],
                    'OS margin result': os_margin.get(node, "")['results'],
                    'Build type': os.environ.get('BUILD_TYPE', 'Not set'),
                    'cscope': metadata,
                    'cluster': cluster,
                    'start_epoch': start_epoch,
                    'end_epoch': end_epoch,
                    'JenkinsLink': os.environ.get('BUILD_URL', 'NA'),
                    'SOL Link': LOG_LINK % {
                        'cluster': cluster,
                        'node': node,
                        'start': start_epoch,
                        'end': end_epoch
                    },
                    'RMT SOL Link': LOG_LINK % {
                        'cluster': cluster,
                        'node': node,
                        'start': rmt_start,
                        'end': rmt_end
                    },
                    'capacity': dimm_info.get(node, "")['capacity'],
                    'density': dimm_info.get(node, "")['density'],
                    'type': dimm_info.get(node, "")['type'],
                    'Raw card': dimm_info.get(node, "")['raw_card'],
                    'RUN AMT': os.environ.get('RUN_AMT', 'NA'),
                    'RUN RMT': os.environ.get('RUN_RMT', 'NA'),
                    'RUN OMT': os.environ.get('RUN_OMT', 'NA'),
                    'RUN ALL': os.environ.get('RUN_ALL', 'NA'),
                    'BUILD_TYPE_MEM': os.environ.get('BUILD_TYPE_MEM', 'NA'),
                    'Namespace': os.environ.get('NS', 'NA'),
                })
                body += [d]

    if "Burnin" in os.environ['JOB_NAME'] or "Burn-in" in os.environ['JOB_NAME']:
        es = ES(url=cfg.es_endpoints['zp31'], name=cfg.es_username['zp31'],
                password=cfg.es_password['zp31'])
        try:
            es.bulk(
                body, "%(idx)s-%(date)s" % {
                    "idx": cfg.idx_burnin_update,
                    "date": date.today().strftime('%Y.%m.%d')
                })

        except Exception as e:
            log.error("Error raised during pushing data to ES: %s" % str(e))


def push_period_to_elasticsearch():
    d = {}
    try:
        d.update({
            '@start':
            datetime.strptime(change_time_format(os.environ['START']),
                              '%a %d %b %Y %I:%M:%S %p %Z'),
            '@end':
            datetime.strptime(change_time_format(os.environ['END']), '%a %d %b %Y %I:%M:%S %p %Z'),
            'Job name':
            os.environ['JOB_NAME'],
            'Build number':
            os.environ['BUILD_NUMBER'],
            'Namespaces':
            os.environ['NS']
        })
    except Exception as e:
        log.error(str(e))

    log.info("Push start/end of pipeline %s build #%s to Elasticsearch" %
             (os.environ['JOB_NAME'], os.environ['BUILD_NUMBER']))
    es = ES(url=cfg.es_endpoints['zp31'], name=cfg.es_username['zp31'],
            password=cfg.es_password['zp31'])
    try:
        es.bulk([d], "%(idx)s-%(date)s" % {
            "idx": cfg.idx_burnin_period,
            "date": date.today().strftime('%Y.%m.%d')
        })
    except Exception as e:
        log.error("Error raised during pushing data to ES: %s" % str(e))


def push_burnin_results(init, nodes):
    cmd = "kubectl %(kubeconfig)s --insecure-skip-tls-verify get node -l %(label)s --no-headers" % {
        "kubeconfig": os.environ['KUBECTL_ARGS'],
        "label": os.environ['JENKINS_NODE_LABEL']
    }
    k8s = Kubernetes()
    out = k8s.cmd(cmd)

    if "No resources found" in out:
        log.warning("No resources found. Exit")
        sys.exit(0)
    rst = {}
    for node in out:
        A = node.split()
        rst[A[0]] = A[1]

    for node in nodes:
        if node not in rst:
            rst[node] = 'NotReady'

    log.info("Start pushing Burnin results to ES: %s" % rst)
    res_amt, res_amt_raw, res_rmt, res_os = {}, {}, {}, {}
    cluster = os.environ['KUBECTL_ARGS'].split(".")[-1]
    if not init:
        res_amt = query_amt(cluster, rst, 'sol-')
        res_amt_raw = query_amt(cluster, rst, 'sol_raw-')
        res_rmt = query_rmt(cluster, rst)
        res_os = query_os_margin(rst)

        dimm_info = query_dimm_info(rst)

    update(rst, res_amt, res_amt_raw, res_rmt, res_os, dimm_info)


def query_test_results(host, pod, begin, end):
    '''
    Return one of "TEST PASSED", "TEST FAILED", "TEST ABORTED", "NA"
    '''
    cluster = get_cluster_by_naming(host)
    try:
        res = handler.get_cpu([host])
        cpu = res[host]
        if cpu == 'SRF-AP' or cpu == 'SRF-SP':
            cluster = 'flex'
    except Exception as e:
        log.error("Error raised during query_test_results: %s" % str(e))
    es = ES(url=cfg.es_endpoints[cluster], name=cfg.es_username[cluster],
            password=cfg.es_password[cluster]).index("qpool-*")
    payload = es.IS('kubernetes.host', host).IS('kubernetes.pod_name', pod).oneOf(
        'log', ['TEST PASSED', 'TEST FAILED', 'TEST ABORTED']).range(begin, end).build()
    docs = es.execute(timeout=600, payload=payload)

    return docs[0]['_source']['log'] if docs else 'NA'


def push_pod_status_to_es(data):
    log.info("Push pod status to ES")
    body = []
    for k, v in data.items():
        d = {}
        testresult = query_test_results(k, v.get("pod"), v.get("starttime"), v.get("endtime"))
        v['host'] = k
        v['TestResult'] = testresult
        d.update(v)
        body += [d]

    es = ES(url=cfg.es_endpoints['zp31'], name=cfg.es_username['zp31'],
            password=cfg.es_password['zp31'])
    try:
        es.bulk(
            body, "%(idx)s-%(date)s" % {
                "idx": cfg.idx_burnin_status,
                "date": date.today().strftime('%Y.%m.%d')
            })
    except Exception as e:
        log.error("Error raised during pushing data to ES: %s" % str(e))


def push_status_to_elasticsearch(source_json, jenkinid):
    log.info("Source json file name: %s" % source_json)
    log.info("Pipeline unique id: %s" % jenkinid)
    body = []

    with open(source_json, 'r') as openfile:
        rst = json.load(openfile)
        for key, valuelist in rst.items():
            for eachitem in valuelist:
                testresult = query_test_results(
                    key, eachitem.get("Pod"),
                    datetime.strptime(eachitem.get("StartTime"), '%Y-%m-%dT%H:%M:%S:%fZ'),
                    datetime.strptime(eachitem.get("EndTime"), '%Y-%m-%dT%H:%M:%S:%fZ'))
                d = {}
                d.update({
                    'host': key,
                    'starttime': datetime.strptime(eachitem.get("StartTime"), '%Y-%m-%dT%H:%M:%S:%fZ'),
                    'endtime': datetime.strptime(eachitem.get("EndTime"), '%Y-%m-%dT%H:%M:%S:%fZ'),
                    'nodestatus': eachitem.get("Status"),
                    'NodeResult': eachitem.get("Result"),
                    'test': eachitem.get("Stage"),
                    'pool': eachitem.get("Pool"),
                    'microcode': eachitem.get("Microcode"),
                    'stepping': eachitem.get("Stepping"),
                    'qdf': eachitem.get("Qdf"),
                    'biosVersion': eachitem.get("BiosVersion"),
                    'system-os': eachitem.get("System-os"),
                    'bmcVersion': eachitem.get("BmcVersion"),
                    'pod': eachitem.get("Pod"),
                    'pod status': eachitem.get("Pod status"),
                    'TestResult': testresult,
                    'JenkinsLink': eachitem.get('JenkinsLink')
                })  # yapf: disable
                body += [d]

    es = ES(url=cfg.es_endpoints['zp31'], name=cfg.es_username['zp31'],
            password=cfg.es_password['zp31'])
    try:
        es.bulk(
            body, "%(idx)s-%(date)s" % {
                "idx": cfg.idx_burnin_status,
                "date": date.today().strftime('%Y.%m.%d')
            })
        os.remove(source_json)
    except Exception as e:
        log.error("Error raised during pushing data to ES: %s" % str(e))
        if not os.path.exists('json'):
            os.makedirs('json')
        shutil.move(source_json, './json/' + source_json)


def node_status_json(init=False, id=False, stage=False, starttime=False, endtime=False):
    cmd = "kubectl %(kubeconfig)s --insecure-skip-tls-verify get node -l %(label)s --no-headers" % {
        "kubeconfig": os.environ['KUBECTL_ARGS'],
        "label": os.environ['JENKINS_NODE_LABEL']
    }

    id = "".join(id.split())
    pod_status_json = "/tmp/" + id + "_" + os.environ.get('TEST_CONTENT_NAME', 'NA') + ".json"
    k8s = Kubernetes()
    out = k8s.cmd(cmd)
    if 'No resources found' in out:
        log.warning("No resources found when getting node. Cleanup %s" % pod_status_json)
        if not os.path.isfile(pod_status_json):
            log.warning("File %s doesn't exist" % pod_status_json)
        else:
            try:
                os.remove(pod_status_json)
            except Exception as e:
                log.error(str(e))
        return
    rst = {}
    log.info("INFO::Value of init: %s" % init)
    log.info("INFO::Value of stage: %s" % stage)
    log.info("INFO::Value of id: %s" % id)
    if id:
        file_to_open = id + ".json"
    if init and id:
        log.info("Initialize the json file at %s" % file_to_open)
        for node in out:
            log.debug(node)
            A = node.split()
            rst[A[0]] = []
        # Serializing json
        json_object = json.dumps(rst, indent=4)

        with open(file_to_open, "w") as outfile:
            outfile.write(json_object)
    if not init and id and stage:
        pods_status = pod_json_to_dict(pod_status_json)
        res_val = {}
        for node in out:
            A = node.split()
            pod, status = 'NA', 'NA'
            try:
                if A[0] in pods_status:
                    pod = pods_status[A[0]]['pod']
                    status = pods_status[A[0]]['status']
            except Exception as e:
                log.error("%s" % str(e))
            metadata = handler.get_metadata_by_nodes(A[0].split())
            result = "Passed" if A[1] == "Ready" else "Failed"
            data = {
                "starttime": datetime.strptime(starttime, '%Y-%m-%dT%H:%M:%S:%fZ'),
                "test": stage,
                "Result": result,
                "nodestatus": A[1],
                "endtime": datetime.strptime(endtime, '%Y-%m-%dT%H:%M:%S:%fZ'),
                "pool": metadata[0].get("pool", "NA") if metadata else "NA",
                "microcode": metadata[0].get("microcode", "NA") if metadata else "NA",
                "stepping": metadata[0].get("stepping", "NA") if metadata else "NA",
                "qdf": metadata[0].get("qdf", "NA") if metadata else "NA",
                "biosVersion": metadata[0].get("biosVersion", "NA") if metadata else "NA",
                "system-os": metadata[0].get("system-os", "NA") if metadata else "NA",
                "bmcVersion": metadata[0].get("bmcVersion", "NA") if metadata else "NA",
                "pod": pod,
                "pod status": status,
                "JenkinsLink": os.environ.get('BUILD_URL', 'NA')
            }
            res_val[A[0]] = data
        log.info("RET_VAL %s" % res_val)
        push_pod_status_to_es(res_val)


if __name__ == "__main__":
    parser = argparse.ArgumentParser("Get parameters burnin pipeline status update")
    parser.add_argument("-i", "--init", action="store_true", help="Initialize status or not")
    parser.add_argument("-id", "--id", action="store", help="Initialize unique json filename")
    parser.add_argument("-s", "--stage", action="store",
                        help="To store pipeline stages per test case")
    parser.add_argument("-st", "--starttime", action="store",
                        help="To store start time per test case")
    parser.add_argument("-et", "--endtime", action="store", help="To store end time per test case")
    args = parser.parse_args()

    node_status_json(args.init, args.id, args.stage, args.starttime, args.endtime)
    if not args.stage:
        nodes = []
        if not args.init:
            nodes = get_node_list(args.id)
            push_period_to_elasticsearch()
            try:
                if nodes:
                    res = handler.get_cpu(nodes)
                    cpu = res[nodes[0]]
                    if cpu in cfg.project_to_get_report:
                        modify_poolname_to_com()
                        get_report(nodes, cpu)
            except Exception as e:
                log.error("Error when getting summary report: %s" % str(e))
            if ("Burnin" in os.environ['JOB_NAME'] or "Burn-in" in os.environ['JOB_NAME']):
                push_burnin_results(args.init, nodes)
            if cpu in cfg.project_to_get_report:
                _nodes = get_node_by_ns()
                nodes_to_unlabel = [n for n in _nodes.keys() if _nodes[n] == "Ready"]
                k8s_handler.unlabel(nodes_to_unlabel, os.environ.get('KUBECTL_ARGS', None),
                                    os.environ.get('JENKINS_NODE_LABEL', None))
                k8s_handler.del_ns(os.environ.get('KUBECTL_ARGS', None), os.environ.get('NS', None))
