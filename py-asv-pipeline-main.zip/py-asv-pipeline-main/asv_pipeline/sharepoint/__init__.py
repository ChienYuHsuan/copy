import logging
import os
import re
import tempfile
import time
from contextlib import contextmanager

# from datetime import datetime
# import pandas as pd
from office365.runtime.auth.client_credential import ClientCredential
from office365.runtime.client_request_exception import ClientRequestException
# from office365.runtime.http.http_method import HttpMethod
# from office365.runtime.http.request_options import RequestOptions
from office365.sharepoint.client_context import ClientContext

try:
    # Office365-REST-Python-Client==2.3.14
    from office365.sharepoint.sharing.sharing_link_kind import SharingLinkKind
except ImportError:
    # Office365-REST-Python-Client==2.3.15
    from office365.sharepoint.sharing.links.kind import SharingLinkKind

import asv_pipeline.config as cfg

# from openpyxl import load_workbook
# from asv_pipeline.util import get_ww_tpe


class SharePoint(object):

    def __init__(self, site_url=None, sp_client_id: str = cfg.sp_client_id,
                 sp_client_secret: str = cfg.sp_client_secret):
        creds = ClientCredential(sp_client_id, sp_client_secret)
        self.site_url = site_url
        self.ctx = ClientContext(site_url).with_credentials(creds)

    def download(self, url, localdir):
        if not os.path.exists(localdir):
            os.makedirs(localdir)
        download_path = os.path.join(localdir, os.path.basename(url))
        try:
            with open(download_path, "wb") as local_file:
                self.ctx.web.get_file_by_server_relative_path(url).download(
                    local_file).execute_query()
                print("[Ok] file has been downloaded into: {0}".format(download_path))
        except Exception as e:
            print(str(e))
            raise
        return download_path

    """ This should be different for each use case
    def update(self, path):
        if not os.path.isfile(path):
            print("Update - {0} doesn't exist in local path".format(path))
            return
        writer = pd.ExcelWriter(path, engine='openpyxl', mode='a', if_sheet_exists='overlay')
        book = load_workbook(path)
        writer.workbook = book

        weekday = datetime.now().isoweekday()
        sheet_prefix = get_ww_tpe()+'.'+str(weekday)
        sheet = ''
        for k in writer.sheets.keys():
            if k.startswith(sheet_prefix):
                sheet = k
                print("Update Sheet:", sheet)
                break
        current_df = pd.read_excel(path, sheet_name=sheet)
        #print(current_df)
        df = pd.DataFrame({"Node": ["node7", "node8"], "content": ["shc-2", "sandstone-2"]})
        #df = pd.DataFrame({"C1": ["node5", "node6"], "C2": ["shc-2", "sandstone-2"]})
        current_df = pd.concat([current_df, df], ignore_index=True)
        current_df.to_excel(writer, sheet_name=sheet, index=False)
        writer.close()
    """

    def upload(self, local_path, sp_folder):
        """
        Example of sp_path: "Shared Documents/Whitley-Share/S3/SPR-EagleStream/Pre-Sightings-summary"
        """
        if not os.path.isfile(local_path):
            print("Upload - {0} doesn't exist in local path".format(local_path))
            return
        with open(local_path, 'rb') as content_file:
            file_content = content_file.read()

        # list_title = "Documents"
        # target_folder = self.ctx.web.lists.get_by_title(list_title).root_folder
        target_folder = self.ctx.web.get_folder_by_server_relative_url(sp_folder)
        filename = os.path.basename(local_path)
        try:
            target_file = target_folder.upload_file(filename, file_content).execute_query()
            logging.info("File has been uploaded to url: {0}".format(target_file.serverRelativeUrl))
        except Exception as e:
            logging.error("Error when uploading file: %s" % str(e))
            match = re.search(r'[\w.+-]+@[\w-]+\.[\w.-]+', str(e))
            logging.info("File is locked and opened by %(user)s. Make a copy..." %
                         {"user": match.group(0)})
            name = filename.split('.')
            copy_name = "%(name)s-copy-%(datetime)s.xlsx" % {
                "name": name[0],
                "datetime": time.strftime("%Y%m%d-%H%M%S")
            }
            target_file = target_folder.upload_file(copy_name, file_content).execute_query()
            logging.info("[Ok] New file %(name)s has been created" % {"name": copy_name})

    def file_exist(self, path, ww):
        try:
            # file = self.ctx.web.get_file_by_server_relative_url(path).get().execute_query()
            self.ctx.web.get_file_by_server_relative_url(path).get().execute_query()
            return True
        except Exception:
            print("File {0} didn't exist. Go create it.".format(path))
            return False

    """
    (IntelGPT)
    A method called mkdir that takes in a relative_path parameter of type string. Here's what the code does:
    Attempts to get the folder by the provided server-relative path using the SharePoint REST API and execute the query.
    """

    def mkdir(self, relative_path: str):
        try:
            self.ctx.web.get_folder_by_server_relative_url(relative_path).get().execute_query()
            logging.info("Relative folder '{0}' is found".format(relative_path))
        except ClientRequestException as e:
            logging.error(e)
            if e.response.status_code == 404:
                print("Relative folder '{0}' not found and will create one".format(relative_path))
                try:
                    self.ctx.web.ensure_folder_path(relative_path).get().select(
                        ["ServerRelativePath"]).execute_query()
                except Exception as e:
                    logging.error(e)
                    raise
            else:
                raise ValueError(e.response.text)

    def get_shared_link(self, filename):
        file = self.ctx.web.get_file_by_server_relative_url(filename).get().select(
            "SharedLink").execute_query()

        # Share a file link
        share_link = file.share_link(link_kind=SharingLinkKind.OrganizationView)
        self.ctx.execute_query()
        logging.debug(share_link.value.sharingLinkInfo.Url)
        return share_link.value.sharingLinkInfo.Url

    @contextmanager
    def download_from_shared_link(self, sharing_link_url):
        download_path = os.path.join(os.getcwd(), tempfile.mkstemp()[1])
        logging.info(download_path)
        try:
            with open(download_path, "wb") as local_file:
                file = (self.ctx.web.get_file_by_guest_url(sharing_link_url).download(
                    local_file).execute_query())
                logging.info(file)
            yield download_path
            logging.info(f"close {download_path}")
        finally:
            os.remove(download_path)
            logging.info(f" delete {download_path}")

        print("[Ok] file has been downloaded into: {0}".format(download_path))


class SharePointFactory(object):

    @staticmethod
    def build(
        sp_site: str = cfg.sp_site,
        sp_client_id: str = cfg.sp_client_id,
        sp_client_secret: str = cfg.sp_client_secret,
    ) -> SharePoint:
        return SharePoint(sp_site, sp_client_id, sp_client_secret)
