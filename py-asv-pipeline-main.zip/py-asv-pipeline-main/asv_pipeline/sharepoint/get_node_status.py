import argparse
import logging
import os
import sys
from datetime import datetime, timedelta

import pandas as pd
import pytz
from openpyxl import load_workbook
from openpyxl.styles import Alignment

import asv_pipeline.clusterscope.poolname as cspoolname
import asv_pipeline.config as cfg
from asv_pipeline.clusterscope import ClusterScope, handler
from asv_pipeline.k8s import Kubernetes
from asv_pipeline.rf.handler import get_dimm0_dimm1
from asv_pipeline.sharepoint.report_util import get_bkc_by_microcode_bios
from asv_pipeline.util import parse_time_for_clusterscope, str2labels

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

FOLDER = ''
FILE_NEW = "%(cpu)s_Node_Status_%(now)s.xlsx"
GET_NODES = "kubectl --kubeconfig=%(k8sconfig)s --insecure-skip-tls-verify get nodes %(node)s --show-labels"
GET_PODS_FROM_NODE_NS = "kubectl --kubeconfig=%(k8sconfig)s --insecure-skip-tls-verify get pods --field-selector spec.nodeName=%(node)s -n %(namespace)s"

QDF_CATGORY_RAW = {
    'A0 VIS': ['Q37F', 'Q37H', 'Q3BF', 'Q3BK', 'Q3BA', 'Q3B3', 'Q3BE', 'Q3J2'],
    'A0 ES1': ['Q3RZ', 'Q3PE', 'Q3RF', 'Q3PB', 'Q3PH', 'Q3PF', 'Q3PC', 'Q3PD'],
    'A0 ES2': ['Q46B', 'Q46C', 'Q46D', 'Q46E', 'Q46Q', 'Q46R'],
    'B0 EVS': ['Q450', 'Q451', 'Q452', 'Q453', 'Q44Y', 'Q44Z', 'Q43W'],
    'C0 VIS 2S': ['Q44J'],
    'C0 VIS 1S': ['Q44P'],
    'C0 QS META': ['Q4AS'],
    'C0 QS 2S': ['Q4VV', 'Q4W2', 'Q4W3', 'Q4VX', 'Q4VY', 'Q4WS', 'Q4VW'],
    'C0 QS 1S': ['Q4VZ'],
    'C0 Dell ES2': ['Q4AT'],
    'PRQ': ['RPFX', 'RPFU', 'RPFZ', 'RPG2', 'RPFY', 'RPFW', 'RPFV', 'RPG3', 'Q47N'],
    'C0 VIS': ['Q4UM', 'Q4UP', 'Q4UU', 'Q4UV'],
    'C0 ES2': ['Q4XM', 'Q4XN', 'Q4XP', 'Q4XQ'],
    'C1 VIS': ['Q5EV', 'Q5EW', 'Q5EX', 'Q5EY', 'Q5EZ'],
    'C5 QS': ['Q5ZD'],
    'C4 PRQ': ['RVEX']
}

# Create a reverse lookup dictionary for items to categories
QDF_CATGORY = {item: category for category, items in QDF_CATGORY_RAW.items() for item in items}


def get_qdf_category_by_qdf(item):
    return QDF_CATGORY.get(item, 'unknown')


def create_file(filename, detail_sheet_name, count_sheet_name):
    cwd = os.getcwd()
    log.info("create sheet file with filename: {}".format(filename))
    sheet_path = os.path.join(cwd, filename)
    try:
        writer = pd.ExcelWriter(sheet_path, engine='openpyxl')
    except Exception as e:
        log.error(str(e))
        sys.exit(1)

    pd.set_option('display.max_colwidth', None)
    df_detail = pd.DataFrame({
        'Node': [],
        'SKU': [],
        'Location': [],
        'Pool': [],
        'Pool Updated Time': [],
        'Pool Updated User': [],
        'Microcode': [],
        'BKC': [],
        'Stepping': [],
        'QDF': [],
        'QDF_Catgo': [],
        'DIMM Vendor': [],
        'Bios Version': [],
        'OS': [],
        'OS Distrubution': [],
        'BMC Version': [],
        'Node Status': [],
        'LABELS': [],
        'PODS': []
    })

    df_count = pd.DataFrame()

    df_detail.to_excel(writer, sheet_name=detail_sheet_name, index=False)
    df_count.to_excel(writer, sheet_name=count_sheet_name, index=False)

    writer.close()
    return sheet_path


def get_nodelabel_podlist(node, cputype):

    try:
        k8s = Kubernetes()
        if "SRF" in cputype:
            k8sconfig_list = [cfg.kubeconfigs['srf']]
        elif "GNR" in cputype:
            k8sconfig_list = [cfg.kubeconfigs['bhs']]
        elif "CWF" in cputype:
            k8sconfig_list = [cfg.kubeconfigs['cwf'], cfg.kubeconfigs['bhs']]
        elif cputype in ["EMR", "SPR", "SKX", "CLX", "ICX"]:
            k8sconfig_list = [cfg.kubeconfigs['zp31']]
        str_labellist, str_podlist = "", ""

        for k8sconfig in k8sconfig_list:
            rst_label = k8s.cmd(GET_NODES % {"k8sconfig": k8sconfig, "node": node})

            if len(rst_label) > 1 and any("denied" not in s for s in rst_label):
                labels = str2labels((rst_label[1].split()[5]))

                labellist, podlist = [], []
                for x in labels:
                    temp = x.split("=")
                    if (any(x in temp[0]
                            for x in ['spr', 'emr', 'gnr', 'srf', 'cwf', 'skx', 'clx', 'icx']) and
                            temp[1] == "true"):
                        ns = temp[0]
                        labellist.append(ns)

                        rst_pod = k8s.cmd(GET_PODS_FROM_NODE_NS % {
                            "k8sconfig": k8sconfig,
                            "node": node,
                            "namespace": ns
                        })

                        if len(rst_pod) > 1:
                            for po in rst_pod[1:]:
                                podlist.append(po.split(" ")[0])

                str_labellist = (','.join(labellist)) if labellist is not None else ''
                str_podlist = (','.join(podlist)) if podlist is not None else ''

        return str_labellist, str_podlist

    except Exception as e:
        log.error(str(e))
        return ""


def get_node_details(cslist, args):
    nodeDetailsList = []
    nodepoolCountbyBKC = {}
    CPUTYPE = str(args.cpu).upper()
    query_pool_names = [CPUTYPE]
    nodeTotal = 0
    count = 1

    for cs in cslist:
        ret = cs.instant_query_by_pool(query_pool_names)
        nodeTotal += len(ret)

        for _p in ret:
            name, location, pool, microcode, stepping = str.strip(
                _p.get("name")), _p.get("location"), str.strip(_p.get("pool")), str.strip(
                    _p.get("microcode")), _p.get("stepping")
            qdf, biosVersion, os, osVersion, bmcVersion = str.strip(str(_p.get("qdf"))), _p.get(
                "biosVersion"), _p.get("os"), _p.get("osVersion"), _p.get("bmcVersion")

            log.info("progress:" + str(count) + "/" + str(nodeTotal) + " --  " + name)

            defaultSKU = handler.get_sku(name, _p.get("0"), _p.get("1"))
            qdf_catgo = get_qdf_category_by_qdf(qdf)

            pool_last_updated_time = ""
            pool_last_updated_user = ""

            if args.poollatestupdate:
                start_date = (datetime.utcnow() - timedelta(14)).strftime('%Y-%m-%d')
                curr_date = (datetime.utcnow() + timedelta(1)).strftime('%Y-%m-%d')

                try:
                    node_action_history = handler.get_action_history_by_node(
                        name, 1, start_date, curr_date, 60)
                    if node_action_history and len(node_action_history) > 0:
                        pool_last_updated_user = node_action_history[0]['user']
                        pool_last_updated_time = parse_time_for_clusterscope(
                            node_action_history[0]['timestamp'], pytz.timezone("Asia/Kolkata"))
                    else:
                        log.info("node {} doesn't have action history in 2 weeks,".format(name))
                except Exception as e:
                    log.error("get pool history error, node = {} , ".format(name) + str(e))

            dimmVendor = ""
            memory_rst = cs.get_memory_detail_by_nodename(location, name)
            try:
                if len(memory_rst) != 0:
                    dimmVendor = memory_rst[0]['Manufacturer']
                else:
                    dimm0, dimm1 = get_dimm0_dimm1(name)
                    dimmVendor = dimm0.get("Manufacturer").strip()
            except Exception as e:
                logging.error("get dimminfo error, node = {} , ".format(name) + str(e))

            nodeStatus = ""
            try:
                nodeStatus = cspoolname.parse(pool).state
            except Exception as e:
                log.error("poolname parsing error, node = {} , ".format(name) + str(e))

            labellist, podlist = "", ""
            try:
                labellist, podlist = get_nodelabel_podlist(name, CPUTYPE)
            except Exception as e:
                log.error("get node label or pod error, node = {} , ".format(name) + str(e))

            bkc = ""
            try:
                bkc = get_bkc_by_microcode_bios(microcode, biosVersion, CPUTYPE)
            except Exception as e:
                log.error("cannot get bkc from sharepoint, node = {} , ".format(name) + str(e))

            data = [
                name, defaultSKU, location, pool, pool_last_updated_time, pool_last_updated_user,
                microcode, bkc, stepping, qdf, qdf_catgo, dimmVendor, biosVersion, os, osVersion,
                bmcVersion, nodeStatus, labellist, podlist
            ]
            nodeDetailsList.append(data)

            if microcode not in nodepoolCountbyBKC.keys():
                nodepoolCountbyBKC[microcode] = [pool]
            else:
                nodepoolCountbyBKC[microcode] += [pool]

            count += 1

    return nodeDetailsList, nodepoolCountbyBKC, nodeTotal


def get_node_counts_by_bkc(nodeTotal, nodepoolCountbyBKC):
    nodeCountBKC = {}
    globalPoolMap = {
        "EXC_ALL": 0,
        "EXC_MAIN": 0,
        "EXC_BURNIN": 0,
        "EXC_DPMO": 0,
        "EXC_OTHERS": 0,
        "NOTREADY": 0,
        "COMPLETE": 0,
        "RERUN": 0,
        "READY": 0,
        "DEBUG": 0,
        "PLN_DEV": 0,
        "INF_EVF": 0,
        "TOTAL": nodeTotal
    }

    for key in nodepoolCountbyBKC.keys():
        poolList = nodepoolCountbyBKC[key]
        poolmap = {
            "EXC_ALL": 0,
            "EXC_MAIN": 0,
            "EXC_BURNIN": 0,
            "EXC_DPMO": 0,
            "EXC_OTHERS": 0,
            "NOTREADY": 0,
            "COMPLETE": 0,
            "RERUN": 0,
            "READY": 0,
            "DEBUG": 0,
            "PLN_DEV": 0,
            "INF_EVF": 0,
            "TOTAL": len(poolList)
        }

        for poolname in poolList:
            try:
                formatpoolname = cspoolname.parse(poolname)
                if formatpoolname.state == "EXC":
                    poolmap["EXC_ALL"] += 1
                    globalPoolMap["EXC_ALL"] += 1
                    if "MAIN" in formatpoolname.test_description:
                        poolmap["EXC_MAIN"] += 1
                        globalPoolMap["EXC_MAIN"] += 1
                    elif "BURNIN" in formatpoolname.test_description:
                        poolmap["EXC_BURNIN"] += 1
                        globalPoolMap["EXC_BURNIN"] += 1
                    elif "DPMO" in formatpoolname.test_description:
                        poolmap["EXC_DPMO"] += 1
                        globalPoolMap["EXC_DPMO"] += 1
                    else:
                        poolmap["EXC_OTHERS"] += 1
                        globalPoolMap["EXC_OTHERS"] += 1
                elif formatpoolname.state == "NTR":
                    poolmap["NOTREADY"] += 1
                    globalPoolMap["NOTREADY"] += 1
                elif formatpoolname.state == "COM":
                    poolmap["COMPLETE"] += 1
                    globalPoolMap["COMPLETE"] += 1
                elif formatpoolname.state == "RER":
                    poolmap["RERUN"] += 1
                    globalPoolMap["RERUN"] += 1
                elif formatpoolname.state == "RDY":
                    poolmap["READY"] += 1
                    globalPoolMap["READY"] += 1
                elif formatpoolname.state == "DBG":
                    poolmap["DEBUG"] += 1
                    globalPoolMap["DEBUG"] += 1
                elif formatpoolname.state == "DEV":
                    poolmap["PLN_DEV"] += 1
                    globalPoolMap["PLN_DEV"] += 1
                elif formatpoolname.asignto == "INF":
                    poolmap["INF_EVF"] += 1
                    globalPoolMap["INF_EVF"] += 1
            except Exception as e:
                log.error("poolname parsing error, node = {} , ".format(poolname) + str(e))

        nodeCountBKC[key] = poolmap

    nodeCountBKC["TOTAL"] = globalPoolMap
    log.info(nodeCountBKC)
    return nodeCountBKC


def get_latest_node_status(path, detail_sheet_name, count_sheet_name, args):
    try:
        writer = pd.ExcelWriter(path, engine='openpyxl', mode='a', if_sheet_exists='overlay')
    except Exception as e:
        log.error(str(e))
        sys.exit(1)

    # Get update sheet
    book = load_workbook(path)
    writer.workbook = book
    current_df_detail = pd.read_excel(path, sheet_name=detail_sheet_name)
    current_df_count = pd.read_excel(path, sheet_name=count_sheet_name)

    CPUTYPE = str(args.cpu).upper()
    cslist = []
    if "SRF" in CPUTYPE or "GNR" in CPUTYPE:
        cslist.append(ClusterScope(cfg.clusterscopes["bhs"], timeout=360))
    if "CWF" in CPUTYPE:
        cslist.append(ClusterScope(cfg.clusterscopes["cwf"], timeout=360))
        cslist.append(ClusterScope(cfg.clusterscopes["cwf-fl31"], timeout=360))
    if CPUTYPE in ["EMR", "SPR", "SKX", "CLX", "ICX"]:
        cslist.append(ClusterScope(cfg.clusterscopes["zp31"], timeout=360))
    if not cslist:
        log.error("unsupported cputype {}".format(CPUTYPE))
        sys.exit(1)

    # Get node detail from clusterscope
    nodeDetailsList, nodepoolCountbyBKC, nodeTotal = get_node_details(cslist, args)
    df = pd.DataFrame(
        nodeDetailsList, columns=[
            'Node', 'SKU', 'Location', 'Pool', 'Pool Updated Time', 'Pool Updated User',
            'Microcode', 'BKC', 'Stepping', 'QDF', 'QDF_Catgo', 'DIMM Vendor', 'Bios Version', 'OS',
            'OS Distrubution', 'BMC Version', 'Node Status', 'LABELS', 'PODS'
        ])
    current_df_detail = pd.concat([current_df_detail, df], ignore_index=True)

    # Get node count
    nodeCountBKC = get_node_counts_by_bkc(nodeTotal, nodepoolCountbyBKC)

    df = pd.DataFrame.from_dict(nodeCountBKC, orient='index')
    current_df_count = pd.concat([current_df_count, df], ignore_index=False)

    # transfer dataframe to excel
    current_df_detail.to_excel(writer, sheet_name=detail_sheet_name, index=False)
    current_df_count.to_excel(writer, sheet_name=count_sheet_name, index=True)

    # Adjust column width and alignment
    for column in current_df_detail:
        column_length = max(current_df_detail[column].astype(str).map(len).max(), len(column))
        col_idx = current_df_detail.columns.get_loc(column)
        writer.sheets[detail_sheet_name].column_dimensions[chr(65 +
                                                               col_idx)].width = column_length + 2

    leftAlignment = Alignment(horizontal="left", vertical="center", wrapText=True)
    for col in writer.sheets[count_sheet_name].columns:
        for cell in col:
            cell.alignment = leftAlignment
    writer.sheets[count_sheet_name].column_dimensions['A'].width = 15
    writer.sheets[count_sheet_name].column_dimensions['B'].width = 15
    writer.sheets[count_sheet_name].column_dimensions['C'].width = 15
    writer.sheets[count_sheet_name].column_dimensions['D'].width = 15
    writer.sheets[count_sheet_name].column_dimensions['E'].width = 15
    writer.sheets[count_sheet_name].column_dimensions['F'].width = 15
    writer.sheets[count_sheet_name].column_dimensions['G'].width = 15
    writer.sheets[count_sheet_name].column_dimensions['H'].width = 15

    writer.close()


if __name__ == "__main__":

    log.info("Start get node latest status sheet")

    parser = argparse.ArgumentParser("Start get node latest status sheet")
    parser.add_argument(
        "-p", "--poollatestupdate", required=False, action="store_true",
        help="report will shows the columna of poolname latest update time and user")
    parser.add_argument("-c", "--cpu", required=True, default="SRF-SP", help="which cpu?")
    args = parser.parse_args()

    now = datetime.utcnow().strftime("%Y%m%d-%I%M%S")
    filename = FILE_NEW % {"now": now, "cpu": str(args.cpu).upper()}
    detail_sheet_name = "detail"
    count_sheet_name = "count"
    path = create_file(filename, detail_sheet_name=detail_sheet_name,
                       count_sheet_name=count_sheet_name)
    get_latest_node_status(path, detail_sheet_name, count_sheet_name, args)
