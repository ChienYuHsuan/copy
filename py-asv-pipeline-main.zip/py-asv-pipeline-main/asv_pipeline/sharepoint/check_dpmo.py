import json
import logging
import os
import sys
from copy import deepcopy
from datetime import date, datetime, timedelta

import pandas as pd
import pytz
import requests
from openpyxl import load_workbook

import asv_pipeline.clusterscope.handler as handler
import asv_pipeline.config as cfg
from asv_pipeline.auto_messages import (TABLE_TPL, create_table_row, create_text_block,
                                        send_teams_message_with_body)
from asv_pipeline.clusterscope import ClusterScope
from asv_pipeline.es import ES
from asv_pipeline.sharepoint import SharePoint
from asv_pipeline.sharepoint.report_util import get_bkc_detail
from asv_pipeline.sharepoint.update_notready import create_file
from asv_pipeline.tasks.elasticsearch.es_eventrouter import get_nrn_time
from asv_pipeline.util import get_cluster_by_naming, get_ww_tpe

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)

FOLDER = "Shared Documents/NotReady Nodes Reporting - "
FILE = "NOTREADY_NODE_%(cpu)s_%(ww)s.xlsx"


def update(path, cpu, ww, rst, creation_time):
    if not os.path.isfile(path):
        print("Update - {0} doesn't exist in local path".format(path))
        return
    try:
        writer = pd.ExcelWriter(path, engine='openpyxl', mode='a', if_sheet_exists='overlay')
    except Exception as e:
        log.error(str(e))
        sys.exit(1)
    book = load_workbook(path)
    writer.workbook = book

    weekday = datetime.now(pytz.timezone('Asia/Taipei')).isoweekday()
    sheet_prefix = ww + '.' + str(weekday)
    sheet = ''
    for k in writer.sheets.keys():
        if k.startswith(sheet_prefix):
            sheet = k
            log.info("Update Sheet: %s" % sheet)
            break

    current_df = pd.read_excel(path, sheet_name=sheet)

    for key, val in rst.items():
        meta = handler.get_metadata_by_nodes([key])
        nrn_time = get_nrn_time(key)
        if meta:
            df = pd.DataFrame({
                "Node": [key],
                "content": [val['bkc_name']],
                "Initial Pool": [meta[0].get('pool', 'NA')],
                "QDF": [meta[0].get('qdf', 'NA')],
                "stepping": [meta[0].get('stepping', 'NA')],
                "Socket Count":
                [handler.get_sku(key, meta[0].get('0', 'NA'), meta[0].get('1', 'NA'))],
                "TTF": [val['repetition']],
                "BKC": [get_bkc_detail(meta[0])],
                "Last test-Subtest": [val['reset_type']],
                'Creation Time': [creation_time],
                "NRN timestamp": [nrn_time]
            })
        else:
            log.warning("%s: No metadata from ClusterScope" % key)
            df = pd.DataFrame({
                "Node": [key],
                "content": [val['bkc_name']],
                "TTF": [val['repetition']],
                "Last test-Subtest": [val['reset_type']],
                'Creation Time': [creation_time],
                "NRN timestamp": [nrn_time]
            })
        current_df = pd.concat([current_df, df], ignore_index=True)

    current_df.to_excel(writer, sheet_name=sheet, index=False)
    writer.close()


def check_dpmo(hour, min):
    res_dpmo = {}
    end = datetime.utcnow()
    start = end - timedelta(hours=int(hour), minutes=int(min))
    try:
        es = ES(url=cfg.es_endpoints['flex'], name=cfg.es_username['flex'],
                password=cfg.es_password['flex']).index("reset_test_index")
    except Exception as e:
        log.error(str(e))
        sys.exit(1)

    body = es.oneOf('log', [
        'Error executing on node', 'Error evaluating on node',
        'Error, unexpected amount of devices/speed detected'
    ]).range(start, end, timestamp="timestamp").build()
    try:
        docs = es.execute(timeout=600, payload=body)
    except Exception as e:
        log.error(str(e))
        sys.exit(1)

    for doc in docs:
        inner_data = {
            'timestamp': '-',
            'reset_type': '-',
            'repetition': '-',
            'log': '-',
            'bkc_name': '-',
            'target': '-'
        }
        host = doc['_source']['hostname']

        inner_data['timestamp'] = doc['_source']['timestamp']
        inner_data['reset_type'] = doc['_source']['reset_type']
        inner_data['repetition'] = doc['_source']['repetition']
        inner_data['log'] = doc['_source']['log']
        inner_data['bkc_name'] = doc['_source']['bkc_name']

        if 'target' in doc['_source']:
            inner_data['target'] = doc['_source']['target']
        if host not in res_dpmo:
            res_dpmo[host] = inner_data
    if not docs:
        log.info("No error in last cycle")

    log.info("res_dpmo %s" % res_dpmo)
    return res_dpmo


def filter_node_by_poolname(dpmo, poolname):
    if dpmo:
        for node, pool in poolname.items():
            if pool.state != 'EXC':
                log.info("%s pool name state is %s. Skip it." % (node, pool.state))
                del dpmo[node]
            elif pool.asignto == 'IVE':
                log.info("%s is assigned to IVE. Skip it." % node)
                del dpmo[node]
            else:
                if pool.cpu.startswith('SRF') or pool.cpu.startswith('CWF'):
                    dpmo[node]['cpu'] = pool.cpu
                else:
                    dpmo[node]['cpu'] = pool.cpu[0:3]


def update_poolname(dpmo, poolname, cpu):
    _cpu = 'srf-sp' if cpu == 'srf' else cpu
    if dpmo:
        locations = handler.get_location_by_nodes(dpmo.keys())
        for node, pool in poolname.items():
            if node in dpmo:
                if dpmo[node]['cpu'] != _cpu.upper():
                    continue
                owner = cfg.triage_owner[cpu]['idsid']
                if cpu in ('spr', 'emr') and pool.subclustername == 'UOE':
                    owner = 'AAZAMUDI'
                elif cpu == 'gnr' and 'AWS' not in pool.test_description:
                    owner = 'ANJALIYA'
                target = "%s_%s_%s_%s_%s_%s_%s" % (pool.cpu, pool.stepping, 'PIV', 'NTR',
                                                   pool.subclustername,
                                                   f"{pool.test_description}-NOTREADY", owner)
                log.info("Target pool name for node %s: %s" % (node, target))
                try:
                    pool.update_node(node, locations[node]).update_pool(target)
                    cs = ClusterScope(cfg.clusterscopes[get_cluster_by_naming(node)])
                    handler.update_pool_by_names(cs, pool)
                except Exception as e:
                    log.error("%s, %s" % (node, str(e)))
                    continue


def get_dpmo_list(cpu, hour, min):
    log.info("Start checking DPMO results for %s" % cpu.upper())
    res_dpmo = check_dpmo(hour, min)

    _nodes = res_dpmo.keys()
    if res_dpmo and _nodes:
        res, noassigned = handler.get_pool_by_nodes(_nodes)
        filter_node_by_poolname(res_dpmo, res)
        update_poolname(res_dpmo, res, cpu)

    # Convert the dictionary to a pandas DataFrame
    df = pd.DataFrame.from_dict(res_dpmo, orient='index')

    if cpu == 'srf':
        cpu = 'srf-sp'

    # Group the data by the 'cpu' field
    res_by_group = {}
    try:
        grouped = df.groupby('cpu', group_keys=True)
        group = grouped.get_group(cpu.upper())
        res_by_group = group.to_dict(orient='index')

        log.info("CPU: %s" % cpu)
        log.info("res_by_group %s" % res_by_group)

    except Exception as e:
        log.warning("Issue happens during group data: %s" % str(e))

    return res_by_group


def update_dpmo_sheet(path, cpu, res_by_group, creation_time):
    log.info("Start updating DPMO results for %s" % cpu.upper())
    sp = SharePoint(cfg.sp_site_notready)
    ww = get_ww_tpe()

    _cpu = 'srf-sp' if cpu == 'srf' else cpu
    if not path:
        # Need a relative path for the first parameter
        url = '/' + '/'.join(cfg.sp_site_notready.split('/')[-2:]) + '/' + FOLDER + _cpu.upper()
        filename = FILE % {"cpu": _cpu.upper(), "ww": ww}
        path = sp.download(url + "/" + filename, os.getcwd())

        if not path:
            log.info("File doesn't exist in SharePoint. Go create a file")
            path = create_file(_cpu, ww)

    update(path, _cpu, ww, res_by_group, creation_time)
    sp.upload(path, FOLDER + _cpu.upper())


def send_teams_messages_dpmo(res, cpu):
    dict_json = json.dumps(res, indent=4)
    dict_json = dict_json.strip("{}")
    log.debug("send_teams_messages %s" % res)
    text = ""
    if not res:
        text = "### DPMO results for %s: \n\n```\nNo error in last cycle\n```" % cpu.upper()
    else:
        text = f"### DPMO results for %s: \n\n```json\n{dict_json}\n```" % cpu.upper()
    payload = {
        "@type": "MessageCard",
        "@context": "http://schema.org/extensions",
        "markdown": True,
        "text": text
    }
    response = requests.post(cfg.teams_webhook_url_dpmo[cpu], data=json.dumps(payload))

    if response.status_code == 200:
        log.info("Send results to DPMO channel successfully")
    else:
        log.warning("Error when sending reporting:", response.status_code)


def send_dpmo_results_to_teams(res, cpu):
    body = [create_text_block(f"DPMO results for {cpu.upper()}")]

    if res:
        for node, data in res.items():
            body.append(create_text_block(node, size=None, weight="bolder", style=None))

            t = deepcopy(TABLE_TPL)
            for d, val in data.items():
                row = create_table_row(d, val)
                t['rows'].append(row)

            body.append(t)
    else:
        body.append(
            create_text_block("No NotReady nodes since last reporting.", size=None, weight=None,
                              style=None))

    send_teams_message_with_body(body, cpu, type='dpmo')


def send_dpmo_completion_to_teams(nodes, cpu):
    body = [create_text_block(f"DPMO Completion Notifications - {cpu.upper()}")]

    res = {}
    pools, _ = handler.get_pool_by_nodes(nodes)
    for node, p in pools.items():
        res[node] = str(p)

    for node, pool in res.items():
        t = deepcopy(TABLE_TPL)
        row = create_table_row(node, pool)
        t['rows'].append(row)

        body.append(t)

    send_teams_message_with_body(body, cpu, type='dpmo_comp')


def push_dpmo_to_es(res, creation_time):
    body = []
    for node, val in res.items():
        d = {}
        nrn_time = get_nrn_time(node)
        d.update({
            'host': node,
            'namespace': val['bkc_name'],
            'test': val['reset_type'],
            'status': 'NA',
            'age': 'NA',
            'timestamp': creation_time,
            'NRN timestamp': nrn_time
        })
        body += [d]
    es = ES(url=cfg.es_endpoints['flex'], name=cfg.es_username['flex'],
            password=cfg.es_password['flex'])
    try:
        es.bulk(body, cfg.idx_nrn_status % {"date": date.today().strftime('%Y.%m.%d')})
    except Exception as e:
        log.error("Error raised during pushing DPMO data to ES: %s" % str(e))
