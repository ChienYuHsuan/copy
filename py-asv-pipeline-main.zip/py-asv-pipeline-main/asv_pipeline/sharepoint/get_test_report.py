import argparse
import logging
import os
import sys
from datetime import datetime, timedelta, timezone

import pandas as pd
import yaml
from openpyxl.styles import Alignment, Border, PatternFill, Side
from openpyxl.utils import get_column_letter

import asv_pipeline.config as cfg
from asv_pipeline.sharepoint import SharePoint
from asv_pipeline.sharepoint.report_util import get_url
from asv_pipeline.tasks.elasticsearch.es_tests import get_test_summary
from asv_pipeline.tasks.mem_tests import query_amt, query_os_margin, query_rmt
from asv_pipeline.util import get_cluster_by_naming

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

CYCLE = ["sandstone-rf-warm", "sandstone-rf-cold", "ive-povray-rf-cold"]
MEM = ["RMT", "OMT", "AMT"]

TEST_LIST = {
    "Burnin": "burnin.yaml",
    "BURNIN": "burnin.yaml",
    "PNP": "pnp.yaml",
    "Main1": "main1.yaml",
    "Main2": "main2.yaml",
    "FuseGo": "fusego.yaml",
    "ShipGo": "shipgo.yaml",
    "BKCStage1": "bkc_stage1.yaml",
    "BKCStage2": "bkc_stage2.yaml",
    "CXLRPB": "cxl_rpb.yaml",
    "CXLMontage": "cxl_montage.yaml",
    "CE": "CE.yaml",
    "RAS": "ras.yaml",
    "SGXTDX": "sgxtdx.yaml",
    "HBMCACHE": "hbmcache.yaml",
    "HBMONLY": "hbmonly.yaml",
    "MainMCC": "main_mcc.yaml",
}


def download_test_from_sp(cpu, test_filename):
    log.info("Start downloading test_list from SharePoint")
    try:
        sp = SharePoint(cfg.sp_site)
        dlfile = sp.download(get_url() + "/" + cpu + "/TestSummaryList/" + test_filename,
                             os.getcwd())
        if dlfile:
            try:
                with open(dlfile, 'r') as f:
                    return yaml.safe_load(f)
            except yaml.YAMLError as err:
                log.error(err)
                raise
    except Exception as e:
        log.error(e)
        raise
    finally:
        try:
            os.remove(os.path.join(os.getcwd(), dlfile))
        except Exception as e:
            log.error(str(e))
    return None


def create_df(index, columns):
    pd.set_option('display.max_colwidth', None)
    df = pd.DataFrame(index=index, columns=columns)
    return df


def save_df(df, sheet_name, filename):
    log.info("create sheet file with filename: {}".format(filename))
    try:
        if os.path.isfile(f'./{filename}'):
            writer = pd.ExcelWriter(f'./{filename}', engine='openpyxl', mode='a',
                                    if_sheet_exists='new')
        else:
            writer = pd.ExcelWriter(f'./{filename}', engine='openpyxl')
    except Exception as e:
        log.error(f'There is something wrong when writing excel with {e}.')
    df.to_excel(writer, sheet_name=sheet_name, merge_cells=True)

    try:
        if "count" in sheet_name:
            writer.sheets[sheet_name].column_dimensions['B'].width = 15
            for column in range(ord('C'), ord('W')):
                column_letter = chr(column)
                writer.sheets[sheet_name].column_dimensions[column_letter].width = 20
        else:
            # Adjust column width and alignment
            for column in df:
                column_length = max(df[column].astype(str).map(len).max(), len(column[1]))
                col_idx = df.columns.get_loc(column)

                if column[1] == "duration":
                    writer.sheets[sheet_name].column_dimensions[get_column_letter(col_idx +
                                                                                  2)].width = 10
                else:
                    writer.sheets[sheet_name].column_dimensions[get_column_letter(
                        col_idx + 2)].width = column_length + 4
    except Exception as e:
        log.error(f'There is something wrong when adjust excel format with {e}.')

    writer.sheets[sheet_name].column_dimensions['A'].width = 16

    # Cell Format
    centerAlignment = Alignment(horizontal="center", vertical="center", wrapText=True)
    thin_border = Side(border_style='thin', color='000000')
    border = Border(left=thin_border, right=thin_border, top=thin_border, bottom=thin_border)

    # Condition bg color
    passed_fill = PatternFill(start_color="E2EFDA", end_color="E2EFDA",
                              fill_type="solid")  # PASSED, green
    failed_fill = PatternFill(start_color="FDCDDC", end_color="FDCDDC",
                              fill_type="solid")  # FAILED, light red
    unknown_fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC",
                               fill_type="solid")  # UNKNOWN, light yellow
    aborted_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2",
                               fill_type="solid")  # ABORTED, light blue

    for col in writer.sheets[sheet_name].columns:
        for cell in col:
            cell.alignment = centerAlignment
            cell.border = border
            if "PASSED" in str(cell.value) or "Pass" in str(cell.value):
                cell.fill = passed_fill
            elif "FAILED" in str(cell.value):
                cell.fill = failed_fill
            elif "UNKNOWN" in str(cell.value):
                cell.fill = unknown_fill
            elif "ABORTED" in str(cell.value):
                cell.fill = aborted_fill
    writer.close()


def get_file_content(filename):
    with open(filename, "r") as file:
        lines = [line.strip() for line in file]

    return lines


def get_mem_result(sut, testname, day, start, end):
    if day != 0:
        log.info("To get report since last %d days" % day)
        now = datetime.now(tz=timezone.utc)
        now_delta = now - timedelta(days=day)

        start = now_delta.strftime('%a %d %b %Y %I:%M:%S %p %Z')
        end = now.strftime('%a %d %b %Y %I:%M:%S %p %Z')

    os.environ['START'] = start
    os.environ['END'] = end

    rst = {}
    rst[sut] = True
    cluster = get_cluster_by_naming(sut)

    latest_result = None
    try:
        if testname == "RMT":
            res_rmt = query_rmt(cluster, rst)
            latest_result = res_rmt[sut]["status"]
        elif testname == "OMT":
            res_omt = query_os_margin(rst)
            latest_result = res_omt[sut]["results"]
        elif testname == "AMT":
            res_amt = query_amt(cluster, rst, 'sol_raw-')
            latest_result = res_amt[sut]["results"]
    except Exception as e:
        log.error("cannot get memory test result, node = {} , ".format(sut) + str(e))

    return latest_result


def get_data(day, start, end, ns=None):
    is_fields = None
    if ns:
        is_fields = [("kubernetes.namespace_name", ns)]

    query_rst = get_test_summary(cluster="bhs", day=day, start=start, end=end, is_fields=is_fields)

    if query_rst and len(query_rst) > 0:
        result = []
        for res in query_rst:
            data = res['_source']
            result.append(data)

        df = pd.json_normalize(result)

        return df
    else:
        return None


def get_result(type, df, suts, testname, ns, day, start, end):
    if type == "latest":
        if ns is not None:
            df = df[(df['kubernetes.host'].isin(suts)) & (df['kubernetes.namespace_name'] == ns)]
        else:
            df = df[(df['kubernetes.host'].isin(suts))]

        index = pd.Index(suts, name='Node')
        columns = pd.MultiIndex.from_product([testname, ['result', 'duration']],
                                             names=['Test Name', 'Test Summary'])
        df_latest = create_df(index=index, columns=columns)

        for sut in suts:
            log.info(f"current mode is {sut}")
            for test in testname:
                if test in MEM:
                    MEM_result = get_mem_result(sut, test, day, start, end)
                    df_latest.loc[sut, (test, 'result')] = MEM_result
                    df_latest.loc[sut, (test, 'duration')] = "NA"
                elif df[(df['kubernetes.host'] == sut)
                        & (df['kubernetes.labels.name'] == test)]['result'].empty & df[
                            (df['kubernetes.host'] == sut)
                            & (df['kubernetes.labels.name'] == test)]['duration'].empty:
                    df_latest.loc[sut, (test, 'result')] = "NA"
                    df_latest.loc[sut, (test, 'duration')] = "NA"
                else:
                    result_list = list(df[(df['kubernetes.host'] == sut)
                                          & (df['kubernetes.labels.name'] == test)]['result'])
                    duration_list = list(df[(df['kubernetes.host'] == sut)
                                            & (df['kubernetes.labels.name'] == test)]['duration'])
                    if test not in CYCLE:
                        df_latest.loc[sut, (test, 'result')] = result_list[0]
                        df_latest.loc[sut, (test, 'duration')] = round(duration_list[0], 3)
                    else:
                        if "PASSED" in result_list:
                            df_latest.loc[sut, (
                                test, 'result'
                            )] = f"PASSED({result_list.count('PASSED')}/{len(result_list)})"
                            df_latest.loc[sut, (test, 'duration')] = round(duration_list[0], 3)
                        else:
                            df_latest.loc[sut, (test, 'result')] = result_list[0]
                            df_latest.loc[sut, (test, 'duration')] = round(duration_list[0], 3)

        return df_latest

    elif type == "count":
        if "RMT" in testname:
            testname_replace = ["memory-margin" if x == "RMT" else x for x in testname]
        elif "OMT" in testname:
            testname_replace = [
                "memory-offset-training-margin" if x == "OMT" else x for x in testname
            ]
        else:  # AMT is no container
            testname_replace = testname

        if ns is not None:
            df = df[(df['kubernetes.labels.name'].isin(testname_replace))
                    & (df['kubernetes.host'].isin(suts)) & (df['kubernetes.namespace_name'] == ns)]
        else:
            df = df[(df['kubernetes.labels.name'].isin(testname_replace))
                    & (df['kubernetes.host'].isin(suts))]
        df_count = pd.pivot_table(data=df, index=['kubernetes.host',
                                                  'result'], columns='kubernetes.labels.name',
                                  values=['@timestamp'], aggfunc='count', dropna=False,
                                  margins=True, fill_value=0).droplevel(0, axis=1)

        for test in testname_replace:
            if test not in df_count.columns:
                df_count[test] = 0

        if 'memory-margin' in df_count.columns:
            df_count = df_count.rename(columns={'memory-margin': 'RMT'})
        elif 'memory-offset-training-margin' in df_count.columns:
            df_count = df_count.rename(columns={'memory-offset-training-margin': 'OMT'})
        else:
            pass
        df_count = df_count[testname]

        return df_count
    else:
        log.error("There is something error for no type.")


if __name__ == '__main__':

    # arg process
    parser = argparse.ArgumentParser("Start get test result sheet")
    parser.add_argument("-n", "--namespace", required=False,
                        help="search specific namespace test result")
    parser.add_argument("-c", "--cpu", required=True, default="SRF-SP", help="which cpu?")
    parser.add_argument("-t", "--type", required=True, help="what kind of pipeline's test result")
    parser.add_argument("-d", "--days", required=False, default=0, type=int,
                        help="search test results within days")
    parser.add_argument("-sf", "--sutfilename", required=True, help="SUT list filename")
    parser.add_argument("-tf", "--testfilename", required=False,
                        help="Custom test type list filename")
    parser.add_argument("-tc", "--totalcount", required=False, action='store_true',
                        help="the count result is needed?")
    parser.add_argument("-s", "--start", required=False, help="Pipeline start time")
    parser.add_argument("-e", "--end", required=False, help="Pipeline end time")
    args = parser.parse_args()

    if args.sutfilename:
        suts = get_file_content(args.sutfilename)
        log.info("Search Suts:")
        log.info(suts)

    if args.type == "Customs" and args.testfilename:
        test_list = get_file_content(args.testfilename)
        log.info("Custom Test List:")
        log.info(test_list)
    else:
        test_list = download_test_from_sp(args.cpu, TEST_LIST.get(args.type))

    if test_list is None:
        log.error("Cannot find corresponding test list file in SharePoint or Customs input text.")
        sys.exit(1)

    namespace = None
    if args.namespace:
        namespace = args.namespace

    # search test summary
    if args.type and suts is not None and test_list is not None and len(suts) > 0 and len(
            test_list) > 0:

        filename = "TEST_Summary_{}_{}.xlsx".format(args.type,
                                                    datetime.utcnow().strftime("%Y%m%d-%I%M%S"))
        log.info("Save Filename: " + filename)
        detail_latest_sheet_name = "{}_result_latest".format(args.type)
        detail_count_sheet_name = "{}_result_count".format(args.type)

        log.info("Start to get data...")
        data = get_data(day=args.days, start=args.start, end=args.end, ns=namespace)

        if data is not None:
            # save file
            log.info("start to preprocess latest data...")
            latest = get_result(type="latest", df=data, suts=suts, testname=test_list, ns=namespace,
                                day=args.days, start=args.start, end=args.end)
            save_df(latest, sheet_name=detail_latest_sheet_name, filename=filename)
            log.info("latest is completed.")

            if args.totalcount:
                log.info("start to preprocess count data...")
                count = get_result(type="count", df=data, suts=suts, testname=test_list,
                                   ns=namespace, day=args.days, start=args.start, end=args.end)
                # save file
                save_df(count, sheet_name=detail_count_sheet_name, filename=filename)
                log.info("count is completed.")
        else:
            log.warning("Cannot find correspoding logs.")
    else:
        log.error("some parameters missing,  please check again the command!")
