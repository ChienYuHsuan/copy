import logging
import os
import re
from collections import OrderedDict

import tenacity
import yaml
from jinja2 import Template

import asv_pipeline.config as cfg
from asv_pipeline.sharepoint import SharePoint

log = logging.getLogger(__name__)


def _url():
    # Need a relative path for the first parameter
    return '/' + '/'.join(cfg.sp_site_at.split('/')[-2:]) + 'Shared Documents/AT'


@tenacity.retry(stop=tenacity.stop_after_attempt(5),
                wait=tenacity.wait_exponential(min=10, max=60, multiplier=10), reraise=True)
def _crawl_task_from_sharepoint(payload={}, file='tasks.yaml'):
    log.info("Start downloading tasks from SharePoint")
    filename = None
    try:
        sp = SharePoint(cfg.sp_site_at)
        filename = sp.download(_url() + "/" + file, os.getcwd())
        if filename:
            try:
                with open(filename, 'r') as f:
                    ctx = f.read()
                    tpl = Template(ctx)
                    rendered_yaml = tpl.render(payload)
                    return yaml.safe_load_all(rendered_yaml)
            except yaml.YAMLError as err:
                log.error(err)
                raise
    except Exception as e:
        log.error(e)
        raise
    finally:
        try:
            if filename:
                os.remove(os.path.join(os.getcwd(), filename))
        except Exception as e:
            log.error(str(e))
    return None


def load_tasks() -> dict[str, str] | None:
    docs = _crawl_task_from_sharepoint()
    try:
        return list(docs)[0]
    except Exception as e:
        logging.error(e)
        return {}


def load_task_definition(task: str, payload: dict[str, str] = None) -> dict[str, str]:
    logging.info(f'task: {task}')
    try:
        docs = list(_crawl_task_from_sharepoint(payload))[1]
        logging.info(docs)
        for data in docs:
            logging.info(data)
            if task == data:
                return docs[task]
    except Exception as e:
        logging.error(e)
    msg = f"no available definition for {task}"
    logging.warning(msg)

    return {}


def compare_desc_with_pattern(cpu, desc: str, tasks: dict[str, str],
                              with_suffix: str = '--') -> str | bool:
    # for x in tasks:
    #     match = re.search(f'^{x}.*?(\d*)(?={with_suffix})', desc)  # noqa:  W605
    #     if match:
    #         logging.debug(f"x:{x}, desc:{desc}")
    #         if x in tasks and cpu.upper() in tasks[x]:
    #             logging.debug(f"tasks : {tasks[x]}")
    #             return tasks[x][cpu.upper()]

    for x in tasks:
        pattern = rf'^{x}(?:-\d+)?(?={with_suffix})'
        match = re.match(pattern, desc)  # noqa: W605
        if match:
            logging.debug(f"x: {x}, desc: {desc}")
            if x in tasks and cpu.upper() in tasks[x]:
                logging.debug(f"tasks: {tasks[x]}")
                return tasks[x][cpu.upper()]
    return False


def match_desc_with_pattern(desc: str, tasks: dict[str, str],
                            with_suffix: str = '--') -> str | bool:
    for x in tasks:
        match = re.search(rf'^{x}(?:.*?-(\d+))?(?={with_suffix})', desc)  # noqa:  W605
        if match:
            return x
    return False


def parse_task_for_iterations(task: str, desc: str, with_suffix: str = '--') -> str:
    logging.info(task)
    logging.info(desc)
    match = re.search(rf'^{task}(?:.*?-(\d+))?(?={with_suffix})', desc)  # noqa:  W605

    logging.info(match)
    if match:
        logging.info(match.groups())
        return match.group(1)
    return None


def load_raw_pipelines():
    _doc = _crawl_task_from_sharepoint(payload={}, file='pipelines.yaml')
    return list(_doc)[0]


# Function to parse the pipeline string into an OrderedDict
def load_pipelines(doc=None) -> OrderedDict:
    if not doc:
        _doc = _crawl_task_from_sharepoint(payload={}, file='pipelines.yaml')
        doc = list(_doc)[0]
    rst = {}
    ordered_lists = {}
    for cpu in doc:
        if 'pipeline' not in doc[cpu]:
            continue
        rst[cpu] = {}
        ordered_lists[cpu] = {}
        for tag in doc[cpu]['pipeline']:
            pipeline_str = doc[cpu]['pipeline'][tag]
            stages = pipeline_str.split(">>")
            pipeline_data = OrderedDict()
            # Because OrderedDict won't be serializable in Airflow, we return the ordered list in case.
            ordered_list = []
            for stage in stages:
                stage = stage.strip()
                if "(" in stage and ")" in stage:
                    name, iterations = stage.split("(")
                    iterations = int(iterations.rstrip(")"))
                    pipeline_data[name] = {"iterations": iterations, "tasks": []}
                    ordered_list += [name]
                elif "{" in stage and "}" in stage:
                    name, tasks = stage.split("{")
                    tasks = tasks.rstrip("}").strip()
                    tasks = tasks.split(",") if tasks else []
                    pipeline_data[name] = {"iterations": None, "tasks": tasks}
                    ordered_list += [name]
                else:
                    pipeline_data[stage] = {"iterations": None, "tasks": []}
                    ordered_list += [stage]
            rst[cpu][tag] = pipeline_data
            ordered_lists[cpu][tag] = ordered_list
    return rst, ordered_lists


def load_testname_in_pipelines(doc=None):
    if not doc:
        _doc = _crawl_task_from_sharepoint(payload={}, file='pipelines.yaml')
        doc = list(_doc)[0]
    rst = {}
    reversed_rst = {}
    for cpu in doc:
        if 'result' not in doc[cpu]:
            continue
        rst[cpu] = {}
        reversed_rst[cpu] = {}
        for tag in doc[cpu]['result']:
            rst[cpu][tag] = {}
            reversed_rst[cpu][tag] = {}
            for p in doc[cpu]['result'][tag]:
                rst[cpu][tag][p] = {}
                reversed_rst[cpu][tag][p] = {}
                for k, v in doc[cpu]['result'][tag][p].items():
                    rst[cpu][tag][p][k] = v
                    if isinstance(v, list):
                        for el in v:
                            if el not in reversed_rst[cpu][tag][p]:
                                reversed_rst[cpu][tag][p][el] = []
                            reversed_rst[cpu][tag][p][el] += [k]
                    else:
                        if v not in reversed_rst[cpu][tag][p]:
                            reversed_rst[cpu][tag][p][v] = []
                        reversed_rst[cpu][tag][p][v] += [k]
    return rst, reversed_rst


def meet_test_criteria(cpu, pipeline, testname, datasource, tag='default', doc=None) -> bool:
    """
    WHY using doc instead of wrapping it as class attribute.
    because we want to leverage this function into XCOM in Airflow, for serializable purpose, it is not suitable to wrap it as the class  

    qdf : CPU QDF
    pipeline : pipeline identity such as BURNIN, MAIN1 MAIN2
    datasource :   the data from ElasticSearch, including 2 indices: 'tests-' and 'burnin_tracker-'
    doc : the definition of the pipeline, qdf and related criteria.
    """
    if testname not in datasource:
        return False
    if not doc:
        logging.info("load the file from sharepoint")
        _doc = _crawl_task_from_sharepoint(payload={}, file='pipelines.yaml')
        doc = list(_doc)[0]

    if pipeline not in doc[cpu]['criteria'].get(tag, {}):
        logging.error(f"pipeline {pipeline} not in the criteria")
        return False
    if testname not in doc[cpu]['criteria'][tag].get(pipeline, {}):
        logging.error(f"testname {testname} not in the pipeline {pipeline} for the criteria")
        return False
    L = doc[cpu]['criteria'][tag][pipeline][testname]
    result = L[0]
    if isinstance(result, str):
        result = [result]

    calculated_result = datasource[testname]
    if not isinstance(calculated_result, str) and calculated_result[1]:
        calculated_result[1] = float(calculated_result[1]) * 3600
    log.info(
        f"""tag : {tag} ::: testname : {testname}, criteria : {L}, and result is {calculated_result}"""
    )

    passed = False
    for cond in result:
        checker = calculated_result
        log.info(f"checker : {checker}")
        if isinstance(checker, str):  # RMT/AMT/OMT
            if re.search(rf'{cond}', checker):
                passed = True
                break
        else:
            if re.search(rf'{cond}', checker[0]):
                if L[1]:
                    target = float(L[1])
                    # duration = float(checker[1]) * 3600
                    duration = checker[1]
                    if duration >= target:
                        passed = True
                        log.info(
                            f'{testname} with checker : {checker[0]}, duration {duration} >= {target} get passed'
                        )
                        break
                    else:
                        log.info(
                            f'{testname} with checker : {checker[0]}, duration {duration} < {target} get failed'
                        )
    return passed
