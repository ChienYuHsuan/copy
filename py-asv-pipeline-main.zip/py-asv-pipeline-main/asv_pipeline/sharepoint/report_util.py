import logging
import os
import re

import yaml

import asv_pipeline.clusterscope.poolname as cspoolname
import asv_pipeline.config as cfg
import asv_pipeline.rf.handler as hd
from asv_pipeline.rf import RFFactory
from asv_pipeline.sharepoint import SharePoint

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)

FILE = "bkc.yaml"
CACHED_BKC_DATA = None


def get_url():
    return '/' + '/'.join(
        cfg.sp_site_bkc.split('/')[-2:]) + '/Shared Documents/StaticFileDescription'


def get_bkcfile_once_from_sp(filelink=None):
    global CACHED_BKC_DATA
    dlfile = None
    if CACHED_BKC_DATA is None:
        log.info("Start downloading tasks from SharePont")
        try:
            sp = SharePoint(cfg.sp_site_bkc)
            dlfile = sp.download(filelink + "/" + FILE, os.getcwd())
            if dlfile:
                try:
                    with open(dlfile, 'r') as f:
                        CACHED_BKC_DATA = yaml.safe_load(f)
                        return CACHED_BKC_DATA
                except yaml.YAMLError as err:
                    log.error("Error loading YAML data: {}".format(err))
                    raise
        except Exception as e:
            log.error(e)
            raise
        finally:
            if dlfile:
                try:
                    os.remove(os.path.join(os.getcwd(), dlfile))
                except Exception as e:
                    log.error(str(e))
        return None
    else:
        return CACHED_BKC_DATA


def get_bkc_by_microcode_bios(microcode, bios, cpu):
    bkc_raw_data = get_bkcfile_once_from_sp(filelink=get_url() + "/" + str(cpu).upper())
    if bkc_raw_data is not None:
        if microcode and bios:
            for bkc, ingredients in bkc_raw_data.items():
                if microcode in ingredients.get("microcode",
                                                []) and ingredients.get("bios") in bios:
                    return bkc
    return 'others'


def get_bkc_detail(meta):
    detail = {}
    detail_str = ""

    try:
        name = meta.get("name")
        pool = meta.get("pool")

        # Get BKC version from poolname
        bkc_pattern = re.compile(r"[bB][kK][cC]-{0,}#{0,}[wW]{0,2}\d+")

        try:
            bkc_version = re.findall(bkc_pattern, cspoolname.parse(pool).test_description)
            if len(bkc_version) > 0:
                detail["BKC Version(pool)"] = bkc_version[0]
        except Exception as e:
            log.error("poolname parsing error, node = {} , ".format(name) + str(e))
            bkc_version = re.findall(bkc_pattern, pool)
            if len(bkc_version) > 0:
                detail["BKC Version(pool)"] = bkc_version[0]

        # Get BKC version from microcode/bios
        try:
            CPUTYPE = pool.split("_")[0]
            if CPUTYPE in ["SRF-SP", "SRF-AP"]:
                bkc = get_bkc_by_microcode_bios(meta.get("microcode"), meta.get("biosVersion"),
                                                CPUTYPE)
                if bkc != "others":
                    detail["BKC Version(microcodebios)"] = bkc
        except Exception as e:
            log.error("cannot get bkc from sharepoint, node = {} , ".format(name) + str(e))

        detail["BMC Version"] = meta.get("bmcVersion")
        detail["BIOS Version"] = meta.get("biosVersion")
        detail["CPLD Version"] = meta.get("cpldVersion")
        detail["cpuId"] = meta.get("cpuId")
        detail["microcode"] = meta.get("microcode")

        meVersion = meta.get("meVersion")
        if "unknown" not in meVersion:
            detail["ME Version"] = meVersion
        detail["Platform"] = meta.get("platform")
        detail["Pool"] = pool

        # Get cpld/memory data from Redfish
        try:
            rf = RFFactory(name)
            detail["CPU CPLD"] = hd.get_cpu_cpld(name, rf, islogout=False)
            detail["DBG CPLD"] = hd.get_debug_cpld(name, rf, islogout=False)
            detail["SCM CPLD"] = hd.get_scm_cpld(name, rf, islogout=False)
            detail["PFR CPLD"] = hd.get_pfr_cpld(name, rf, islogout=False)

            bmcVersion = hd.get_bmc(name, rf, islogout=False)
            if bmcVersion != detail["BMC Version"]:
                detail["BMC Version"] = bmcVersion

            biosVersion = hd.get_bios(name, rf, islogout=False)
            if biosVersion != detail["BIOS Version"]:
                detail["BIOS Version"] = biosVersion

            dimm0, dimm1 = hd.get_dimm0_dimm1(name, rf, islogout=True)

            # DIMM0
            dimm0_Manu = dimm0.get("Manufacturer").strip()
            dimm0_PartNumber = dimm0.get("PartNumber").strip()
            dimm0_Speed = dimm0.get("OperatingSpeedMhz")
            dimm0_Size = int(dimm0.get("CapacityMiB") / 1024)

            # DIMM1
            dimm1_Manu = dimm1.get("Manufacturer").strip()
            dimm1_PartNumber = dimm1.get("PartNumber").strip()

            # TODO need more check, temporary fix return value
            if pool.startswith("SRF-AP"):
                dimmDPC = "1DPC"
            else:
                dimmDPC = "2DPC"
                if '' == dimm1_Manu or dimm1_PartNumber == 'NO DIMM':
                    dimmDPC = "1DPC"

            dimm0_str = "{} {}GB {} ({})".format(dimm0_Manu, dimm0_Size, dimm0_PartNumber,
                                                 dimm0_Speed)
            detail["DIMM"] = dimmDPC + " " + dimm0_str

        except Exception as e:
            logging.error("get info from redfish error, node = {} , ".format(name) + str(e))

        # Compose final BMC detail
        for k, v in detail.items():
            if k == "BKC Version(pool)":
                detail_str += "BKC#" + v[3:] + " (from poolname)\n"
            elif k == "BKC Version(microcodebios)":
                detail_str += v + " (from CS microcode/bios version)\n"
            else:
                detail_str += "{} - {}".format(k, v) + "\n"

        logging.debug(detail_str)

    except Exception as e:
        logging.error("get get_bkc_detail error, " + str(e))

    return detail_str
