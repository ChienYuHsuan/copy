import os
from collections import defaultdict

from asv_pipeline.sharepoint.update_burnin import get_node_list
from asv_pipeline.tasks.mem_tests import query_amt, query_os_margin, query_rmt


def burnin_results():
    cluster = ''
    kubeconfig = os.environ.get('KUBECONFIG')
    if kubeconfig:
        cluster = kubeconfig.split(".")[-1]

    rst = get_node_list()
    if 'No' in rst:
        return

    res_amt = query_amt(cluster, rst, 'sol_raw-')
    res_rmt = query_rmt(cluster, rst)
    res_omt = query_os_margin(rst)
    res = defaultdict(dict)

    for host, data in res_amt.items():
        res[host]['AMT'] = data['results']

    for host, data in res_rmt.items():
        res[host]['RMT'] = data['status']

    for host, data in res_omt.items():
        res[host]['OS Margin'] = data['results']

    for host, test in res.items():
        print(host, test)


if __name__ == "__main__":
    burnin_results()
