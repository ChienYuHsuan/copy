import logging
import os
import re
from datetime import datetime

import openpyxl
import pandas as pd

import asv_pipeline.clusterscope.handler as handler
import asv_pipeline.config as cfg
from asv_pipeline.clusterscope.handler import get_metadata_by_nodes, get_sku
from asv_pipeline.es import es_handler
from asv_pipeline.k8s import Pod
from asv_pipeline.sharepoint import SharePoint
from asv_pipeline.sharepoint.report_util import get_bkc_detail
from asv_pipeline.util import get_cluster_by_naming, get_ww_tpe

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

FOLDER = "Shared Documents/NotReady Nodes Reporting - "
FILE = "NOTREADY_NODE_%(cpu)s_%(ww)s.xlsx"


def _load_default_df() -> pd.DataFrame:

    return pd.DataFrame({
        'Node': [],
        'L1|L2 owner': [],
        'content': [],
        'Initial Pool': [],
        'QDF PCH': [],
        'QDF': [],
        'stepping': [],
        'Socket Count': [],
        'timeline': [],
        'TTF': [],
        'automatic presighting': [],
        'Manual HSD': [],
        'Master PS?': [],
        'PythonSV Result': [],
        'Error Root Cause': [],
        'BKC': [],
        'Last test-Subtest': [],
        'Kernel Panic': [],
        'MCEs/MCAs': [],
        'Hardware errors': [],
        'Event log ': [],
        'Final Pool': [],
        'Next Steps': []
    })


def _get_sharepoint_url(cpu):
    _folder = ''

    if cpu == 'spr':
        _folder += 'SPR'
    elif cpu == 'emr':
        _folder += 'EMR'
    elif cpu == 'gnr':
        _folder += 'GNR'
    elif cpu == 'srf':
        _folder += 'SRF'
    else:
        err = f'Unrecognized CPU: {cpu.upper()}'
        log.error(err)
        raise Exception(err)

    # Need a relative path for the first parameter
    return '/' + '/'.join(cfg.sp_site_notready.split('/')[-2:]) + '/' + FOLDER + _folder


def load_existed_excel(cpu) -> pd.DataFrame:
    log.info("Start updating sheet in SharePont")
    ww = get_ww_tpe()
    filename = FILE % {"cpu": cpu.upper(), "ww": ww}
    try:
        sp = SharePoint(cfg.sp_site_notready)
        path = sp.download(_get_sharepoint_url(cpu) + "/" + filename, os.getcwd())
        if path:
            book = openpyxl.load_workbook(path)
            weekday = datetime.utcnow().isoweekday()
            sheet_prefix = ww + '.' + str(weekday)
            sheet = ''
            for ws in book.worksheets:
                k = ws.title
                if k.startswith(sheet_prefix):
                    sheet = k
                    log.info("Update Sheet: %s" % sheet)
                    break
            return pd.read_excel(path, sheet_name=sheet)
    except Exception as e:
        logging.error(e)
        raise
    finally:
        try:
            os.remove(os.path.join(os.getcwd(), filename))
        except Exception as e:
            log.error(str(e))
    return None


def save_upload_excel(df: pd.DataFrame, cpu, metadata=None, remove_file=True):
    if not isinstance(df, pd.DataFrame) or df.empty:
        logging.info(type(df))
        logging.info(df)
        logging.info(df.empty)
        return
    ww = get_ww_tpe()
    filename = FILE % {"cpu": cpu.upper(), "ww": ww}
    try:
        sp = SharePoint(cfg.sp_site_notready)
        path = sp.download(_get_sharepoint_url(cpu) + "/" + filename, os.getcwd())
        relative_filename = os.path.join(os.getcwd(), filename)
        if not path:
            with pd.ExcelWriter(relative_filename, engine='openpyxl') as writer:

                load_default_df = _load_default_df()
                next_ww = ww
                sheet_name = f"{ww}.7 - {next_ww}.1" if len(next_ww) > 0 else f"{ww}.7"
                load_default_df.to_excel(writer, sheet_name=sheet_name, index=False)
                for i in range(1, 7):
                    next_ww = 'WW' + str(int(ww[2:]) + 1).zfill(2) if i == 7 else ww
                    sheet_name = f"{ww}.{i} - {next_ww}.{1 if i == 7 else i + 1}" if len(
                        next_ww) > 0 else f"{ww}.{i}"
                    load_default_df.to_excel(writer, sheet_name=sheet_name, index=False)
                # writer.save()

        if not os.path.isfile(relative_filename):
            raise Exception(f"fail to download {path} to {relative_filename}")

        with pd.ExcelWriter(relative_filename, engine='openpyxl', mode='a',
                            if_sheet_exists='overlay') as writer:

            book = openpyxl.load_workbook(relative_filename)
            writer.workbook = book
            # writer.sheets = {ws.title: ws for ws in book.worksheets}

            weekday = datetime.utcnow().isoweekday()
            sheet_prefix = ww + '.' + str(weekday)
            sheet = ''

            logging.info(writer.sheets.keys())
            for k in writer.sheets.keys():
                if k.startswith(sheet_prefix):
                    sheet = k
                    log.info("Update Sheet: %s" % sheet)
                    break
            if len(sheet) < 0:
                raise Exception("not suitable sheet")
            df.to_excel(writer, sheet_name=sheet, index=False)
            if metadata:
                # if there're pythonsv data
                if "pythonsv" in metadata:
                    logging.info("update pythonsv in metadata")
                    ins = metadata["pythonsv"]
                    logging.info(ins)
                    if ins:
                        _sheet = writer.sheets[sheet]
                        for idx, node in enumerate(df['Node'].tolist(), start=2):
                            if node in ins and ins[node]:
                                cell = _sheet[f'N{idx}']
                                cell.value = f'[{node}]{ins[node]}'
                                match = re.search(r"https?://\S+", ins[node])
                                if match:
                                    cell.hyperlink = match.group(0)
                                    cell.style = "Hyperlink"
            # writer.save()
        sp.upload(relative_filename, FOLDER + cpu.upper())

    except Exception as e:
        logging.error(e)
        raise
    finally:
        try:
            if remove_file:
                os.remove(os.path.join(os.getcwd(), filename))
        except Exception as e:
            log.error(str(e))


def update_dataframe(current_df: pd.DataFrame, rst) -> pd.DataFrame:
    if not isinstance(current_df, pd.DataFrame):
        current_df = pd.DataFrame()
    logging.info("=" * 33)
    logging.info(rst)
    logging.info(current_df)
    logging.info(rst)
    logging.info("=" * 33)
    for key, val in rst.items():
        if isinstance(val, list):
            if val and isinstance(val[0], Pod):
                for v in val:
                    if v.node in current_df["Node"].unique():
                        log.info("%s is already in sheet" % v.node)

                    test = v.name
                    workload, _, _ = es_handler.get_burnin_phase(get_cluster_by_naming(v.node),
                                                                 v.node, key)
                    if "killer-pod" in v.name and workload:
                        test = v.name + " (after %s)" % workload
                    reboot_count = es_handler.get_reboot_count(v.node, v.ns)
                    meta = get_metadata_by_nodes([v.node])
                    if meta:
                        df = pd.DataFrame({
                            "Node": [v.node],
                            "content": [key],
                            "Initial Pool": [meta[0].get('pool', 'NA')],
                            "QDF": [meta[0].get('qdf', 'NA')],
                            "stepping": [meta[0].get('stepping', 'NA')],
                            "Socket Count":
                            [get_sku(v.node, meta[0].get('0', 'NA'), meta[0].get('1', 'NA'))],
                            "TTF": ["Reboot count: %s" % reboot_count],
                            "BKC": [get_bkc_detail(meta[0])],
                            "Last test-Subtest": [test]
                        })
                    else:
                        log.warning("%s: No metadata from ClusterScope" % v.node)
                        df = pd.DataFrame({
                            "Node": [v.node],
                            "content": [key],
                            "TTF": ["Reboot count: %s" % reboot_count],
                            "Last test-Subtest": [test]
                        })

        else:
            meta = handler.get_metadata_by_nodes([key])
            if meta:
                df = pd.DataFrame({
                    "Node": [key],
                    "content": [val['bkc_name']],
                    "Initial Pool": [meta[0].get('pool', 'NA')],
                    "QDF": [meta[0].get('qdf', 'NA')],
                    "stepping": [meta[0].get('stepping', 'NA')],
                    "Socket Count":
                    [handler.get_sku(key, meta[0].get('0', 'NA'), meta[0].get('1', 'NA'))],
                    "TTF": [val['repetition']],
                    "BKC": [get_bkc_detail(meta[0])],
                    "Last test-Subtest": [val['reset_type']]
                })
            else:
                log.warning("%s: No metadata from ClusterScope" % key)
                df = pd.DataFrame({
                    "Node": [key],
                    "content": ["DPMO"],
                    "TTF": [val['repetition']],
                    "Last test-Subtest": [val['reset_type']]
                })
        current_df = pd.concat([current_df, df], ignore_index=True)
    logging.info(current_df)
    logging.info(current_df['Node'].tolist())
    return current_df
