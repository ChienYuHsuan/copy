# if sys.version_info.major == 3 and sys.version_info.minor < 9
from __future__ import annotations

# import concurrent.futures
import logging
import os
import sys
from datetime import datetime

import pandas as pd
import pytz
from openpyxl import load_workbook

import asv_pipeline.config as cfg
from asv_pipeline.sharepoint import SharePoint
from asv_pipeline.tasks.pythonsv import pure_mca_error  # , unlock
from asv_pipeline.tasks.pythonsv.fstream import stream_upload
from asv_pipeline.util import get_cluster_by_naming, get_ww_tpe

FOLDER = "Shared Documents/NotReady Nodes Reporting - "
FILE = "NOTREADY_NODE_%(cpu)s_%(ww)s.xlsx"
"""
Create an Excel file with column names and sheets respectively. Sample file name is "GDC_SPR_WW34.xlsx".
"""

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

nrn_template = {
    "Node": "",
    "L1|L2 owner": "",
    "content": "",
    "Initial Pool": "",
    "QDF PCH": "",
    "QDF": "",
    "stepping": "",
    "Socket Count": "",
    "timeline": "",
    "TTF": "",
    "automatic presighting": "",
    "HSD": "",
    "Master PS?": "",
    "PythonSV Result": "",
    "Error Root Cause": "",
    "BKC": "",
    "Last test-Subtest": "",
    "Kernel Panic": "",
    "MCEs/MCAs": "",
    "Hardware errors": "",
    "Event log": "",
    "Final Pool": "",
    "Next Steps": "",
    "Creation Time": "",
    "NRN timestamp": "",
    "PythonSV Readiness": "",
    "pythonSV_sharepoint_path": "",
    "Previous Pool": "",
    "Pipeline": ""
}


def create_file(cpu, ww):
    cwd = os.getcwd()
    filename = FILE % {"cpu": cpu.upper(), "ww": ww}
    sheet_path = os.path.join(cwd, filename)
    try:
        writer = pd.ExcelWriter(sheet_path, engine='openpyxl')
    except Exception as e:
        log.error(str(e))
        sys.exit(1)
    df = pd.DataFrame({
        'Node': [],
        'L1|L2 owner': [],
        'content': [],
        'Initial Pool': [],
        'QDF PCH': [],
        'QDF': [],
        'stepping': [],
        'Socket Count': [],
        'timeline': [],
        'TTF': [],
        'automatic presighting': [],
        'HSD': [],
        'Master PS?': [],
        'PythonSV Result': [],
        'Error Root Cause': [],
        'BKC': [],
        'Last test-Subtest': [],
        'Kernel Panic': [],
        'MCEs/MCAs': [],
        'Hardware errors': [],
        'Event log ': [],
        'Final Pool': [],
        'Next Steps': [],
        'Creation Time': [],
        'NRN timestamp': []
    })
    for i in range(1, 8):
        if i == 7:
            next_ww = 'WW' + str(int(ww[2:]) + 1)
            df.to_excel(
                writer, sheet_name="%(ww)s.%(day1)s - %(next_ww)s.%(day2)s" % {
                    "ww": ww,
                    "day1": i,
                    "next_ww": next_ww,
                    "day2": 1
                }, index=False)
        else:
            df.to_excel(
                writer, sheet_name="%(ww)s.%(day1)s - %(ww)s.%(day2)s" % {
                    "ww": ww,
                    "day1": i,
                    "day2": i + 1
                }, index=False)
    writer.close()
    return sheet_path


def launch_pythonsv(node):
    try:
        outstream = pure_mca_error(get_cluster_by_naming(node), node)
        rst, _ = stream_upload(node, outstream)
        log.debug(rst)
        return rst
    except Exception as e:
        log.error(e)
        raise


def update(path, ww, body, metadata: dict[str, dict] = None):
    if not os.path.isfile(path):
        log.info("Update - %s doesn't exist in local path" % path)
        return
    try:
        writer = pd.ExcelWriter(path, engine='openpyxl', mode='a', if_sheet_exists='overlay')
    except Exception as e:
        log.error(str(e))
        sys.exit(1)
    book = load_workbook(path)
    writer.workbook = book

    weekday = datetime.now(pytz.timezone('Asia/Taipei')).isoweekday()
    sheet_prefix = ww + '.' + str(weekday)
    sheet = ''
    for k in writer.sheets.keys():
        if k.startswith(sheet_prefix):
            sheet = k
            log.info("Update Sheet: %s" % sheet)
            break

    current_df = pd.read_excel(path, sheet_name=sheet)
    """
    # wait for keypair importing.
    node_to_link = {}
    with concurrent.futures.ThreadPoolExecutor() as executor:
        future_to_node = {}
        for val in rst.values():
            for x in val:
                node = x.node
                future_to_node[executor.submit(launch_pythonsv, node)] = node
        # Wait for all tasks to complete and retrieve the results
        for f in concurrent.futures.as_completed(future_to_node):
            node = future_to_node[f]
            try:
                link = f.result()
                node_to_link[node] = link
            except Exception as e:
                log.error('%s generated an exception: %s' % (node, e))
            else:
                log.info("%s's PythonSV log located at %s" % (node, link)) 
    """
    for b in body:
        df = pd.DataFrame({
            "Node": [b["Node"]],
            "content": [b["content"]],
            "Initial Pool": [b["Initial Pool"]],
            "QDF": [b["QDF"]],
            "stepping": [b["stepping"]],
            "Socket Count": [b["Socket Count"]],
            "TTF": [b["TTF"]],
            "automatic presighting": [b["automatic presighting"]],
            "BKC": [b["BKC"]],
            "Last test-Subtest": [b["Last test-Subtest"]],
            "Creation Time": [b["Creation Time"].replace(tzinfo=None)],
            "NRN timestamp": [b["NRN timestamp"].replace(tzinfo=None)],
            "Previous Pool": [b["Previous Pool"]],
            "PythonSV Result": [b["PythonSV Result"]],
            "pythonSV_sharepoint_path": [b["pythonSV_sharepoint_path"]]
        })

        current_df = pd.concat([current_df, df], ignore_index=True)

    logging.info(current_df['Node'].tolist())

    current_df.to_excel(writer, sheet_name=sheet, index=False)

    if metadata:
        # if there're pythonsv data
        if "pythonsv" in metadata:
            ins = metadata["pythonsv"]
            _sheet = writer.sheets[sheet]
            for idx, node in enumerate(current_df['Node'].tolist(), start=2):
                if node in ins:
                    cell = _sheet[f'N{idx}']
                    cell.value = f'[{node}]{ins[node]}'
                    cell.hyperlink = ins[node]
                    cell.style = "Hyperlink"
    # hyperlinkize
    # _sheet = writer.sheets[sheet]
    # for idx, node  in enumerate(current_df['Node'].tolist(), start=2):
    #     cell = _sheet[f'N{idx}']
    #     cell.value = f'[{node}]{node_to_link[node]}'
    #     cell.hyperlink = node_to_link[node]
    #     cell.style = "Hyperlink"

    writer.close()


def update_notready_sheet(body, cpu, metadata=None):
    log.info("Start updating sheet in SharePont")
    ww = get_ww_tpe()
    sp = SharePoint(cfg.sp_site_notready)
    _folder = 'SRF-SP' if cpu == 'srf' else cpu.upper()

    # Need a relative path for the first parameter
    url = '/' + '/'.join(cfg.sp_site_notready.split('/')[-2:]) + '/' + FOLDER + _folder
    filename = FILE % {"cpu": _folder.upper(), "ww": ww}
    path = None
    try:
        path = sp.download(url + "/" + filename, os.getcwd())
    except Exception as e:
        log.error(f"Error downloading file: {e}")

    if not path:
        log.info("File doesn't exist in SharePoint. Go create a file")
        path = create_file(_folder, ww)

    _cpu = 'srf-sp' if cpu == 'srf' else cpu
    update(path, ww, body, metadata)
    sp.upload(path, FOLDER + _cpu.upper())


def clean_nrn_report(cpu):
    FILE = "NOTREADY_NODE_%(cpu)s_%(ww)s.xlsx"

    ww = get_ww_tpe()

    # Check if report of previous WW exists
    pre_ww_number = int(ww[-2:]) - 1
    pre_ww = f"WW{pre_ww_number}"

    _folder = 'SRF-SP' if cpu == 'srf' else cpu.upper()
    pre_ww_filename = FILE % {"cpu": _folder.upper(), "ww": pre_ww}
    log.info(f"Report filename of previous week: {pre_ww_filename}")

    if not os.path.isfile(pre_ww_filename):
        log.info(f"File {pre_ww_filename} doesn't exist. No need to remove file.")
    else:
        try:
            log.info(f"Remove {pre_ww_filename}")
            os.remove(pre_ww_filename)
        except Exception as e:
            log.error(f"Error removing file: {e}")
