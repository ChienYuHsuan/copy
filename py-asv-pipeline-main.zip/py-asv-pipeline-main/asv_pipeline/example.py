"""Python boilerplate example."""


class Example:
    """Example class."""

    def __init__(self, msg):
        self.msg = msg
