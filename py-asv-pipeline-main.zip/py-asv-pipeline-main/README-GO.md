# Goto Instroduction
Do you suffer from the travering amoung the servers through bastions ?

**Goto** is a script to help you to readily reach out sites where we need to operate k8s/Sysman

For now, we support sites:**OPUS, GDC, FLEX** and for `BMC, SYS and K8S` operations

### prerequiste
- **Adjust/Change** clone asv_pipeline/config.py from asv_pipeline/config.py.sample to finish your configuration.
  - **kubeconfigs**
  - **patterns**, when scraping from k8s cluster, we only focus on designate pattern instead whole nodes.
  - **jenkins_username**
  - **jenkins_password**
  - **i_idsid**
  - **i_password**
  - **DEO_INFRA_PASSWORD** 
- If you want to execute the CMD like your ususal way, you can put the `goto.py` to your `/usr/local/bin/` or `/usr/bin`.
- if you want to input your sso passwod automatically and securely , please use environment variables
    ~~~
    $ export I_PASSWORD=<idsid password>
    ~~~
  or you can leverage the option `-p` for your password, but this way is not so secure.
    ~~~
    $ goto -i <idsid> -p <intel sso password> [opus|flex|gdc]
    ~~~
### Note
- you can use make goto-install to install to your binary directory.
- you have to pip install pexcept in advance.
- **limitation** no fullcy support long size of buffers, for example huge length for a CMD from history and editor, like vim/vi. Eexpect adopts pseudo-terminal (tty) to execute remote commands, but currenlty don't support well on editors & huge length of buffers.
### How to use
#### options
- -p,--passowrd:  your idsid password. You can also use env variable instead
  ~~~
  $ export I_PASSWORD=xxx
  ~~~
- -m, --mgmt: you want to login for system level operation (sysman). With this option, you can also bring second argument as the node name.
  it will auto help you to reboot the Node by `sysman -am -M <node_name>`. For example, 
  ~~~
  $ goto -m flex r01p01.fl0001
  ~~~ 
- -b, --bmc : you want to login for adm level operation (bmc)
- -i, --idsid: your idsid. You can also use env variable instead
  ~~~
  $ export I_IDSID=xxx
  ~~~
#### args
currently, we support FLEX|OPUS|GDC

#### examples
- Flex
  - Goto handle **k8s cluster**. `Goto` will also load `KUBECONFIG=/srv/kube/config.flex` 
    ~~~
    $ goto flex
    ~~~
  - Goto **sysman**
    ~~~
    $ goto -m flex r018s008.fl30lus00x # for avoid misoperating, obscure the node name
    ~~~
  - Goto **bmc**
    ~~~
    $ goto -b flex
    ~~~
- OPUS
  - Goto handle k8s cluster, `Goto` will load `KUBECONFIG=/srv/kube/config.opus-spr`
    ~~~
    $ goto opus
    ~~~
  - Goto **sysman**
    ~~~
    $ goto -m opus r08s08.op20lminorx # for avoid misoperating, obscure the node name
    ~~~
  - Goto **bmc**
    ~~~
    $ goto -b opus
    ~~~
- GDC
  - Goto handle k8s cluster, `Goto` will load `KUBECONFIG=/srv/kube/config.icx-1`
    ~~~
    $ goto gdc
    ~~~
  - Goto **sysman**
    ~~~
    $ goto -m gdc r031s017.zp31l0fxxx # for avoid misoperating, obscure the node name
    ~~~
  - Goto **bmc**
    ~~~
    $ goto -b gdc
    ~~~