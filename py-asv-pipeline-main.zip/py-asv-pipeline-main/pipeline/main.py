import getopt
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
sys.path.insert(0, ROOT)
from asv_pipeline.tasks.kubernetes import add_label_and_ns
from asv_pipeline.tasks.xmlcli import progknobs, readknobs
from asv_pipeline.util import get_cluster_by_naming


def init(data, opts):
    for x in data:
        if opts == 2 or opts == 3:
            print(x, readknobs(get_cluster_by_naming(x),x, "VendorSpecificOutlierCheckDisable=1,bdatEn=1,EnableEvLoader=1,AttemptFastBoot=0,AttemptFastBootCold=0,AllowedSocketsInParallel=1,TrainingResultOffsetFunctionEnable=1"))
            # progknobs(get_cluster_by_naming(x),x, "VendorSpecificOutlierCheckDisable=1,bdatEn=1,EnableEvLoader=1,AttemptFastBoot=0,AttemptFastBootCold=0,AllowedSocketsInParallel=1,TrainingResultOffsetFunctionEnable=1")
        if opts == 1 or opts == 3:
            add_label_and_ns(get_cluster_by_naming(x),x,"spr-dbg-tests-kloh")

if __name__ == "__main__":
    opts, args = getopt.getopt(sys.argv[1:], "nk", ["knob","ns"])
    exec_opt = 0
    for k,_ in opts:
        if k in ['-n', '--ns']:
            exec_opt += 1
        if k in ['-k', '--knob']:
            exec_opt += 2
    if not exec_opt: exec_opt = 3
    print(args)
    data = args[0].split(',')
    print(type(data))
    print("do you confirm that above data is correct? [y|Y]", end="")
    print(", and will execute ", end="")
    if exec_opt == 2 or exec_opt == 3:
        print("readknob ", end="")
    if exec_opt == 1 or exec_opt == 3:
        if exec_opt > 1:
            print("and ", end= "")
        print("add_label", end="")
    print("")
    confirmed = input()
    if confirmed.lower() in ['y']:
        print("[ start ]")  
        init(data, exec_opt)

    