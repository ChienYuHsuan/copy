# SharePoint
## upload
```
$ python pipeline/PL.py sp upload \
-path {your file location} \
-target_dir {the directory in SharePoint} \
-site {site name is SharePoint} \
-client_id {client_id} \
-client_secret {client_secret}
```
Note that, the `target_dir` must exist in SharePoint.