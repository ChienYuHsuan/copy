import distutils.text_file
import os
import pathlib
import re
from pathlib import Path
from typing import List

import pkg_resources
from setuptools import find_packages, setup

ROOT = os.path.dirname(__file__)
VERSION_RE = re.compile(r'''__version__ = ['"]([0-9.]+)['"]''')

with pathlib.Path('requirements.txt').open() as requirements_txt:
    install_requires = [
        str(requirement)
        for requirement
        in pkg_resources.parse_requirements(requirements_txt)
    ]
def get_version():
    # init = open(os.path.join(ROOT, 'asv_pipeline', '__init__.py')).read()   
    # return VERSION_RE.search(init).group(1)
    import asv_pipeline
    print(asv_pipeline.__version__)
    return asv_pipeline.__version__.split("-")[0]



setup(
    name='asv_pipeline',
    packages=find_packages(exclude=['docs', 'tests']),
    scripts=['bin/example_script'],
    author='yc0',
    author_email='nelson.lin@intel.com',
    description='ASV automation',
    url=' https://github.com/intel-sandbox/py-asv-pipeline',
    include_package_data=True,
    install_requires=None,
    python_requires='>=3',
    version=get_version(),
    license='Intel',
)
