import logging

import pytest

from asv_pipeline.clusterscope import poolname


@pytest.fixture
def poolname_with_dbg_state():
    _poolname = poolname.parse("EMR_XCC-A1_PIV_DBG_IVE_PRODUCTION-DPMO-SMLINK1-BKC25-NOTREADY_RICARDOH")
    yield _poolname

    logging.info("teardown the poolname_with_dbg_state fixture")