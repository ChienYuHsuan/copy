import json
from unittest.mock import patch

import pytest


# Fixture to load JSON data from a file
@pytest.fixture
def json_fixture():
    with open('data.json', 'r') as file: 
        data = json.load(file)
        yield data

# Test function that uses the mocked function with the fixture as return value
@patch('your_module.function_to_mock')
def test_mocked_function(mock_function_to_mock, json_fixture):
    # Mock function returns the JSON data from the fixture
    mock_function_to_mock.return_value = json_fixture

    # Invoke the function that uses the mocked function
    result = your_module.function_using_mocked_function()

    # Perform assertions based on the result
    assert result == expected_result