import json
import logging
import os

import pytest
import yaml
from jinja2 import Template


@pytest.fixture
def sharepoint_task_fixture():
    logging.info(os.getcwd())
    with open('../../fixtures/tasks.yaml', 'r') as f:
        ctx = f.read()
        tpl = Template(ctx)
        rendered_yaml = tpl.render({})
        rst = list(yaml.safe_load_all(rendered_yaml))
        yield rst

@pytest.fixture
def sharepoint_pipeline_fixture():
    logging.info(os.getcwd())
    with open('../../fixtures/pipelines.yaml', 'r') as f:
        ctx = f.read()
        tpl = Template(ctx)
        rendered_yaml = tpl.render({})
        rst = list(yaml.safe_load_all(rendered_yaml))
        yield rst
   

# Fixture to load JSON data from a file
@pytest.fixture
def generic_mca_fixture():
    logging.info(os.getcwd())
    with open('../../fixtures/pythonsv_generic_mca.txt', 'r') as file: 
        yield file.read()

@pytest.fixture
def pythonsv_errordump():
    logging.info(os.getcwd())
    with open('../../fixtures/pythonsv_errordump.txt', 'r') as file: 
        yield file.read()

@pytest.fixture
def sysman_status_fixture():
    logging.debug("fixture the result of sysman --status -M")
    ctx = """
linnelso@fl31ca104ia0219:~$ sysman --status -M fl41ca202gs1104
exit
Machine translates to %BMC%fl41ca202gb1104.deacluster.intel.com;
fl41ca202gs1104: GNR-SP_X2-ES1_PIV_DEV_PIV_BKC-TEST-MAIN_DTORALVA pool
fl41ca202gs1104: OS reported by System is Linux 6.2.0-gnr.bkc.6.2.6.10.30.x86_64
fl41ca202gs1104: OS version is ntOS Stream 9
fl41ca202gs1104: BMC Last Reset Time 2023-11-30T09:21:05+00:00
fl41ca202gs1104: Node Last Reset Time 2023-12-14T16:53:24+00:00
fl41ca202gs1104: BMC available at fl41ca202gb1104.deacluster.intel.com - True
fl41ca202gs1104: BMC credentials valid - True
fl41ca202gs1104: BMC version bhs-0.30-37-gf1a47a-89f4cad
fl41ca202gs1104: SDR version Can't collect SDR due to this issue: https://hsdes.intel.com/appstore/article/#/14011372068
fl41ca202gs1104: Unable to determine SDR mismatch
fl41ca202gs1104: BIOS version BHSDCRB1.CON.0027.D40.2310191840
fl41ca202gs1104: cpuid version 0xa06d0
fl41ca202gs1104: microcode version 0x800004f0
fl41ca202gs1104: ME version unknown
fl41ca202gs1104: CPLD version:0.0-3.0-2b4ad20a226a125980a955cc4dba48ad9d87145e0b1ff11ef26b88cea14b31c8
fl41ca202gs1104: CPLD main:0.17
fl41ca202gs1104: CPLD debug:0.17
fl41ca202gs1104: CPLD scm:4.11
fl41ca202gs1104: CPLD pfr:0.0-3.0-2b4ad20a226a125980a955cc4dba48ad9d87145e0b1ff11ef26b88cea14b31c8
fl41ca202gs1104: Power is ON
fl41ca202gs1104: LEDs - green_blink, amber_off, blue_on
fl41ca202gs1104: Host primary network up - True
fl41ca202gs1104: Error Log completed count = 0
fl41ca202gs1104: CATERR count = unknown
"""
    yield ctx

    logging.info("fixture sysman --status -M teardown")

