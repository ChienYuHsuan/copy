import logging

import pytest


@pytest.fixture
def k8s_pods_fixture():
    from asv_pipeline.k8s import Pod
    _data = {'srf-burnin-b0-rerun-ww49-4-3': ['killer-pod-rxlm6,srf-burnin-b0-rerun-ww49-4-3,6h45m,Terminating,10.75.46.204,fl41ca201es1103'], 'srf-burnin-b0-ww49-2': ['killer-pod-6grp7,srf-burnin-b0-ww49-2,12h,Terminating,10.75.47.202,fl41ca202es0408'], 'srf-main-a0-es2-ww49-3': ['ive-rdt-v1p3-23ww12-4-k9nvm,srf-main-a0-es2-ww49-3,4h57m,Running,100.65.193.15,fl31ca102gs0906'], 'srf-main-pnp-a0-es2-ww49-3': ['paiv-pnp-srf-main-specrate2017-int-74xxg,srf-main-pnp-a0-es2-ww49-3,8h,Terminating,10.75.144.36,fl31ca102gs0603'], 'srf-main-pnp-a0-es2-ww49-5': ['killer-pod-5hr8d,srf-main-pnp-a0-es2-ww49-5,11h,Terminating,10.45.207.169,fl31ca102fs0608']}
    rst = {}
    for k,v in _data.items():
        rst[k] = []
        for el in v:
            EL = el.split(",")
            rst[k] += [Pod(EL[0],EL[1],EL[2],EL[3],EL[4],EL[5])]
    yield rst

    logging.info("tear down for k8s pods' fixture")