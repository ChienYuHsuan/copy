# asv_pipeline

[![pipeline](https://github.com/intel-innersource/applications.productivity.python-boilerplate/actions/workflows/status.yml/badge.svg)](https://github.com/intel-innersource/applications.productivity.python-boilerplate/actions)

[![license](https://img.shields.io/badge/intel-confidential-blue)](https://img.shields.io/badge/intel-confidential-blue)
## Overview

This project will cover the at-scale team's automation and automated workflow for SOP, including 4 parts:

* k8s, redfish, clusterscope, elasticsearch, os, sharepoint and Jenkins (how we manipulate the peripheral services from at-scale tech stack )
* Linting (pylint, flake8, isort, pydocstyle)
* tasks (Apache Airflow)
* Packaging (setuptools)

## Installation
```
> git clone https://github.com/intel-sandbox/py-asv-pipeline.git
> cd py-asv-pipeline
> source <venv path>/bin/activate
> make install
```

## Configuration
Since we will execute CMDs in OS of systems and bastions, as well as integrate with certain API Services such as ClsuterScope and ElasticSearch, we need to get endpoints' authentication through account, password, secret, token or credential information. The place we store those information is at `config.py`

Due to security concern, we don't keep config.py on the Github. You can copy the `config.py.sample` into `config.py`, and fill out the data.

```
> cd <venv path>/lib/python<version>/site-packages/asv_pipeline/
> copy config.py.sample config.py
> nano config.py # or use your preferred editor
```
## Other Document
[Sirloin - Intel Wiki](http://goto/sirloin)

## Legal

INTEL CONFIDENTIAL

© 2019-2021 Intel Corporation

This software and the related documents are Intel copyrighted materials, and
your use of them is governed by the express license under which they were
provided to you ("License"). Unless the License provides otherwise, you may not
use, modify, copy, publish, distribute, disclose or transmit this software or
the related documents without Intel's prior written permission.

This software and the related documents are provided as is, with no express or
implied warranties, other than those that are expressly stated in the License.
